/* --------------------------------------------------------------------------
 * ZIPIdent - Written by Logiqx (http://www.logiqx.com/)
 *
 * Little tool that tries to identify ZIP files that are emulated by MAME
 * -------------------------------------------------------------------------- */

/* --- Size declarations --- */

#define MAX_GAMES  5000
#define MAX_ROMS 100000

#define MAX_ZIP_ENTRIES 100

#define LONG_NAME_LENGTH 128
#define FILE_NAME_LENGTH 13
#define GAME_NAME_LENGTH 20
#define TITLE_LENGTH 100
#define MANUFACTURER_LENGTH 60
#define YEAR_LENGTH 4
#define CRC_LENGTH 8
#define SIZE_LENGTH 8
#define REGION_LENGTH 6

#define BUFFER_SIZE 1024

/* --- Scan types --- */

#define SCAN_DIR    0x0001
#define SCAN_TEXT   0x0002
#define SCAN_FILE   0x0003

/* --- Flags --- */

#define SIZE_MATCH    0x0001
#define NAME_MATCH    0x0002
#define CRC_MATCH     0x0004
#define PERFECT_MATCH (CRC_MATCH+NAME_MATCH+SIZE_MATCH)

/* --- Dat structures --- */

struct rom
{
	char name[FILE_NAME_LENGTH+1];
	char merge[FILE_NAME_LENGTH+1];
	int size;
	unsigned long crc;
	char region[REGION_LENGTH+1];
	unsigned long best_match;
};

struct game
{
	char name[GAME_NAME_LENGTH+1];
	char title[TITLE_LENGTH+1];
	char manufacturer[MANUFACTURER_LENGTH+1];
	char year[YEAR_LENGTH+1];
	char cloneof[GAME_NAME_LENGTH+1];
	char romof[GAME_NAME_LENGTH+1];
	struct rom *first_rom;
	int num_roms;
	unsigned long flags;
	double score;
};

struct rom_idx
{
	struct game *game;
	struct rom *rom;
};

struct game_idx
{
	struct game *game;
};

struct dat
{
	char name[LONG_NAME_LENGTH+1];
	struct game *games;
	struct game_idx *game_idx;
	struct rom *roms;
	struct rom_idx *rom_crc_idx;
	struct rom_idx *rom_name_idx;
	int num_games;
	long num_roms;
};

struct zip_entry
{
	char name[LONG_NAME_LENGTH+1];
	char uname[LONG_NAME_LENGTH+1];
	int size;
	unsigned long crc;
	char region[REGION_LENGTH+1];
	unsigned long best_match;
};

/* --- Dummy ROMs --- */

struct dummy_rom
{
	int size;
	unsigned long crc;
};

struct dummy_rom dummy_roms[] =
{
	{       1, 0xd202ef8d},
	{       2, 0x41d912ff},
	{       4, 0x2144df1c},
	{       8, 0x6522df69},
	{      16, 0xecbb4b55},
	{      32, 0x190a55ad},
	{      64, 0x758d6336},
	{     128, 0xc2a8fa9d},
	{     256, 0x0d968558},
	{     512, 0xb2aa7578},
	{    1024, 0xefb5af2e},
	{    2048, 0xf1e8ba9e},
	{    4096, 0xc71c0011},
	{    8192, 0xd8f49994},
	{   16384, 0xab54d286},
	{   32768, 0x011ffca6},
	{   65536, 0xd7978eeb},
	{  131072, 0x7ee8cdcd},
	{  262144, 0xe20eea22},
	{  524288, 0x75660aac},
	{ 1048576, 0xa738ea1c},
	{ 2097152, 0x8d89877e},
	{ 4194304, 0x1147406a},
	{ 8388608, 0x1ad2bc45},
	{16777216, 0xa47ca14a},

	/* --- list terminator --- */
	{       0, 0x00000000}
};

/* --- Function protoypes --- */

int init_dat(struct dat *, char *);
int load_mame_listinfo(struct dat *);
int release_dat(struct dat *);

int rom_idx_crc_sort_function(const void *, const void *);
int rom_idx_name_sort_function(const void *, const void *);

int find_rom_by_crc(const void *, const void *);
int find_rom_by_comp_crc(const void *, const void *);
int find_rom_by_name(const void *, const void *);

int scan_dir(FILE *, FILE *, struct dat *, char *, char *);
int process_text(FILE *, FILE *, struct dat *, char *, char *);
int process_zip(FILE *, FILE *, struct dat *, char *, char *);
int process_entries(FILE *, FILE *, struct dat *, char *, struct zip_entry *, int, char *);
void output_title(FILE *, char *);

/* --- Useful macros --- */

#define REMOVE_CR_LF(ST) \
{ \
	while ((ST[strlen(ST)-1]==10) || (ST[strlen(ST)-1]==13)) \
		ST[strlen(ST)-1]='\0'; \
}

#define CALLOC(PTR, NUMBER, TYPE) \
if (!(PTR=calloc(NUMBER, sizeof(struct TYPE)))) \
{ \
	printf("Not enough memory\n"); \
	errflg++; \
}

#define FREE(PTR) \
if (PTR) \
{ \
	free(PTR);\
}

#define FOPEN(PTR, FN, MODE) \
if (!(PTR=fopen(FN, MODE))) \
{ \
	printf("Error opening %s for mode '%s'\n", FN, MODE); \
	errflg++; \
}

#define FCLOSE(PTR) \
if (PTR) \
{ \
	fclose(PTR); \
	PTR=0; \
}

#define LOWER(ST) \
{ \
	char *ptr=ST; \
	int i; \
	for (i=0; i<strlen(ptr); i++) \
		ptr[i]=tolower(ptr[i]); \
}

#define GET_TOKEN(TOKEN, ST_PTR) \
{ \
	int token_idx=0; \
\
	while (*ST_PTR==' ' || *ST_PTR=='	') \
		ST_PTR++; \
\
	if (*ST_PTR=='"') \
	{ \
		ST_PTR++; \
		while (*ST_PTR!='"' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
		if (*ST_PTR!='\0') \
			ST_PTR++; \
	} \
	else \
	{ \
		while (*ST_PTR!=' ' && *ST_PTR!='	' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
	} \
}

#define MATCH_ROM \
{ \
	match=0; \
	if (rom_match->rom->crc==zip_entry[i].crc || rom_match->rom->crc==~zip_entry[i].crc) \
		match|=CRC_MATCH; \
	if (rom_match->rom->size==zip_entry[i].size) \
		match|=SIZE_MATCH; \
	if (!strcmp(rom_match->rom->name, zip_entry[i].uname)) \
		match|=NAME_MATCH; \
\
	if (match > rom_match->rom->best_match) \
		rom_match->rom->best_match=match; \
\
	if (match > zip_entry[i].best_match) \
	{ \
		zip_entry[i].best_match=match; \
		strcpy(zip_entry[i].region, rom_match->rom->region); \
	} \
\
	for (j=found=0; !found && j<num_game_matches; j++) \
	{ \
		if (rom_match->game==dat->game_idx[j].game) \
		found++; \
	} \
\
	if (!found) \
	{ \
		dat->game_idx[num_game_matches].game=rom_match->game; \
		num_game_matches++; \
	} \
\
	rom_match++; \
}

/* --------------------------------------------------------------------------
 * STORE_ROM macro
 *
 * Based on code from DatUtil (but stripped out non-MAME related bits)
 * -------------------------------------------------------------------------- */

#define STORE_ROM(ST) \
{ \
	/* --- Extract details and store them --- */ \
	st_ptr=ST; \
	GET_TOKEN(token, st_ptr) /* skip rom token */ \
	GET_TOKEN(token, st_ptr) /* skip bracket */ \
	GET_TOKEN(token, st_ptr) \
	while (*token) \
	{ \
		/* --- ROM name --- */ \
		if (!strcmp(token, "name")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			LOWER(token) \
			strncpy(roms[num_roms].name, token, GAME_NAME_LENGTH); \
			roms[num_roms].name[GAME_NAME_LENGTH]='\0'; \
			*token='\0'; \
		} \
		/* --- ROM 'merge' name --- */ \
		if (!strcmp(token, "merge")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			LOWER(token) \
			strncpy(roms[num_roms].merge, token, GAME_NAME_LENGTH); \
			roms[num_roms].merge[GAME_NAME_LENGTH]='\0'; \
			*token='\0'; \
		} \
		/* --- ROM size --- */ \
		if (!strcmp(token, "size")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			roms[num_roms].size=strtoul(token, NULL, 10); \
		} \
		/* --- ROM CRC --- */ \
		if (!strcmp(token, "crc") || !strcmp(token, "crc32")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			roms[num_roms].crc=strtoul(token, NULL, 16); \
		} \
		/* --- ROM region --- */ \
		if (!strcmp(token, "region")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			strncpy(roms[num_roms].region, token, REGION_LENGTH); \
			roms[num_roms].region[REGION_LENGTH]='\0'; \
		} \
		/* --- Onto next property... --- */ \
		GET_TOKEN(token, st_ptr) \
	} \
	/* --- That's one more ROM --- */ \
	rom_crc_idx[num_roms].rom=&roms[num_roms]; \
	rom_crc_idx[num_roms].game=&games[num_games]; \
\
	rom_name_idx[num_roms].rom=&roms[num_roms]; \
	rom_name_idx[num_roms].game=&games[num_games]; \
\
	games[num_games].num_roms++; \
	num_roms++; \
}

/* --- Game name formatting --- */

#define FORMAT_GAME_NAME(ST, GAME) \
{ \
	strncpy(st, GAME->title, 41); \
	st[41]='\0'; \
	strcat(st, " [name: "); \
	strcat(st, GAME->name); \
	if (strcmp(GAME->name, GAME->cloneof)) \
	{ \
		strcat(st, " - parent: "); \
		strcat(st, GAME->cloneof); \
	} \
	strcat(st, "]"); \
}


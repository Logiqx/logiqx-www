/* --------------------------------------------------------------------------
 * ROMBuild - Written by Logiqx (http://www.logiqx.com)
 *
 * A simple little utility for re-building ROMs
 * -------------------------------------------------------------------------- */

#define ROMBUILD_VERSION "v1.13"
#define ROMBUILD_DATE "18 January 2003"

/* --- The standard includes --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <zlib.h>

/* --- Although DJGPP has a getopt function, MinGW, CygWin and MSVC don't --- */

#if defined (__MINGW32_VERSION) || defined (__CYGWIN__) || defined (_MSC_VER)
#include "getopt.c"	// Same functions as in unistd library
#else
#include <unistd.h>
#endif

#if defined (_MSC_VER) || defined (__MINGW32_VERSION)
#define MKDIR(a,b) mkdir((a))
#else
#define MKDIR(a,b) mkdir((a),(b))
#endif

/* --- Definitions for MAME's unzip routines --- */

#include "mame/unzip.h"

/* --- My type definitions and the ROM information --- */

#include "rombuild.h"
#include "rominfo.h"

/* --------------------------------------------------------------------------
 * The main() function just works out what the user wants to do then calls the
 * appropriate function.
 *
 * Uses the getopt() function from unistd to interpret command line options.
 * -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
	extern char *optarg;
	extern int optind;

	int c, errflg = 0;
	int list=0, fulllist=0;

	char emulator[ID_LENGTH+1]="";
	char game[GAME_LENGTH+1]="";
	char in_dir[PATH_LENGTH+1]="roms_in";
	char out_dir[PATH_LENGTH+1]="roms_out";

	int emulator_idx=-1;
	int game_idx=-1;

	printf("===============================================================================\n");
	printf("ROMBuild %s (%s)\n", ROMBUILD_VERSION, ROMBUILD_DATE);
	printf("Written by Logiqx (http://www.logiqx.com)\n");
	printf("===============================================================================\n");

	/* --- Get the options specified on the command line --- */

	while ((c = getopt(argc, argv, "i:o:l?L")) != EOF)
	switch (c)
	{
		case 'i':
			strcpy(in_dir, optarg);
			break;
		case 'o':
			strcpy(out_dir, optarg);
			break;
		case 'l':
			list++;
			break;
		case 'L':
			fulllist++;
			break;
		case '?':
			errflg++;   /* User wants help! */
	}

	/* --- Display the help page if required --- */

	if (!list && !fulllist && argc-optind<1)
			errflg++;

	if (errflg)
	{
		printf("Usage: rombuild [-l] [-i in_dir] [-o out_dir] [emulator [game]]\n\n");
		printf("Using the -l or -L options will list supported emulators/games/roms.\n");
		exit (1);
	}

	/* --- Get going then! --- */

	if (!errflg && argc-optind>=1)
	{
		strncpy(emulator, argv[optind], ID_LENGTH);
		emulator[ID_LENGTH]='\0';
		if ((emulator_idx=find_emulator(emulator))==-1)
			errflg++;
	}

	if (!errflg && argc-optind>=2)
	{
		strncpy(game, argv[optind+1], GAME_LENGTH);
		game[GAME_LENGTH]='\0';
		if ((game_idx=find_game(emulator, game))==-1)
			errflg++;
	}

	if (!errflg && list)
	{
		switch (argc-optind)
		{
			case 0:
				list_ems();
				break;
			case 1:
				list_games(emulator_idx);
				break;
			default:
				list_roms(emulator_idx, game_idx);
				break;
		}
	}

	if (!errflg && fulllist)
	{
		full_list();
	}

	if (!errflg && !list && !fulllist)
	{
		rebuild_roms(emulator_idx, game_idx, in_dir, out_dir);
	}

	/* --- All done --- */

	exit(errflg);
}

/* --------------------------------------------------------------------------
 * Validation of parameters
 * -------------------------------------------------------------------------- */

int find_emulator(char *emulator)
{
	int i=0;

	while(ems[i].descr[0])
	{
		if (!strcmp(ems[i].id, emulator))
			return(i);
		i++;
	}

	printf("Invalid emulator (%s)\n", emulator);
	return(-1);
}

int find_game(char *emulator, char *game)
{
	int i=0, j=0;

	if ((i=find_emulator(emulator))==-1)
		return(-1);

	while (ems[i].roms[j].local.game[0])
	{
		if (!strcmp(ems[i].roms[j].local.game, game))
			return(j);
		j++;
	}

	printf("Invalid game (%s/%s)\n", emulator, game);
	return(-1);
}

/* --------------------------------------------------------------------------
 * CRC calculation uses zlib function
 * -------------------------------------------------------------------------- */

unsigned long CalcFileCRC32(char *fn, unsigned long reclen)
{
	FILE *in;
	unsigned char *mem;
	unsigned long crc=0;

	if (!(in=fopen(fn, "rb")))
	{
		printf("Error opening %s\n", fn);
		return(0);
	}

	if ((mem=malloc(reclen)))
	{
		fread(mem, 1, reclen, in);
		crc = crc32(0, NULL, 0);
		crc = crc32(crc, mem, reclen);
		free(mem);
	}

	fclose(in);

	return(crc);
}


/* --------------------------------------------------------------------------
 * Listing supported emulators/games/roms
 * -------------------------------------------------------------------------- */

void list_ems()
{
	int i=0;

	printf("Supported Emulators:\n\n");
	while(ems[i].descr[0])
	{
		printf("%12s - %s\n", ems[i].id, ems[i].descr);
		i++;
	}
}

void list_games(int emulator_idx)
{
	int i=emulator_idx, j=0;

	printf("Supported Games (of %s):\n\n", ems[i].id);

	while (ems[i].roms[j].local.game[0])
	{
		if (j==0 || strcmp(ems[i].roms[j].local.game, ems[i].roms[j-1].local.game))
		{
			printf("%s\n", ems[i].roms[j].local.game);
		}
		j++;
	}
}

void list_roms(int emulator_idx, int game_idx)
{
	int i=emulator_idx, j=game_idx;

	printf("Supported ROMs (of %s/%s):\n\n", ems[i].id, ems[i].roms[j].local.game);

	while (!strcmp(ems[i].roms[j].local.game, ems[i].roms[game_idx].local.game))
	{
		if (j==0 || strcmp(ems[i].roms[j].local.rom, ems[i].roms[j-1].local.rom))
		{
			printf("%s (size %ld, crc %08lx)\n", ems[i].roms[j].local.rom, ems[i].roms[j].local.size, ems[i].roms[j].local.crc);
		}
		j++;
	}
}

void full_list()
{
	int i=0, j;

	printf("All supported ROMs:\n\n");

	while(ems[i].descr[0])
	{
		j=0;
		while (ems[i].roms[j].local.game[0])
		{
			//if (j==0 || strcmp(ems[i].roms[j].local.game, ems[i].roms[j-1].local.game))
			if (j==0 || strcmp(ems[i].roms[j].local.rom, ems[i].roms[j-1].local.rom))
			{
				printf("%s,", ems[i].id);
				printf("%s,", ems[i].roms[j].local.game);
				printf("%s,%ld,%08lx\n", ems[i].roms[j].local.rom, ems[i].roms[j].local.size, ems[i].roms[j].local.crc);
			}
			j++;
		}
		i++;
	}
}

/* --------------------------------------------------------------------------
 * Processing of 'roms_in' directory
 * -------------------------------------------------------------------------- */

void rebuild_roms(int emulator_idx, int game_idx, char *in_dir, char *out_dir)
{
	struct Cache rom_cache[1024];

	char fn[PATH_LENGTH+1];
	struct stat buf;
	unsigned long crc;

	int i, j=0;
	int found=0;

	/* --- Generate an array (rom_cache) of ROMs we're looking for --- */

	if (game_idx==-1)
	{
		printf("Rebuilding ROMs for %s:\n\n", ems[emulator_idx].id);

		i=0;
		while (ems[emulator_idx].roms[i].local.game[0])
		{
			rom_cache[j].rom=&ems[emulator_idx].roms[i];
			rom_cache[j].file[0]='\0';
			i++; j++;
		}
	}
	else
	{
		printf("Rebuilding ROMs for %s/%s:\n\n", ems[emulator_idx].id, ems[emulator_idx].roms[game_idx].local.game);

		i=game_idx;
		while (!strcmp(ems[emulator_idx].roms[i].local.game, ems[emulator_idx].roms[game_idx].local.game))
		{
			rom_cache[j].rom=&ems[emulator_idx].roms[i];
			rom_cache[j].file[0]='\0';
			i++; j++;
		}
	}

	rom_cache[j].rom=NULL;

	/* --- Scan the Input directory --- */

	printf("Scanning...\n");

	scan_dir(in_dir, rom_cache);

	for (i=0; i<j; i++)
	{
		if (((rom_cache[i].file[0]) && ((rom_cache[i].rom->local.offset==0) || (i>0 && rom_cache[i-1].file[0])))
				|| (rom_cache[i].rom->local.offset==0 && rom_cache[i].rom->type==BLOCK_FILL))
			found++;
	}

	/* --- Build the new ROMs --- */

	if (found)
		printf("\nBuilding...\n");
	else
		printf("\nNothing to do!\n");

	for (i=0; found && i<j; i++)
	{
		if ((rom_cache[i].rom->type==ODD_COPY || rom_cache[i].rom->type==EVEN_COPY ||
				rom_cache[i].rom->type==FULL_COPY) &&
				(rom_cache[i].file[0]) &&
				((rom_cache[i].rom->local.offset==0) || (i>0 && rom_cache[i-1].file[0])))
			copy_region(out_dir, &rom_cache[i]);

		if (rom_cache[i].rom->type==COMBINE_EVEN &&
				(rom_cache[i].file[0]) &&
				((rom_cache[i].rom->local.offset==0) || (i>0 && rom_cache[i-1].file[0])))
			combine_region(out_dir, &rom_cache[i], &rom_cache[i+1]);

		if (rom_cache[i].rom->type==COMBINE_ODD)
			rom_cache[i].file[0]='\0';	/* ensure no verification */

		if (rom_cache[i].rom->type==LOWER_COPY &&
				(rom_cache[i].file[0]) &&
				((rom_cache[i].rom->local.offset==0) || (i>0 && rom_cache[i-1].file[0])))
			combine_region_2(out_dir, &rom_cache[i], &rom_cache[i+1]);

		if (rom_cache[i].rom->type==LOWER_SHIFT)
			rom_cache[i].file[0]='\0';	/* ensure no verification */

		if ((rom_cache[i].rom->type==BLOCK_FILL && rom_cache[i].rom->local.offset==0) ||
			(i>0 && rom_cache[i].rom->type==BLOCK_FILL && rom_cache[i-1].file[0]))
		{
			fill_region(out_dir, &rom_cache[i]);
			sprintf(rom_cache[i].file, " ");	/* ensure verification */
		}
	}

	/* --- Verify the new ROMs --- */

	if (found)
		printf("\nVerifying...\n");

	for (i=0; found && i<j; i++)
	{
		if (rom_cache[i].file[0] && rom_cache[i].rom->local.offset==0)
		{
			sprintf(fn, "%s/%s/%s", out_dir, rom_cache[i].rom->local.game, rom_cache[i].rom->local.rom);
			if (stat(fn, &buf) == 0)
			{
				if (buf.st_size == rom_cache[i].rom->local.size)
				{
					crc=CalcFileCRC32(fn, rom_cache[i].rom->local.size);
					if (crc==rom_cache[i].rom->local.crc)
						printf("%s/%s is ok\n", rom_cache[i].rom->local.game, rom_cache[i].rom->local.rom);
					else
						printf("%s/%s failed CRC check (%08lx instead of %08lx)\n", rom_cache[i].rom->local.game, rom_cache[i].rom->local.rom, crc, rom_cache[i].rom->local.crc);
				}
				else
				{
						printf("%s/%s failed size check\n", rom_cache[i].rom->local.game, rom_cache[i].rom->local.rom);
				}
			}
		}
	}
}

/* --------------------------------------------------------------------------
 * The directory scan routine - recursive
 * -------------------------------------------------------------------------- */

int scan_dir(char *dir, struct Cache *rom_cache)
{                                                  
	DIR *dirp;                                    
	struct dirent *direntp;                       
	struct stat buf;

	ZIP *zip;
	struct zipent *zipent;

	char fn[PATH_LENGTH+1];
	unsigned long crc;
	int i;

	dirp = opendir(dir);                          

	while (dirp && ((direntp = readdir(dirp)) != NULL))
	{
		sprintf(fn, "%s/%s", dir, direntp->d_name);
		if (stat(fn, &buf) == 0)
		{
			if (!(buf.st_mode & S_IFDIR))
			{
				if (strrchr(fn, '.') && !strcmp(strrchr(fn, '.'), ".zip"))
				{
					if ((zip = openzip(fn)))
					{
						while ((zipent = readzip(zip)) != 0)
						{
							i=0;
							while (rom_cache[i].rom)
							{
								if ((rom_cache[i].rom->mame.crc==zipent->crc32) && (rom_cache[i].rom->mame.size==zipent->uncompressed_size))
									sprintf(rom_cache[i].file, fn);
								i++;
							}
						}
						closezip(zip);
					}
				}
				else
				{
					crc=CalcFileCRC32(fn, buf.st_size);
					i=0;
					while (rom_cache[i].rom)
					{
						if ((rom_cache[i].rom->mame.crc==crc) && (rom_cache[i].rom->mame.size==buf.st_size))
							sprintf(rom_cache[i].file, fn);
						i++;
					}
				}
			}
			else
			{
				if (fn[strlen(fn)-1]!='.')	/* Don't try . or .. entries */
					scan_dir(fn, rom_cache);
			}
		}
		else
		{
			printf("Error getting attributes of %s\n", direntp->d_name);
		}
	}

	if (dirp)
		closedir(dirp);                               

	return (0);                                   
}                                                  

/* --------------------------------------------------------------------------
 * Load a ROM region from a file or ZIP file
 * -------------------------------------------------------------------------- */

unsigned char *load_region(char *source_fn, struct Rom *region)
{
	unsigned char *mem;
	FILE *in=NULL;

	int i=0, j=0;

	ZIP *zip;
	struct zipent* zipent;

	if (!(mem=malloc(region->mame.size)))
		return(0);

	printf("%s/%s (region %05lx-%05lx) using %s", region->local.game, region->local.rom, region->local.offset, region->local.offset+region->local.length-1, source_fn);

	if (strrchr(source_fn, '.') && !strcmp(strrchr(source_fn, '.'), ".zip"))
	{
		if ((zip = openzip(source_fn)))
		{
			while ((zipent = readzip(zip)))
			{
				if ((region->mame.crc==zipent->crc32) && (region->mame.size==zipent->uncompressed_size))
				{
					readuncompresszip(zip, zipent, mem);
					if (region->mame.offset)
						memcpy(mem, mem+region->mame.offset, region->mame.size-region->mame.offset);
				}
			}
			closezip(zip);
		}
		else
		{
			free(mem);
			return(0);
		}
	}
	else
	{
		if (!(in=fopen(source_fn, "rb")))
		{
			printf("Error opening %s\n", source_fn);
			free(mem);
			return(0);
		}
		else
		{
			fseek(in, region->mame.offset, SEEK_SET);
			fread(mem, 1, region->mame.size, in);

			fclose(in);
		}
	}

	if (region->type==ODD_COPY || region->type==EVEN_COPY)
	{
		if (region->type==ODD_COPY)
			j++;

		for (i=0; i<region->local.length; i++)
		{
			if (i!=j)
				mem[i]=mem[j];
			j+=2;
		}
	}
	
	if (region->patch)
	{
		i=0;
		while(region->patch[i].address)
		{
			mem[region->patch[i].address]=region->patch[i].value;
			i++;
		}
		printf(" (patched)\n");
	}
	else
		printf("\n");

	return(mem);
}

/* --------------------------------------------------------------------------
 * Write a block of memory to a ROM file
 * -------------------------------------------------------------------------- */

void write_block(char *out_dir, struct Rom *region, unsigned char *mem)
{
	FILE *out=NULL;
	char fn[PATH_LENGTH+1];
	struct stat buf;

	strcpy(fn, out_dir);
	if (stat(fn, &buf))
	{
		if (MKDIR(fn, S_IRWXU))
			printf("Error creating directory '%s'\n", fn);
	}

	sprintf(fn, "%s/%s", out_dir, region->local.game);
	if (stat(fn, &buf))
	{
		if (MKDIR(fn, S_IRWXU))
			printf("Error creating directory '%s'\n", fn);
	}

	sprintf(fn, "%s/%s/%s", out_dir, region->local.game, region->local.rom);
	if (region->local.offset==0)
	{
		if (!(out=fopen(fn, "wb")))
			printf("Error opening '%s' for writing\n", fn);
	}
	else
	{
		if (!stat(fn, &buf))
		{
			if (buf.st_size!=region->local.offset)
				printf("%s/%s (region %05lx-%05lx) skipped\n", region->local.game, region->local.rom, region->local.offset, region->local.offset+region->local.length-1);
			else if (!(out=fopen(fn, "ab")))
				printf("Error opening '%s' for append\n", fn);
		}
		else
		{
			printf("File does not exist '%s'\n", fn);
		}
	}

	if (mem && out)
	{
		fseek(out, region->local.offset, SEEK_SET);
		fwrite(mem, 1, region->local.length, out);
	}

	if (out)
		fclose(out);
}

/* --------------------------------------------------------------------------
 * ROM manipulation routines
 * -------------------------------------------------------------------------- */

int copy_region(char *out_dir, struct Cache *cache)
{
	unsigned char *mem;

	if ((mem=load_region(cache->file, cache->rom)))
	{
		write_block(out_dir, cache->rom, mem);
		free(mem);
	}

	return(0);
}

int combine_region(char *out_dir, struct Cache *cache1, struct Cache *cache2)
{
	unsigned char *mem1;
	unsigned char *mem2;
	unsigned char *mem;
	int i=0;

	if (!(mem1=load_region(cache1->file, cache1->rom)))
		return(0);

	if (!(mem2=load_region(cache2->file, cache2->rom)))
	{
		free(mem1);
		return(0);
	}

	if (!(mem=malloc(cache1->rom->mame.size+cache2->rom->mame.size)))
	{
		free(mem2);
		free(mem1);
		return(0);
	}

	for (i=0; i<cache1->rom->local.length; i++)
		mem[i*2]=mem1[i];

	for (i=0; i<cache2->rom->local.length; i++)
		mem[i*2+1]=mem2[i];

	write_block(out_dir, cache1->rom, mem);

	free(mem);
	free(mem2);
	free(mem1);

	return(0);
}

int combine_region_2(char *out_dir, struct Cache *cache1, struct Cache *cache2)
{
	unsigned char *mem1;
	unsigned char *mem2;
	unsigned char *mem;
	int i=0;

	if (!(mem1=load_region(cache1->file, cache1->rom)))
		return(0);

	if (!(mem2=load_region(cache2->file, cache2->rom)))
	{
		free(mem1);
		return(0);
	}

	if (!(mem=malloc(cache1->rom->mame.size+cache2->rom->mame.size)))
	{
		free(mem2);
		free(mem1);
		return(0);
	}

	for (i=0; i<cache1->rom->local.length; i++)
	{
		mem[i]=((mem1[i] & 0x0f) | ((mem2[i] % 8) << 4));
	}

	write_block(out_dir, cache1->rom, mem);

	free(mem);
	free(mem2);
	free(mem1);

	return(0);
}

void fill_region(char *out_dir, struct Cache *cache)
{
	struct Rom *region=cache->rom;
	unsigned long *mem;
	int i;

	if ((mem=malloc(region->local.length)))
	{
		for (i=0; i<region->local.length/4; i++)
		{
			mem[i]=region->mame.crc;
		}

		printf("%s/%s (region %05lx-%05lx) using fill value 0x%08lx\n", region->local.game, region->local.rom, region->local.offset, region->local.offset+region->local.length-1, region->mame.crc);

		write_block(out_dir, region, (unsigned char *)mem);

		free(mem);
	}
}

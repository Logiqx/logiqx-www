CONTENTS
--------
This zip archive contains a ClrMame Pro dat file
for checking and rebuilding MAMu's MAME 0.70
icons for use with MAME 0.71, PinMAME 1.21 and
MAME32 0.71.

USAGE
-----
Download icons.zip from
  http://www.mameworld.net/icons
to ...\<your MAME folder>\icons\icons.zip.

Extract "MAMu Icons 20030629.dat" to your ClrMame
Pro datfile folder.  (ClrMame Pro is available at
http://www.clrmame.com)

Start ClrMame Pro.  In the Profiler load the dat
file.  Go to Settings and set your paths.  Next go
to the Scanner: set your 'Systems...' paths,
select the 'Checksums...' you require, select the
items you want to 'Check' and 'Fix' then click
'Scan...'

For more help see the ClrMame Pro help files.

CONTACT DETAILS
---------------
If you spot any bugs or have any suggestions,
please send me an e-mail to:
  ZaxQuimby@hotmail.com

Happy MAMEing,

Zax.

Some notes:

Replace the not yet dumped vector game sample with an empty 22KHz/16bit/mono wav file
and marked the roms 'flags baddump'. The empty wav is included, so you can use the
rebuilder to add them.

I keep wotwc as a clone of wotw. Aaron isn't sure if the 2 sets use the same samples.
Until further knowledge I keep it as a clone.

                                            Unofficial Mame32 Titles


                                 Creating a correct titles.zip with RomCenter


I'm afraid I can't help you here as I have never used RomCenter before, I merely convert the ClrMamePro dat with Logiqx's Dat Util to RomCenter format to support users of RomCenter.

If you have never used RomCenter before to rebuild files then I suggest you use the ClrMamePro dat instead as full instructions are provided within the zip.

If you use RomCenter and can provide instructions on how to Rebuild with it then give me a shout at:-

petr1fied@mametitles.com

Full credits will go to yourself for providing the instructions.


Thanks go out to:-

Roman Scherzer     - http://www.clrmame.com   -  for creating the excellent ClrMamePro and hosting my dats.
Logiqx             - http://www.logiqx.com    -  for all of the excellent dat tools and also for hosting my dats.
MameWorld          - http://www.mameworld.net -  for making the Titles the success they've become. 
RomShare/EmuChina  - http://www.romshare.net  -  for taking the titles onboard (full titles.zip available here.)

And of course JohnIV for creating the Title Packs to v0.67 and the entire mame32 team for creating mame32, without them these title packs would not exist. - http://www.classicgaming.com/mame32qa


Petr1fied, http://www.mametitles.com

                                            Unofficial Mame32 Titles


                    Creating a correct titles.zip from the seperate titlepacks with ClrMamePro


First download the seperate Title Packs into a folder. (anywhere but your mame/titles folder)

Now Launch ClrMamePro and drag the dat into the profiler window and select the dat from "Not used / New Dat Files" and click "Load / Update" If this is the first time you have done this you will be offered 4 options, so select Default and Click OK. (For future dat files you will be asked if you want to update so click OK and it will keep the folder settings the same.)

Now click on the "Rebuilder" button and select the location you saved the Title packs to as the Source and your mame/titles folder as the Destination and Click "Rebuild" now just sit back and let ClrMamePro do all the hard work for you. Once your correct titles.zip has been created you can either delete the original Title Packs or keep them, it's up to you. (ClrMamePro will remove them for you if you tick "Remove Rebuilt Source Files")


                                    Rebuilding from one version to the next


The best way of doing this is to move your previously correct titles.zip to another folder and download the new Title Pack(s) to the same folder and rebuild from that folder to your mame/titles folder. (This is because occasonally games change from a Parent to a Clone and in that case the title is deleted)

Alternatively you can leave titles.zip in your mame/titles folder and set up your mame/titles folder under Rom-Paths in the Settings menu and run a scan with "Fix Unneeded" ticked and answer "Yes to All" to remove any unneeded files prior to rebuilding with the new title pack. 

Thanks go out to:-

Roman Scherzer     - http://www.clrmame.com   -  for creating the excellent ClrMamePro and hosting my dats.
Logiqx             - http://www.logiqx.com    -  for all of the excellent dat tools and also for hosting my dats.
MameWorld          - http://www.mameworld.net -  for making the Titles the success they've become. 
RomShare/EmuChina  - http://www.romshare.net  -  for taking the titles onboard (full titles.zip available here.)

And of course JohnIV for creating the Title Packs to v0.67 and the entire mame32 team for creating mame32, without them these title packs would not exist. - http://www.classicgaming.com/mame32qa


Petr1fied, http://www.mametitles.com
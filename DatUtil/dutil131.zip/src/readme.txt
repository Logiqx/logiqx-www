-------------------------------------------------------------------------------
                                   DatUtil

                  Written by Logiqx (http://www.logiqx.com)
-------------------------------------------------------------------------------

Foreword
--------

I have provided the source for DatUtil so that people can add support for any
additional dat formats and also because it may be a useful learning aid for
anyone learning C. The source is still my intellectual property so please don't
use it in any way that could be considered as abusing my good will!


Compiling
---------

DatUtil is compiled using MinGW but can also be compiled with DJGPP, CygWin or
Microsoft Visual C++ (and maybe other compilers too).
The executable is compressed using UPX v1.08.

To compile DatUtil, just use the makefile (i.e. type 'make' and press return).


Adding support for new formats
------------------------------

This should be really easy as you don't need to go anywhere near the guts of
DatUtil. All you need to write are two functions; one to identify a dat of the
new format and one to load it into memory (using macros I have provided). Once
they are written you will be able to use your newly added format just like any
other.

Take a look at the top of datutil.c and you will see something like this:

LOAD_SAVE_FORMAT(mame_listinfo, "MAME Listinfo", "LISTINFO", FULL_SUPPORT)
LOAD_ONLY_FORMAT(callus_gamelist, "Callus Gamelist", PARENT_SUPPORT)

const struct DatFormat *formats[] =
{
	FORMAT(mame_listinfo)
	FORMAT(callus_gamelist)
	0
};

I've stripped out the other formats for clarity but you should get the idea.
To add a new format you just need to declare a 'LOAD_ONLY_FORMAT' and add it to
the 'formats' structure.

e.g. adding support for 'rominfo.txt' of 'SuperEm' you may add:

LOAD_ONLY_FORMAT(superem_rominfo, "SuperEm RomInfo", 0)

const struct DatFormat *formats[] =
{
	...
	FORMAT(superem_rominfo)
	0
};

Now that DatUtil includes your new format you must write two C functions;
identify_superem_rominfo and load_superem_rominfo.

I would recommend looking at identify_callus_gamelist and load_callus_gamelist
first because they are simplest of all. Look at all of the formats to get an
idea of how to write these functions. I would keep away from the RomCenter
routines though as they are very specific and somewhat different to the others!

Don't worry about how they get run or where they store their data. All you need
know is that they do get run and the macros store the data as appropriate.

Good luck and let me have a copy of your endeavors please!

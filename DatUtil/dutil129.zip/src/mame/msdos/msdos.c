void logerror(char *msg, ...)
{
	/* MAME's unzip routines use this function but I don't */
}

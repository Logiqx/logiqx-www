>new.dat

for GAME in `grep 'name:' mamediff.2.log|sed 's/.*name: //'|sed 's/ .*//'|sed 's/].*//'`
do
	datutil -g $GAME -a new.dat "CPS-2 20020912.dat"
	datutil -g $GAME -a new.dat "Neo-Geo 20020501.dat"
done

rm -f datutil.dat datutil.log

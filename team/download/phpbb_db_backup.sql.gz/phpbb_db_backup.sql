#
# phpBB Backup Script
# Dump of tables for lac_xmb1
#
# DATE : 06-09-2005 10:52:47 GMT
#
#
# TABLE: phpbb_auth_access
#
DROP TABLE IF EXISTS phpbb_auth_access;
CREATE TABLE phpbb_auth_access(
	group_id mediumint(8) NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	auth_view tinyint(1) NOT NULL,
	auth_read tinyint(1) NOT NULL,
	auth_post tinyint(1) NOT NULL,
	auth_reply tinyint(1) NOT NULL,
	auth_edit tinyint(1) NOT NULL,
	auth_delete tinyint(1) NOT NULL,
	auth_sticky tinyint(1) NOT NULL,
	auth_announce tinyint(1) NOT NULL,
	auth_vote tinyint(1) NOT NULL,
	auth_pollcreate tinyint(1) NOT NULL,
	auth_attachments tinyint(1) NOT NULL,
	auth_mod tinyint(1) NOT NULL, 
	KEY group_id (group_id), 
	KEY forum_id (forum_id)
);

#
# Table Data for phpbb_auth_access
#

INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '12', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '3', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '12', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '14', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '15', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '6', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '3', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('4', '9', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '6', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '14', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '15', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('3', '9', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
#
# TABLE: phpbb_banlist
#
DROP TABLE IF EXISTS phpbb_banlist;
CREATE TABLE phpbb_banlist(
	ban_id mediumint(8) unsigned NOT NULL auto_increment,
	ban_userid mediumint(8) NOT NULL,
	ban_ip varchar(8) NOT NULL,
	ban_email varchar(255), 
	PRIMARY KEY (ban_id), 
	KEY ban_ip_user_id (ban_ip, ban_userid)
);

#
# Table Data for phpbb_banlist
#

INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('1', '54', '', NULL);
#
# TABLE: phpbb_categories
#
DROP TABLE IF EXISTS phpbb_categories;
CREATE TABLE phpbb_categories(
	cat_id mediumint(8) unsigned NOT NULL auto_increment,
	cat_title varchar(100),
	cat_order mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (cat_id), 
	KEY cat_order (cat_order)
);

#
# Table Data for phpbb_categories
#

INSERT INTO phpbb_categories (cat_id, cat_title, cat_order) VALUES('1', 'General', '10');
INSERT INTO phpbb_categories (cat_id, cat_title, cat_order) VALUES('2', 'Tools', '30');
INSERT INTO phpbb_categories (cat_id, cat_title, cat_order) VALUES('3', 'Data Files', '20');
#
# TABLE: phpbb_config
#
DROP TABLE IF EXISTS phpbb_config;
CREATE TABLE phpbb_config(
	config_name varchar(255) NOT NULL,
	config_value varchar(255) NOT NULL, 
	PRIMARY KEY (config_name)
);

#
# Table Data for phpbb_config
#

INSERT INTO phpbb_config (config_name, config_value) VALUES('config_id', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sitename', 'Logiqx');
INSERT INTO phpbb_config (config_name, config_value) VALUES('site_desc', 'Discussions relating to the sites, tools and data files created by Logiqx');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_name', 'phpbb2mysql');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_path', '/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_domain', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_secure', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('session_length', '3600');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html_tags', 'b,i,u,pre');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_bbcode', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_smilies', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_sig', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_namechange', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_theme_create', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_local', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_remote', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_upload', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('enable_confirm', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('override_user_style', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('posts_per_page', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('topics_per_page', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('hot_threshold', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_poll_options', '10');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sig_chars', '255');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_inbox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sentbox_privmsgs', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_savebox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_sig', 'Note: This e-mail address is not monitored so there is not point replying to this e-mail. Your response will not be seen!');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email', 'phpbb@logiqx.com');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_delivery', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_host', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_username', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_password', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sendmail_fix', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('require_activation', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('flood_interval', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_form', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_filesize', '6144');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_width', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_height', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_path', 'images/avatars');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_gallery_path', 'images/avatars/gallery');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smilies_path', 'images/smiles');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_style', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_dateformat', 'D M d, Y g:i a');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_timezone', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('prune_enable', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('privmsg_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('gzip_compress', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_fax', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_mail', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_users', '6');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_date', '1122967364');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_name', 'www.logiqx.com');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_port', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('script_path', '/forum/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('version', '.0.13');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_startdate', '1112905709');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_lang', 'english');
#
# TABLE: phpbb_disallow
#
DROP TABLE IF EXISTS phpbb_disallow;
CREATE TABLE phpbb_disallow(
	disallow_id mediumint(8) unsigned NOT NULL auto_increment,
	disallow_username varchar(25) NOT NULL, 
	PRIMARY KEY (disallow_id)
);
#
# TABLE: phpbb_forums
#
DROP TABLE IF EXISTS phpbb_forums;
CREATE TABLE phpbb_forums(
	forum_id smallint(5) unsigned NOT NULL,
	cat_id mediumint(8) unsigned NOT NULL,
	forum_name varchar(150),
	forum_desc text,
	forum_status tinyint(4) NOT NULL,
	forum_order mediumint(8) unsigned DEFAULT '1' NOT NULL,
	forum_posts mediumint(8) unsigned NOT NULL,
	forum_topics mediumint(8) unsigned NOT NULL,
	forum_last_post_id mediumint(8) unsigned NOT NULL,
	prune_next int(11),
	prune_enable tinyint(1) NOT NULL,
	auth_view tinyint(2) NOT NULL,
	auth_read tinyint(2) NOT NULL,
	auth_post tinyint(2) NOT NULL,
	auth_reply tinyint(2) NOT NULL,
	auth_edit tinyint(2) NOT NULL,
	auth_delete tinyint(2) NOT NULL,
	auth_sticky tinyint(2) NOT NULL,
	auth_announce tinyint(2) NOT NULL,
	auth_vote tinyint(2) NOT NULL,
	auth_pollcreate tinyint(2) NOT NULL,
	auth_attachments tinyint(2) NOT NULL, 
	PRIMARY KEY (forum_id), 
	KEY forums_order (forum_order), 
	KEY cat_id (cat_id), 
	KEY forum_last_post_id (forum_last_post_id)
);

#
# Table Data for phpbb_forums
#

INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('1', '1', 'Announcements', 'News and upcoming releases from Logiqx', '0', '10', '15', '12', '130', NULL, '0', '0', '0', '3', '1', '1', '1', '3', '3', '1', '3', '3');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('3', '2', 'DatUtil, MAMEDiff and ImgChk', 'DatUtil and MAMEDiff are my data file creation/conversion and comparison tools. ImgChk verifies image collections against any format datafile.', '0', '10', '14', '4', '123', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('6', '2', 'ROMBuild, ROMInfo and ZIPIdent', 'Tools for ROM identification and manipulation', '0', '20', '2', '2', '38', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('9', '2', 'DatLib', 'Core to all of my tools it provides data file loading, cleansing, conversion and saving routines', '0', '40', '2', '2', '122', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('12', '3', 'ClrMamePro Dats', 'Questions relating to the CMPro data files at www.logiqx.com', '0', '10', '37', '7', '136', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('15', '1', 'CAESAR / General', 'For discussions about CAESAR, arcade emulation and/or to tell us about releases and other news', '0', '40', '55', '20', '138', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('14', '3', 'RomCenter Dats', 'Questions relating to the RomCenter data files at www.logiqx.com', '0', '30', '7', '3', '121', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
#
# TABLE: phpbb_forum_prune
#
DROP TABLE IF EXISTS phpbb_forum_prune;
CREATE TABLE phpbb_forum_prune(
	prune_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(5) unsigned NOT NULL,
	prune_days smallint(5) unsigned NOT NULL,
	prune_freq smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (prune_id), 
	KEY forum_id (forum_id)
);
#
# TABLE: phpbb_groups
#
DROP TABLE IF EXISTS phpbb_groups;
CREATE TABLE phpbb_groups(
	group_id mediumint(8) NOT NULL auto_increment,
	group_type tinyint(4) DEFAULT '1' NOT NULL,
	group_name varchar(40) NOT NULL,
	group_description varchar(255) NOT NULL,
	group_moderator mediumint(8) NOT NULL,
	group_single_user tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (group_id), 
	KEY group_single_user (group_single_user)
);

#
# Table Data for phpbb_groups
#

INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('1', '1', 'Anonymous', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('5', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('3', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('4', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('6', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('7', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('8', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('9', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('10', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('11', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('12', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('13', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('14', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('15', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('16', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('17', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('18', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('19', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('20', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('21', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('22', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('23', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('24', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('25', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('26', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('27', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('28', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('29', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('30', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('31', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('32', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('33', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('34', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('35', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('36', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('37', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('38', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('39', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('40', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('41', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('42', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('43', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('44', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('45', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('46', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('47', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('48', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('49', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('50', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('51', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('52', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('53', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('54', '1', '', 'Personal User', '0', '1');
#
# TABLE: phpbb_posts
#
DROP TABLE IF EXISTS phpbb_posts;
CREATE TABLE phpbb_posts(
	post_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	poster_id mediumint(8) NOT NULL,
	post_time int(11) NOT NULL,
	poster_ip varchar(8) NOT NULL,
	post_username varchar(25),
	enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	enable_html tinyint(1) NOT NULL,
	enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	enable_sig tinyint(1) DEFAULT '1' NOT NULL,
	post_edit_time int(11),
	post_edit_count smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (post_id), 
	KEY forum_id (forum_id), 
	KEY topic_id (topic_id), 
	KEY poster_id (poster_id), 
	KEY post_time (post_time)
);

#
# Table Data for phpbb_posts
#

INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('8', '8', '14', '3', '1112999523', 'd92c6ed8', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('4', '4', '15', '3', '1112912141', 'd92c6ed8', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('5', '5', '12', '3', '1112912200', 'd92c6ed8', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('12', '11', '14', '9', '1113262181', 'cb264b25', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('7', '7', '1', '3', '1112912388', 'd92c6ed8', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('11', '10', '15', '4', '1113250486', '53d5305f', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('13', '11', '14', '3', '1113292490', 'd92c6ed8', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('14', '12', '15', '4', '1113408729', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('15', '10', '15', '3', '1113420008', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('16', '13', '1', '3', '1113420068', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('17', '10', '15', '4', '1113425121', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('18', '14', '15', '14', '1113514182', '43a642de', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('19', '14', '15', '3', '1113549886', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('20', '14', '15', '4', '1113559108', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('21', '12', '15', '16', '1113858072', 'd52a020b', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('22', '12', '15', '4', '1113863442', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('23', '15', '9', '4', '1114001881', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('24', '16', '15', '4', '1114267323', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('25', '16', '15', '3', '1114297662', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('26', '16', '15', '4', '1114316251', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('27', '17', '12', '20', '1114635760', '88b602dd', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('28', '17', '12', '4', '1114638224', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('29', '17', '12', '20', '1114640456', '88b602dd', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('30', '17', '12', '3', '1114674481', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('31', '18', '15', '4', '1115146949', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('32', '19', '1', '3', '1115497456', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('33', '16', '15', '7', '1115799474', '3eaccf5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('34', '16', '15', '4', '1115827378', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('35', '16', '15', '7', '1115851723', 'd92b194b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('36', '16', '15', '4', '1115886622', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('37', '20', '6', '25', '1116171568', '43a4d0f9', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('38', '20', '6', '4', '1116180787', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('39', '21', '3', '26', '1116369124', 'a253da2e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('40', '21', '3', '3', '1116402777', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('41', '21', '3', '26', '1116467447', 'a253da2e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('42', '22', '15', '29', '1117002358', 'd31cc834', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('43', '22', '15', '4', '1117007005', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('44', '22', '15', '3', '1117094027', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('45', '22', '15', '4', '1117096598', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('46', '22', '15', '29', '1117097409', 'd31cc834', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('47', '22', '15', '3', '1117102555', 'c29f1fa5', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('48', '23', '3', '31', '1117223179', 'd8aa8a54', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('49', '23', '3', '3', '1117263239', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('50', '23', '3', '4', '1117272915', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('51', '23', '3', '3', '1117288112', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('52', '23', '3', '31', '1117510617', '18a6885c', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('53', '24', '15', '32', '1117809249', 'ce7b044a', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('54', '24', '15', '4', '1117809793', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('55', '24', '15', '32', '1117811216', 'ce7b044a', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('56', '25', '1', '3', '1118093293', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('57', '25', '1', '3', '1118176006', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('58', '26', '15', '4', '1118511919', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('59', '27', '12', '34', '1118580023', 'a66f40b0', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('60', '27', '12', '4', '1118592714', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('61', '27', '12', '3', '1118596654', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('62', '27', '12', '34', '1118604691', 'a66f40b0', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('63', '27', '12', '4', '1118606207', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('64', '27', '12', '3', '1118607304', 'd92c6ed8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('65', '27', '12', '4', '1118651396', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('66', '27', '12', '3', '1118656568', 'c29f1fa5', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('67', '28', '15', '4', '1119453086', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('68', '28', '15', '7', '1120071913', '519bd4cf', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('69', '28', '15', '4', '1120078055', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('70', '29', '15', '41', '1120140689', 'c050374a', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('71', '29', '15', '4', '1120148908', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('72', '29', '15', '41', '1120152135', 'c0503749', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('73', '29', '15', '4', '1120215311', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('74', '31', '1', '4', '1121117395', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('75', '31', '1', '34', '1121241176', 'a66f40b0', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('76', '31', '1', '3', '1121461092', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('77', '32', '12', '45', '1121474606', '45eae05a', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('78', '33', '3', '46', '1121593900', '52382853', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('79', '33', '3', '3', '1121627731', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('80', '32', '12', '3', '1121628179', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('81', '33', '3', '46', '1121683608', '50b41df4', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('82', '33', '3', '3', '1121684815', 'c29f1fa5', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('83', '33', '3', '46', '1121710984', '52322bac', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('84', '34', '15', '34', '1122001000', 'a66f40b0', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('85', '35', '15', '47', '1122277699', '5414a914', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('86', '36', '12', '48', '1122680833', '52fe9ed1', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('87', '37', '1', '3', '1122718139', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('88', '38', '15', '3', '1122718186', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('89', '38', '15', '4', '1122721301', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('90', '38', '15', '3', '1122721632', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('91', '36', '12', '3', '1122798243', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('92', '36', '12', '48', '1122817790', '52fe9ed1', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('93', '38', '15', '5', '1122833285', '53869611', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('94', '27', '12', '3', '1122838300', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('95', '36', '12', '3', '1122838339', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('96', '39', '15', '3', '1122838669', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('97', '38', '15', '4', '1122900894', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('98', '40', '12', '49', '1122967936', '428a4943', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('99', '40', '12', '3', '1123005669', '56822b66', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('100', '40', '12', '4', '1123011303', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('101', '41', '15', '4', '1123089979', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('102', '42', '1', '3', '1123492506', 'c29f1fa5', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('103', '43', '15', '4', '1123845823', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('104', '44', '1', '3', '1124405718', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('105', '40', '12', '49', '1124415474', '445e4c53', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('106', '40', '12', '49', '1124416268', '445e4c53', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('107', '39', '15', '23', '1124428344', '1898daee', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('108', '40', '12', '3', '1124437928', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('109', '39', '15', '3', '1124438346', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('110', '40', '12', '49', '1124496474', '428c3ff3', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('111', '40', '12', '23', '1124598455', '1898daee', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('112', '39', '15', '23', '1124608924', '1898daee', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('113', '39', '15', '3', '1124615033', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('114', '45', '14', '51', '1124827102', 'd92bafe8', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('115', '46', '12', '49', '1124830420', '428db06a', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('116', '46', '12', '49', '1124905291', '41427e32', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('117', '45', '14', '4', '1124917319', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('118', '46', '12', '3', '1124925268', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('119', '45', '14', '3', '1124925635', '56822d5e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('120', '46', '12', '49', '1124950432', '41436686', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('121', '45', '14', '3', '1125388121', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('122', '47', '9', '3', '1125519456', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('123', '48', '3', '3', '1125519583', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('124', '46', '12', '3', '1125519629', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('125', '49', '1', '3', '1125519686', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('126', '50', '1', '3', '1125519715', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('127', '46', '12', '49', '1125719822', '428a4962', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('128', '46', '12', '3', '1125757522', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('129', '51', '1', '3', '1125757588', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('130', '52', '1', '3', '1125757644', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('131', '53', '15', '3', '1125757843', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('132', '54', '15', '49', '1125890667', '428db05e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('133', '54', '15', '3', '1125906528', '5682290e', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('134', '54', '15', '4', '1125915234', '53d5305f', '', '0', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('135', '36', '12', '48', '1125924358', '52fe99a3', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('136', '36', '12', '4', '1125929468', '53d5305f', '', '1', '1', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('137', '54', '15', '49', '1125940566', '4144cc5c', '', '1', '1', '1', '1', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('138', '55', '15', '49', '1125967923', '428db346', '', '1', '1', '1', '1', NULL, '0');
#
# TABLE: phpbb_posts_text
#
DROP TABLE IF EXISTS phpbb_posts_text;
CREATE TABLE phpbb_posts_text(
	post_id mediumint(8) unsigned NOT NULL,
	bbcode_uid varchar(10) NOT NULL,
	post_subject varchar(60),
	post_text text, 
	PRIMARY KEY (post_id)
);

#
# Table Data for phpbb_posts_text
#

INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('8', '4499a7bad1', 'Do not ask where to find ROMs. No ROM Requests!', 'Thank you!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('4', '2fe576dbe2', 'Do not ask where to find ROMs. No ROM Requests!', 'Thank you!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('5', 'fd553f7e8d', 'Do not ask where to find ROMs. No ROM Requests!', 'Thank you!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('7', 'decf843f5c', 'New Forums', 'There are lots of new forums available here for the discussion of things relating to Logiqx.com. Hopefully they will prove useful!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('13', '3ba4c00830', '', 'They\'re all online here. There is a link on the MAME data file page that says \'older versions are still online\'. It was broken earlier but fixed now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('11', 'a34fdb58f6', 'Pacifi 3D new version...', '...And I\'ve not tried it yet. [url=http://pacifi3d.retrogames.com/]Pacifi3D home[/url].');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('12', 'e2c42788fb', 'Chasing dat file for MAME v0.84', 'I am chasing a MAME v.0.84 dat file in Romcentre format.  A file in ClrMamePro format would even do.  Does anyone know where you can find dat files for older versions of MAME.  (I don\'t have a copy of MAME0.84, so I can\'t use the -listinfo, -listxml function)

Replys appreciated');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('14', '', 'It\'s getting dangerous', 'We have more registered users than posts made :mrgreen:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('15', '8f6566b9d0', '', 'I\'ve just released update data files for it.  :)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('16', '8b3c335484', 'Pacifi3D v0.3', 'Updated data files are now available.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('17', '', '', 'If you think that new datafiles are a way of encouraging me to try it... Well, I haven\'t updateth for Mameth 95... Does that give you any clue?  :roll:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('18', 'a70318b520', 'Help me with this compelling idea!', 'First, I just registered to ask you guys this question, and I hope I\'m in the right spot and not just going to embarrace myself (I don\'t know anything about emulation, I just collect arcade stuff), but here\'s what\'s on my mind-

A Playstation emulator, designed to run on the Taito G-net hardware

There you go. I want to play playstation games on the G-net.  It\'s similar to the playstation, right?  And it uses those standardised computer cards for the roms, right, so I thought maybe it would be possible to store the roms and the emulator on the card and have a perfectly working Einhander or R-type Delta to play on the arcade machine.
And I\'m sure you guys understand that I just want carts of my favorite games- not interested in just hooking up a playstation to the cabinet.
  Of course, maybe you could fit a few games on one cart?

Am I way off the mark, or is it possible?  How much work would be involved if it was possible? Surely you could just use the playstation rom and the emulator could tell the info where to go and what to do (thus, it all makes sense in my ignorant brain).  Good idea, huh?
Thanks so much if you can offer any help.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('19', '50d6cbb90f', '', 'That\'s an interesting idea but I don\'t think it is viable. Emulators require huge amounts of processing power to emulate a machine and typically the emulation requires at least 10 times the power of the original machine to run at full speed (this is my own rough approximation and must consider combined cpu, sound and graphics power).

Converting a game from one system to a similar system is a more likely possibility but that is not something that I know about. I don\'t mean porting either, I mean hacking something together to get it running as a virtual machine or simple bootleg (if they are identical hardware but that is very unlikely, no matter how similar they seem on the surface).

Anyway, I don\'t actually know anything about Taito\'s G-Net hardware and the viability of it running Playstation games. My gut reaction is that it is unlikely to be possible no matter how similar they are (for one the game is going to want to load from a CD which is rather different to addressing memory in a ROM). What is certain is that it would be a huge amount of work and it is also unlikely that anyone other than Taito has the required documentation to write any substantial programs on the G-Net hardware.

If you want further opinions on the idea, try the general message board at Retrogames because there are emulator developers there who will know more about the internals of both systems.

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('20', '', 'Re: Help me with this compelling idea!', 'Another thing to consider is that you\'d need a G-Net SDK (Software Development Kit). I\'m sure that will be the biggest problem. Taito will not allow anyone to develop games to their own platform without paying some fees to them.

Just look at the NeoGeo case, it was a very very popular platform, but there are almost no homebrew games and the ones made are quite simple. Just because there\'s no NeoGeo SDK publically available. And making something as complex as an emulator without that SDK will be very hard, even if the G-Net hardware is capable of emulating or mimicing a Playstation.

Another thing to take into account is the fact that making an emulator for this system will mean an easy and good solution for bootlegging PS games and use them in arcades, and I can tell you that most devs would frown upon this thought.

So I know it\'s not the solution you wanted, but hooking a Playstation to the cabinet will be your solution. You can make it better if you can hack up a connector to use the JAMMA controls with the Playstation, then you wouldn\'t notice the difference between using an emulator or the real PS.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('21', 'e2b85492ae', '', ':D  8)  :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('22', '', '', 'Smiley-only and NT posts don\'t count. Yet.  :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('23', '', 'Core for a rom manager?', 'I\'m kind of surprised no one took DatLib and used it as the core for a new rom manager. I guess CMP is daunting, and it\'ll take a lot of effort to have anything as good as CMP is now.

 :roll:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('24', '', 'As a moderator, I check these boards several times a day...', '...So please, give me some work  :lol:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('25', '0a9859e2b7', '', 'So, you\'re the one using all of the bandwidth and costing me money then. ;)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('26', '', '', 'Probably yes. I\'m tempted to post some pr0n to attract more visitors. Fancy some Chloe Jones?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('27', '84b91fdc18', 'Is there a place to find old MAME DATs?', 'Thanks');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('28', '11479a6cb3', '', 'Yes, in Logiqx\'s site, in the MAME dats page, look where it says \"previous dats still online\" and you\'ll find all dats back to 0.36:
[url]http://www.logiqx.com/Dats/MAMEBeta/MAMEBetaHistory.shtml[/url]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('29', '0b8cd69498', 'Is there a place to find old MAME DATs?', 'Thanks for the quick response. 

However, I hate to be a pain in the ass but I went to the main Dats screen and I don\'t see the \"previous dats still online\" link.  Has the page changed and under a different heading now.  The page I am viewing is http://www.logiqx.com/Dats/Dats.shtml');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('30', '7aecf3cb38', '', 'From the page you are on, click \'MAME\' to show the MAME data file page or just click the link that Pi supplied (above).');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('31', 'cb724e1a52', 'MAME 0.96', 'It\'s out, for you to play with it. Besides Boogie Wings, it\'s the first release with the new BSD-based license. I wonder if RB will end making jokes about this license too. Eventually  :D 

(Maybe RB will join these boards just to kill me, eventually too.)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('32', 'fd74c16b69', 'MAME v0.96', 'I have finally uploaded the MAME v0.96 updates to logiqx.com.

It\'s been a busy week but better late than never!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('33', 'fe341fbf4c', '', 'If you post 8-bit pr0n you\'ll have me checking several times per day =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('34', '', '', 'Now what was the URL for that site which kept 8-bit porn game pics?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('35', '210b37705c', '', 'Thanks to Twisty for this one:  http://girls.c64.org/

Anything similar for other formats?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('36', '', '', 'Closest I have seen is MamEnd which has image galleries for porn arcade games. Several contributed by me  :lol: 

http://emulazione.multiplayer.it/mamend/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('37', 'e341340b9a', 'So does ROMBuild do Zinc anymore?', 'I noticed that in the release notes that it was removed, with a note regarding being superseded.  What does this mean?  Does this mean it is not there anymore?

Thanks.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('38', '', '', 'Right now, the roms in MAME and ZiNc are exactly the same. Same set and rom names and same crc\'s. Since there are no rom differences, ROMBuild doesn\'t need to rebuild anything. That\'s why ROMBuild doesn\'t do anything ZiNc related now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('39', '881f7265ab', 'MameDiff Question', 'I am trying to create a ClrMamePro DAT file so I can have a \"Diff\" directory for only the roms that differ between two sets. In this case, I have a full set of 0.96 ROMS and a collection of zips that represent all the ROMS that have been \"removed\" since MAME began. I would like to generate the \"Diff\" directory for Roms needed, in addition to the ones I have in my 0.96 directory, to run Kaillera Mame (i.e. 0.67). Is this the correct command I need so that I have a ClrMamePro DAT file that can create this romset (split sets): 

[code:1:881f7265ab]mamediff -v -s -d1 mame67.xml mame96.txt[/code:1:881f7265ab]

Thanks!

-Jerry');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('40', '7ea8ba556a', '', 'Ok, 3 points that I can see:

1) You don\'t need the -v option because that doesn\'t relate to the -dX options. It won\'t do anything (or worse still, MAMEDiff may refuse to do anything because you are giving it conflicting actions) so take it out of your command line.

2) Your filenames should be turned the other way around (i.e. 0.96 should be first, then 0.67) because you want a backwards supplement.

3) Last point, you should use -d3 (or -d2, but -d3 would be best) so that you create a supplement and not complete ZIPs. The -d1 option would create loads of unnecessary ZIPs if ROMs have been added since 0.67 and that would be pointless. -d3 will only create ZIPs containing the minimum number of ROMs required (i.e. ROMs that have since been changed or removed).

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('41', '1e174e2b5d', '', 'hehe I knew I wasn\'t going to get lucky on the first try :)

Thanks a ton!

-Jerry');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('42', '9a87cece2e', 'Double Dragon(Neo Geo)', 'Hi. 

I have the double dragon(neo geo) rom for NeorageX. I can\'t get it to work on MAME or any other emulators that I have tried. Could someone please teach me how to get it to work? (if it\'s possible)

Thank you.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('43', '', '', 'The roms used by NeoRageX were incorrect for MAME, ranging from bad dumps or bitswaps, to dumps from home carts. Over the time, these dumps have been corrected and now MAME uses the good arcade dumps. In most cases, NeoRageX roms differ and don\'t work. So you need to get the dumps that MAME needs. 

Some of these bad dumps can be converted to the MAME roms, but I\'m almost certainly sure that Double Dragon can\'t be, so you\'ll have to find it again.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('44', 'a28918b668', '', 'That game happens to be one of the few that are compatible with all emulators. The ZIP name should be the same (doubledr.zip) and the ROMs are identical, just the filenames inside the ZIP different (loading by CRC will mean that any name works though):

ddrag_c1.rom            082-c1.bin              IDENTICAL
ddrag_c2.rom            082-c2.bin              IDENTICAL
ddrag_c3.rom            082-c3.bin              IDENTICAL
ddrag_c4.rom            082-c4.bin              IDENTICAL
ddrag_c5.rom            082-c5.bin              IDENTICAL
ddrag_c6.rom            082-c6.bin              IDENTICAL
ddrag_c7.rom            082-c7.bin              IDENTICAL
ddrag_c8.rom            082-c8.bin              IDENTICAL
ddrag_m1.rom            082-m1.bin              IDENTICAL
ddrag_p1.rom            082-p1.bin              IDENTICAL
ddrag_s1.rom            082-s1.bin              IDENTICAL
ddrag_v1.rom            082-v1.bin              IDENTICAL
ddrag_v2.rom            082-v2.bin              IDENTICAL

Check the ROMs that you have with ClrMamePro or RomCenter.

Either you have the ZIP named incorrectly, you have an incorrect/missing neogeo.zip, you have a bad doubledr.zip or you\'re using MAME incorrectly.

You will find all of the tips that you need at http://www.mameworld.net/easyemu

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('45', '', '', 'Oops  :roll:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('46', '598955befa', '', 'Thanks for all your replies.

I just tried it with winkawak, it says i\'m missing 030-p.bin (d396c9cb).

I already have 2 neogeo zip in the folder though....');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('47', 'bab672e687', '', 'That particular ROM is from 2020 Super Baseball and is nothing to do with Double Dragon.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('48', '92534c2f06', 'mamediff tab delim layout', 'I want to verify the layout of the tab delimitted file.
If the first column is different from the second column it\'s a rom rename?
If the second column is blank it is a rom no longer supported in the newer version?
If the first column is blank it is a new rom?
If the columns are the same now difference in name changes?

If this is true this will make updating the controls.dat database MUCH easier :)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('49', '453f7fa6db', '', 'Yes, all of your statements are correct.

I\'m not sure that many people don\'t actually know it\'s there either... I added it to make the CAESAR maintance easier for myself. :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('50', '', '', 'Well, I didn\'t know that was in MameDiff, and supossedly I betatested it  :roll:  Btw this week I found the testing folder and wiped it out, it was 1.2gb of data files...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('51', 'a7df477dc5', '', 'Just regard it as an easter egg. There are probably a few more within my tools. ;)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('52', '7028fb2e1b', '', 'sweetness.  Makes really easy to create SQL statements to update my database now :)  thanks alot.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('53', '1a160d3206', 'mx27l1000.u14 file', 'I\'m trying to dowload the rom \"The crystal of the kings\" for mame but the game doesn\'t want to run. The file mx27l1000.u14 IS MISSING. PLEASE help me to find it.

THANKZ');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('54', '', '', '1. You can\'t ask for roms here.
2. You need the bios for that system, it\'s crysbios.zip.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('55', '96c3a73d8d', 'SORRY', 'I\'m REALLY SORRY for thr ROM asking... And THANK YOU VERY MUCH for your help.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('56', '47108365a1', 'MAME v0.97', 'Released data files for MAME and CPS-2.

Also updated the supplements for emulators supporting sfz3a (which was renamed in MAME v0.97).');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('57', 'a1e4933fcc', '', 'I have now updated the CAESAR for MAME v0.97 too.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('58', '', 'Hello, is anybody there?', 'Ooops, gotta keep it on topic... RAINE rules!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('59', 'd2eba2748a', 'An sha1 mistake about uni-bios in NeoGeo data for cm?', 'resource (
	name uni-bios
	description \"UNIVERSE BIOS (v1.0 to v2.0, non-MAME)\"
	year 2004
	manufacturer \"CPS2Shock\"
	rom ( name uni-bios.rom size 131072 crc 0c12c2ad sha1 eca8851d30557b97c309a0d9f4a9d20e5b14af4e )
	rom ( name uni-bios.13 size 131072 crc b24b44a0 sha1 eca8851d30557b97c309a0d9f4a9d20e5b14af4e )
	rom ( name uni-bios.12 size 131072 crc 4fa698e9 sha1 682e13ec1c42beaa2d04473967840c88fd52c75a )
	rom ( name uni-bios.11 size 131072 crc 5dda0d84 sha1 4153d533c02926a2577e49c32657214781ff29b7 )
	rom ( name uni-bios.10 size 131072 crc 0ce453a0 sha1 3b4c0cd26c176fc6b26c3a2f95143dd478f6abf9 )
)

the \"uni-bios.rom\" is version 2.0, but have sha1 as same as version 1.3. I think 2.0 should be 37bcd4d30f3892078b46841d895a6eff16dc921e?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('60', '', '', 'Probably a copypaste error. Logiqx will probably fix it when he includes the very new version 2.1. I think he hasn\'t noticed about it yet. (Specially because I\'ve not posted it at CAESAR.)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('61', '1d7e83c52f', '', 'Thanks for mentioning the SHA1 error and the existence of a new version too. I\'ll include the details in the next update.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('62', '1cdc076bf3', '', 'Thanks, Pi and Logiqx.
And another SHA1 copypaste error in ZiNc v1.1 data I think... I am doing a big tidying job for my friend\'s whole collection today...

game (
	name souledga
......
	rom ( name so1sprg.6d size 262144 crc f6f682b7 sha1 4168a9aa525f1f0ce6cf6e14cfe4c118c4c0d773 region cpu2 )
......
)
game (
	name souledgb
......
	rom ( name so1sprg.6d size 262144 crc f6f682b7 sha1 4168a9aa525f1f0ce6cf6e14cfe4c118c4c0d773 region cpu2 )
......
)
game (
	name souledge
......
	rom ( name so1sprc.6d size 262144 crc 2bbc118c sha1 4168a9aa525f1f0ce6cf6e14cfe4c118c4c0d773 region cpu2 )
......
)

Maybe the former two\'s SHA1 should be a64e19be3f6e630b8c34f34b46b95aadfabd3f63, but I am not very sure.

BTW, I hope my way to report errors is appropriate. I am new here, so if it is not proper please let me know:) Thanks again.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('63', '', '', 'Actually it\'s souledga and souledgb the ones who should change the SHA1 of that rom so1sprg.6d to a64e19be3f6e630b8c34f34b46b95aadfabd3f63. That\'s how it\'s in a MAME generated dat.

I don\'t remember how the dat for ZinC it\'s generated, so it might be another copypaste error. I have checked these games with CRC and SHA1 together with a dat from MAME and there was no error. I guess a similar check with ZinC\'s dat would give some kind of error. Lazy to check it by myself...

I also remember MameDiff\'ing MAME vs ZinC to see if their games where the same, and there was no difference. Maybe MameDiff only relies on the CRC? Don\'t remember that either.

Alzheimer 2 - Pi 1. I lose 
 :lol:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('64', '28ef93ab5c', '', 'The ZiNc dat is hand created and compared against the ZiNc \'listsets\' output using MAMEDiff.

The reason for that error was the above mentioned ROMs being interchanged between ZiNc versions and I must have forgotten to update the SHA1s as well as the names+CRCs.

I rarely use CMPro with SHA1 functionality switched on so now and then there may be SHA1 errors in the data files that I didn\'t spot. Letting me know about them is a good thing because it means they will get corrected. Keep me informed of these things please.

Regarding MAMEDiff, it doesn\'t compare SHA1s... only CRCs. For that matter, all of my consistency checks are CRC based (since SHA1 is mainly of use to detect \'faked CRC\' ROMs). SHA1 values are therefore the most likely thing to slip through my quality control procedures. ;)

Thanks, Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('65', '', '', '[quote=\"Logiqx\"]Regarding MAMEDiff, it doesn\'t compare SHA1s... only CRCs. For that matter, all of my consistency checks are CRC based (since SHA1 is mainly of use to detect \'faked CRC\' ROMs). SHA1 values are therefore the most likely thing to slip through my quality control procedures. ;)
[/quote]

Then add SHA1 comparison to MameDiff, add it to the to-do list... If the notepad can edit such a big file :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('66', '4d33816ca5', '', 'Nope, that\'s too low down on my priorities to even make the todo list. :p');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('67', 'a9b7fab1ad', 'Well, at least there\'s something positive...', '...And it\'s that this forum doesn\'t seem to be infested by trolls, bloody n00bs, know-more-than-you jerks, warez kiddiez and other internet pests  :lol: 

I hereby declare this board as higienical and healthy :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('68', 'f0cc327a87', '', 'But is that a good or a bad thing. Is there such a thing as too much clean living? I wouldn\'t know.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('69', 'fc46249121', '', 'Yes, there\'s such a thing. Too bad many people come here and read the posts (just look at the thread views numbers!) and no one just say something. You know to keep the boards alive, after all Logiqx did all this with some effort.

And I want to ban someone  :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('70', 'ef4abc78a3', 'Confusion about ROM updates', 'So I downloaded PALM MAME and to my dismay discovered that none of the ROMs I have are recognized. The documentation states that it requires all ROMs to be in MAME 0.36 format. I have successfully used these ROMs on MAME32 0.31.1, but haven\'t used them for a while. The \"ROMs\" are mostly binary files that have no particular extension, though some are .BIN. They don\'t generally follow any particular pattern of naming (some are gamename.01 .02, etc., others not).

From what I could determine online, it appears that newer versions of MAME require ROM updates. I confess I don\'t understand the concept of ROM updates. My impression was that the ROMs were literally dumps from the EEPROMs in the arcade machines.

That said, the existing programs for reverting \"new\" MAME ROMs back to the older 0.36 format expect a .dat file as its input. I have the reverse problem. My ROMs work for MAME 0.31, but they are most definitely not .dat files.

So the question is, how do I go [i:ef4abc78a3]forward [/i:ef4abc78a3] to MAME 0.36 (presumably .dat) format?

I hope I picked the right forum.  Apologies if not (redirects appreciated!)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('71', 'ffc96b16f9', '', 'You\'re confusing a few things, I\'ll try to explain this stuff properly.

Yes, PalmMame needs the roms for the 0.36 version of MAME, because that\'s the version that the port author used as a base (old versions had much lower requirements). Yes, the roms change between MAME versions; there are many reasons, all of them explained in the MAME FAQ, but to name a few:
* Dumps are not always correct, so roms need a redump.
* Certain roms are undumpable under certain circumstances so when they\'re dumped, the game roms get updated.
* Old dumps didn\'t include proms, so when they are dumped they are added to the game, thus changing the sets again...
* Documentation might change parent-clone relationships, rom filenames, or any other minor change which might make a need to change again the roms.

So to manage all these rom updates, people use the so called \"Rom Managers\". A popular one is ClrMamePro. These rom managers need the information of which roms and with which filenames and contents each game needs, and that information is called a datfile (the ones with .dat extension). So to update/downdate your roms, you need to use a datfile which holds the information for a certain MAME release. If you want to update to latest MAME, you need a .dat for version 0.97. If you want to downgrade to 0.36 (or update from 0.31 in your case) then you need a datfile for 0.36.

Once loaded the datfile in the rom manager, it will scan your rom folders and tell you what do you have and what are you missing. I have to tell you that many many games can be used interchangeably from old versions to new ones, but at the same time, many roms have changed, bad dumps were replaced with good dumps, so rebuilding 0.36 from a recent 0.97 set is kind of hard. If you\'re rebuilding from 0.31 you\'ll be missing lots of stuff too (for once, all the games added from that version and 0.36).

I think that\'s all you need. Not so long ago I prepared a 0.36 romset for a friend and his Palm (but never used because he couldn\'t make it work), and I remember there were lots of stuff missing. I can\'t tell you where to find the missing roms (and don\'t ask), but Google is your friend, people still use 0.36 sets...

A 0.36 datfile (cm is for ClrMamePro, RC is for another rom manager):
http://www.logiqx.com/Dats/MAMEBeta/MAMEBetaHistory.shtml

The rom manager (with a board for help in case you don\'t get it with its own documentation):
http://www.clrmame.com/

Shock treatment tutorials for MAME, ClrMAME and stuff:
http://www.mameworld.net/easyemu/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('72', 'ea5f784f6d', 'Thanks', 'Thanks for the education.  I did get it working correctly for at least one game, but for some of the others, while ClrMamePro claimed I had complete sets for v.0.36, and it created .zip files for me, PALM MAME wouldn\'t run them.  But this was a big help, thanks.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('73', '', '', 'PalmMAME doesn\'t run all the games from MAME 0.36, so you\'ll have to check its compatibility list, regardless of if you have the right roms or not.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('74', 'c45f5ec00b', 'MAME 0.98', 'And Logiqx is back so we can expect some dats as soon as he recovers from the jet lag, approximately about July 20th or so :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('75', '0a533b062b', '', 'Oh yeah');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('76', 'f91a53dadb', '', 'Ok, they\'re online now. It\'s taken me a while to get back into things after a fortnight of nothingness. ;)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('77', '7ca43df8d1', 'Looks like you forgot the CPS2 dats.....', 'Thought you\'d want to know that the CPS2 dats need updating, seeing how the Choko set has changed in the latest MAME.

Sorry to be the one to tell you that after all your hard work today you\'re still not done, betcha it makes you wish you were still on vacation huh? :p');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('78', '3e92e49a8b', 'datutil truncates descriptions?', 'i have a Romcenter Dat with this gamename:

2 Games in 1 - SpongeBob SquarePants - SuperSponge + SpongeBob SquarePants - Revenge of the Flying Dutchman (E)

it\'s the longest filename of that dat.
converting it to CLRMAME format using datutil, it cuts the description to

2 Games in 1 - SpongeBob SquarePants - SuperSponge + SpongeBob SquarePants - Revenge of the Flying D

any solution? is this a problem of Datutil or of CLRMAME file format?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('79', '1ef033f106', '', 'DatUtil v2.0 and onwards doesn\'t have any limits on string lengths. What version of DatUtil are you using?

Is the dat somewhere on the web so that I can download it and see what is going on?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('80', '335e301569', '', 'Thanks. I noticed that the CRC and SHA1 information had been removed but forgot to upload a new data file. Online now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('81', 'fb6afd7982', '', 'yep, it was a bit stupid not reporting the version i used and withouth checking for newer versions.
atm im not at home, ill check with 2.0, sorry for the noob question  :oops:  :wink: 
anyway, dat is here: 
http://www.gbadat.altervista.org/gbadat/dats/Nintendo%20Game%20Boy%20Advance%20(2057).zip
(if download doesnt work, copy the link in the address bar)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('82', 'e983207c7d', '', 'It works fine here so my guess is that you have a really old version of DatUtil (prior to the v2.0 rewrite that was released about a year ago).

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('83', '6b22dbbb04', '', 'great, works, thanks!
i dont know why, i uesed v1.20!  :(  :(');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('84', '642bc05d8e', 'X-Men Vs. Street Fighter (USA 961023)', 'xor is released by CPS-2 Shock');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('85', '1a8288fba9', 'i\'m a newbie pls help', 'HI


1 year ago i\'ve bought for my Jamma Arcade Cabinet a PC (called dream) for 150,- EUR with approx. 60 Games (mostly Neo Geo &amp; Co), 

but now i want to upgrade this one with other Games, 
especially shooter games like Virtua Cop, House of the dead, 

now i wanna to ask you, can i search in the internet for thoose games, copy than on my harddrive from the PC in the Cabinet, and is function?

i\'m also looking for lightguns, can i connect these parallel to the Arcade Joystick, or had i to took the joystick and buttons away - and only connet lightguns...

furthermore i wanna have for example a maschine with 3-4 games,

at the beginning i will choose one, than insert a coin, than play!

it\'s possible and what i had to do ;-)

--------
PS: do you know whre i can found a jamma tree - if i will build my own PC , - a complete tree with all on it, only to conect PC2jamma.

sincerly
AJ

from Austria
EUROPE');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('86', 'f0edb0c5eb', 'DAT Errors or Impossible to find roms?', 'hello

well, i\'m using your super dats to manager my roms (thx a lot) but i have problems to find some roms for 4 dats (i know no request is allowed) i asked to many other collectors and they miss the exact same !! so can you tell me whats wrong?!

thanks you !

----------------------------------------------------------------------------------------
[b:f0edb0c5eb]Nebula Jukebox v2.9[/b:f0edb0c5eb]
	name vf3
	description \"Virtua Fighter 3 [Model 3 Step 1.0] [sound only]\"
	year 1996
	manufacturer \"Sega\"
	rom ( name ep19231.21 size 524288 crc 0xb416fe96 sha1 0xb508eb6802072a8d4f8fdc7ca4fba6c6a4aaadae )

[b:f0edb0c5eb]CPS-2 20050606[/b:f0edb0c5eb]
	name jgokushi
	description \"Jyangokushi: Haoh no Saihai (Japan 990527)\"
	year 1999
	manufacturer \"Capcom\"
	rom ( name maj-sim.01a size 2097152 crc 0xe29e4c26 sha1 0x51e99536f40481c4c208695354e90fb3fe9416d5 )
	rom ( name maj-sim.01b size 2097152 crc 0x7f68b88a sha1 0x944bf34dc998dffe39b25c3e9fcec17ad421ce81 )
	rom ( name maj-sim.01c size 2097152 crc 0xba0fe27b sha1 0x60a4fdee8da663777af1e126a1aa6308c9d9a5a9 )
	rom ( name maj-sim.01d size 2097152 crc 0x2cd141bf sha1 0x57ec73ea24d594fc1e4d2d194a3c548a7043666e )
	rom ( name maj-sim.03a size 2097152 crc 0xec737d9d sha1 0xcfff42cc24ac011fab2670dec42cab16f4e0d84d )
	rom ( name maj-sim.03b size 2097152 crc 0xc23b6f22 sha1 0xfb3120ea28c67ecb7c4a2b61a64feb62c033ef68 )
	rom ( name maj-sim.03c size 2097152 crc 0x3aaeb90b sha1 0xd426d5c7ae5ca99321ec1280abdd1fdfe4882829 )
	rom ( name maj-sim.03d size 2097152 crc 0x97894cea sha1 0xa501cd80e6da75409e3381d66bd0a13e021e89f3 )
	rom ( name maj-sim.05a size 2097152 crc 0x4cb79672 sha1 0xc5552b279a8573352c865323c834905b6b3d5ee7 )
	rom ( name maj-sim.05b size 2097152 crc 0xe5f2e14a sha1 0x2c478ca4f1a5848bb7e5aa72b416d6cf9e50b7b5 )
	rom ( name maj.01 size 131072 crc 0x1fe8c213 sha1 0xe0045566337851d8261ed65d5bea483f09ae96b4 )
	rom ( name majj.03 size 524288 crc 0x4614a3b2 sha1 0xf7226006feafaf561046ae7fce18bf62289d41df )

[b:f0edb0c5eb]Neo-Geo 20050712[/b:f0edb0c5eb]
	name kof2003a
	description \"The King of Fighters 2003 (MVS, non-MAME)\"
	year 2003
	manufacturer \"SNK Playmore\"
	romof neogeo
	rom ( name 271-p1c.bin size 4194304 crc 0x530ecc14 )
	rom ( name 271-p2c.bin size 4194304 crc 0xfd568da9 )
	rom ( name 271-p3c.bin size 1048576 crc 0xaec5b4a9 )

	name uni-bios
	description \"UNIVERSE BIOS (v1.0 to v2.1, non-MAME)\"
	year 2005
	manufacturer \"CPS2Shock\"
	romof uni-bios
	rom ( name uni-bios.20 size 131072 crc 0x0c12c2ad sha1 0x37bcd4d30f3892078b46841d895a6eff16dc921e )
	rom ( name uni-bios.rom size 131072 crc 0x8dabf76b sha1 0xc23732c4491d966cf0373c65c83c7a4e88f0082c )

[b:f0edb0c5eb]ZiNc v1.1.dat[/b:f0edb0c5eb]
	name souledga
	description \"Soul Edge (SO3/VER.A)\"
	year 1995
	manufacturer \"Namco\"
	rom ( name so1sprg.6d size 262144 crc 0xf6f682b7 sha1 0x4168a9aa525f1f0ce6cf6e14cfe4c118c4c0d773 )

	name souledgb
	description \"Soul Edge (SO1/VER.A)\"
	year 1995
	manufacturer \"Namco\"
	rom ( name so1sprg.6d size 262144 crc 0xf6f682b7 sha1 0x4168a9aa525f1f0ce6cf6e14cfe4c118c4c0d773 )');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('87', '6774369bd4', 'CAESAR gone PHP!', 'Wow, it has taken me almost 3 years to complete this! I started the project in November 2002 (after having the idea on holiday) and by December 2002 it was already on ice, or should I say in hypersleep? Last year in the summer I worked for a month or so on tools like DatUtil 2, etc. (a requirement for me getting game information into MySQL - well, in the manner I wished) and this year I did some more MySQL+PHP work around February time. After another long dormant period (i.e. better things to be doing than coding!), I have got back to it and actually finished it off. Miracles will never cease.

So, CAESAR is now running 100% in PHP. Wohooo!  :D 

As users there aren\'t many visible changes but it should at least make my life easier managing it (19,000 pages of generated HTML was not ideal, lol). Improvements for users right now:

- Some extra info (like \'driver\' details from MAME)
- Some more dat information (disks, baddump/nodump, SHA1, region)
- The \'fix aspect ratio\' logic does not mangle snaps of emulators such as Pacifi3D (e.g. http://caesar.logiqx.com/php/emulator_game.php?id=pacifi3d&amp;game=puckman)
- Improved data integrity, thanks to being able to write test queries in MySQL.
- Pretty much 100% XHTML 1.0 compliant (mainly thanks to the ZTNet ads being removed - I moved off that server in April)
- BEST OF ALL... A game search facility (simple but powerful).
- Lastly, the \'past news\' does not need setting up manually so old news should always be available.

I\'ll probably add other stuff when I feel like it (MAME history, etc) but the rewrite task was generally quite dull (not always mind you, some things were fun) and I didn\'t want it to take any longer!

It should work fine in all of the popular browsers and any sites trying to link to the old HTML should be re-mapped to the PHP pages via Apache\'s MOD_REWRITE ([url]http://httpd.apache.org/docs/1.3/mod/mod_rewrite.html[/url]). You\'ll still see the old style URL (i.e. ending in .shtml) but it will be rendered through the new PHP code. I\'d recommend using the new PHP URLs when linking though.  8) 

Please let me know if you uncover any issues with the new site.

Enjoy! Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('88', 'c0faba29d9', 'CAESAR gone PHP!', 'Wow, it has taken me almost 3 years to complete this! I started the project in November 2002 (after having the idea on holiday) and by December 2002 it was already on ice, or should I say in hypersleep? Last year in the summer I worked for a month or so on tools like DatUtil 2, etc. (a requirement for me getting game information into MySQL - well, in the manner I wished) and this year I did some more MySQL+PHP work around February time. After another long dormant period (i.e. better things to be doing than coding!), I have got back to it and actually finished it off. Miracles will never cease.

So, CAESAR is now running 100% in PHP. Wohooo!  :D 

As users there aren\'t many visible changes but it should at least make my life easier managing it (19,000 pages of generated HTML was not ideal, lol). Improvements for users right now:

- Some extra info (like \'driver\' details from MAME)
- Some more dat information (disks, baddump/nodump, SHA1, region)
- The \'fix aspect ratio\' logic does not mangle snaps of emulators such as Pacifi3D (e.g. http://caesar.logiqx.com/php/emulator_game.php?id=pacifi3d&amp;game=puckman)
- Improved data integrity, thanks to being able to write test queries in MySQL.
- Pretty much 100% XHTML 1.0 compliant (mainly thanks to the ZTNet ads being removed - I moved off that server in April)
- BEST OF ALL... A game search facility (simple but powerful).
- Lastly, the \'past news\' does not need setting up manually so old news should always be available.

I\'ll probably add other stuff when I feel like it (MAME history, etc) but the rewrite task was generally quite dull (not always mind you, some things were fun) and I didn\'t want it to take any longer!

It should work fine in all of the popular browsers and any sites trying to link to the old HTML should be re-mapped to the PHP pages via Apache\'s MOD_REWRITE ([url]http://httpd.apache.org/docs/1.3/mod/mod_rewrite.html[/url]). You\'ll still see the old style URL (i.e. ending in .shtml) but it will be rendered through the new PHP code. I\'d recommend using the new PHP URLs when linking though.  8) 

Please let me know if you uncover any issues with the new site.

Enjoy! Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('89', '', '', 'I don\'t know if I should ban you for cross-posting... :twisted: 

Congrats for finishing the project. And now you\'ll be able to start trimming down that hundred mile long to-do list for CAESAR. When are you adding history.dat?  8)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('90', 'a4514b71ab', '', 'Well, I\'m supposed to be visiting some dude in Spain in the last week of August.

I suppose that I could cancel the trip and do history.dat instead. ;)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('91', 'd8eb34216a', 'Re: DAT Errors or Impossible to find roms?', 'I\'ll just be brief with the answers because I need to get on with stuff. ;)

[b:d8eb34216a]Nebula Jukebox v2.9[/b:d8eb34216a]

	name vf3 
	description \"Virtua Fighter 3 [Model 3 Step 1.0] [sound only]\" 

Does exist.

[b:d8eb34216a]CPS-2 20050606[/b:d8eb34216a]

	name jgokushi
	description \"Jyangokushi: Haoh no Saihai (Japan 990527)\"

Being hoarded by Xacrow.

[b:d8eb34216a]Neo-Geo 20050712[/b:d8eb34216a]

	name kof2003a
	description \"The King of Fighters 2003 (MVS, non-MAME)\"

Exists, apparently. I had the details given to me by someone who should know!

	name uni-bios
	description \"UNIVERSE BIOS (v1.0 to v2.1, non-MAME)\"

Easy to find. Go to the Uni-BIOS site.

[b:d8eb34216a]ZiNc v1.1.dat[/b:d8eb34216a]

There are two SHA1 typos in that data file (all CRCs are correct mind). It will be re-released shortly.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('92', '140344f7e3', '', 'ok thx for the answer, was able to find the uni-bios but for the rest...
btw thx for your works on dats :)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('93', 'adb0838679', '', '[quote:adb0838679=\"Logiqx\"]Well, I\'m supposed to be visiting some dude in Spain in the last week of August.

I suppose that I could cancel the trip and do history.dat instead. ;)[/quote:adb0838679]

Yeah, please do
 :lol:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('94', 'd5780290c6', '', 'It\'s taken me a while but I\'ve now fixed the SHA1 problems in the ZiNc data file.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('95', '3ba310933a', '', 'The ZiNc issue has been fixed now. It\'s available for download.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('96', '1bd0b8f046', 'CAESAR Updates', 'I have updated information for a number of emulators in CAESAR. Some are completely new, some were just waiting for the latest info:

I, Robot v2.0.0.10 [url]http://caesar.logiqx.com/php/emulator.php?id=irobot[/url]
Tickle \"Rebound\" Edition [url]http://caesar.logiqx.com/php/emulator.php?id=tickle[/url]
Pacifi3D v0.3 [url]http://caesar.logiqx.com/php/emulator.php?id=pacifi3d[/url]
RAINE v0.42.4 [url]http://caesar.logiqx.com/php/emulator.php?id=raine[/url]
Daphne v0.99.6c [url]http://caesar.logiqx.com/php/emulator.php?id=daphne[/url]
VAntAGE v1.12 [url]http://caesar.logiqx.com/php/emulator.php?id=vantage[/url]
AsteroidsGL [url]http://caesar.logiqx.com/php/emulator.php?id=asteroidsgl[/url]
BattleZoneGL [url]http://caesar.logiqx.com/php/emulator.php?id=battlezonegl[/url]
TempestGL [url]http://caesar.logiqx.com/php/emulator.php?id=tempestgl[/url]

Corresponding data files have also been released at the main Logiqx site.

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('97', '', '', 'Who needs a brit to get drunk and have fun? Not me, certainly. The decision is yours  :lol:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('98', 'ac57172f40', 'Tickle Rebound Edition is fixs.', 'Ms. PacMan won\'t run because Pacman is missing some roms.

Here is the fixs. Seem that you didn\'t see the missing roms on the Tickle Rebound Edition screen.

game (
	name pacman
	description \"Pac-Man (Midway)\"
	year 1980
	manufacturer \"[Namco] (Midway license)\"
	rom ( name pacman.6e size 4096 crc c1e6ab10 sha1 e87e059c5be45753f7e9f33dff851f16d6751181 region cpu1 )
	rom ( name pacman.6f size 4096 crc 1a6fb2d4 sha1 674d3a7f00d8be5e38b1fdc208ebef5a92d38329 region cpu1 )
	rom ( name pacman.6h size 4096 crc bcdd1beb sha1 8e47e8c2c4d6117d174cdac150392042d3e0a881 region cpu1 )
	rom ( name pacman.6j size 4096 crc 817d94e3 sha1 d4a70d56bb01d27d094d73db8667ffb00ca69cb9 region cpu1 )
	rom ( name pacman.5e size 4096 crc 0c944964 sha1 06ef227747a440831c9a3a613b76693d52a2f0a9 region gfx1 )
	rom ( name pacman.5f size 4096 crc 958fedf9 sha1 4a937ac02216ea8c96477d4a15522070507fb599 region gfx2 )
	rom ( name u5 size 2048 crc f45fbbcd sha1 b26cc1c8ee18e9b1daa97956d2159b954703a0ec region cpu1 )
	rom ( name u6 size 4096 crc a90e7000 sha1 e4df96f1db753533f7d770aa62ae1973349ea4cf region cpu1 )
	rom ( name u7 size 4096 crc c82cd714 sha1 1d8ac7ad03db2dc4c8c18ade466e12032673f874 region cpu1 )
	rom ( name 5e size 4096 crc 5c281d01 sha1 5e8b472b615f12efca3fe792410c23619f067845 region gfx1 )
	rom ( name 5f size 4096 crc 615af909 sha1 fd6a1dde780b39aea76bf1c4befa5882573c2ef4 region gfx2 )
	rom ( name 82s123.7f size 32 crc 2fc650bd sha1 8d0268dee78e47c712202b0ec4f1f51109b1f2a5 region proms )
	rom ( name 82s126.4a size 256 crc 3eb3a8e4 sha1 19097b5f60d1030f8b82d9f1d3a241f93e5c75d6 region proms )
	rom ( name 82s126.1m size 256 crc a9cc86bf sha1 bbcec0570aeceb582ff8238a4bc8546a23430081 region sound1 )
	rom ( name 82s126.3m size 256 crc 77245b66 sha1 0c4d0bee858b97632411c440bea6948a74759746 region sound1 )
)

Paste this over the one down bellow.

game (
	name pacman
	description \"Pac-Man (Midway)\"
	year 1980
	manufacturer \"[Namco] (Midway license)\"
	rom ( name pacman.6e size 4096 crc c1e6ab10 sha1 e87e059c5be45753f7e9f33dff851f16d6751181 region cpu1 )
	rom ( name pacman.6f size 4096 crc 1a6fb2d4 sha1 674d3a7f00d8be5e38b1fdc208ebef5a92d38329 region cpu1 )
	rom ( name pacman.6h size 4096 crc bcdd1beb sha1 8e47e8c2c4d6117d174cdac150392042d3e0a881 region cpu1 )
	rom ( name pacman.6j size 4096 crc 817d94e3 sha1 d4a70d56bb01d27d094d73db8667ffb00ca69cb9 region cpu1 )
	rom ( name pacman.5e size 4096 crc 0c944964 sha1 06ef227747a440831c9a3a613b76693d52a2f0a9 region gfx1 )
	rom ( name pacman.5f size 4096 crc 958fedf9 sha1 4a937ac02216ea8c96477d4a15522070507fb599 region gfx2 )
	rom ( name 82s123.7f size 32 crc 2fc650bd sha1 8d0268dee78e47c712202b0ec4f1f51109b1f2a5 region proms )
	rom ( name 82s126.4a size 256 crc 3eb3a8e4 sha1 19097b5f60d1030f8b82d9f1d3a241f93e5c75d6 region proms )
	rom ( name 82s126.1m size 256 crc a9cc86bf sha1 bbcec0570aeceb582ff8238a4bc8546a23430081 region sound1 )
	rom ( name 82s126.3m size 256 crc 77245b66 sha1 0c4d0bee858b97632411c440bea6948a74759746 region sound1 )
)

This will fixs the Ms. PacMan loading error problem. Other wise it will keep saying missing roms if PacMan didn\'t have those roms.

You may have to fixs the RC data version as well.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('99', '255c9e06f5', '', 'I don\'t know why you get a problem but there is no problem here. I have pacman ROMs in pacman.zip, mspacman ROMs in mspacman.zip and all is fine. There is no reason to put mspacman ROMs in pacman.zip as you suggest.

If that were necessary (i.e. mspacman ROMs in pacman.zip) then there are better ways to do it in the data file anyway (e.g. make mspacman a clone of pacman and set \'forcemerging\' to full).

I\'m always glad of problems being reported but try to avoid false alarms please. I even went as far as reading the Tickle source code at lunch time looking for possible changes... not the best use of my time. ;)

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('100', '', '', 'I tried rebuilding the Ms. Pacman set with the current dat at logiqx.com and there was no problem loading the game. There\'s no need for the pacman.5? roms in this set.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('101', 'f114415a56', 'JEmu2 online', 'Just posted about it in the frontpage, visit &lt;a href=\"http://www.gagaplay.com/\" target=_blank&gt;gagaplay.com&lt;/a&gt; to play it. Supporting 28 games for now. There\'s also a free game, quite nice.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('102', '3b5bdc5c09', 'MAME v0.99', 'Old news... it was released at the weekend.

I have released the relevant data files at logiqx.com and also updated the CAESAR database.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('103', '', 'Uhmmmm....', 'What, no \"next MAME is 1.0\" or NeoRageX threads? No \"when is XXXX gonna be emulated\" or asking about 2005 games? No \"I can\'t download roms from CAESAR, help me!\" or even \"why Sanfran Rush doesn\'t run in my PII-500\"????

Uhmmmmm.... I wonder if that\'s a good or a bad thing.... :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('104', '1ff46fb9a8', 'New Look', 'I have updated the look of the site slightly! I\'ve been wanting to do it for ages but it\'s always been beneath the CAESAR rewrite on my (never ending) todo list. ;) 

It may not look massively different but there are a number of improvements for you guys: 

- Slightly different look (e.g. it has turned blue) and no more annoying frames 
- Simpler URLs (e.g. http://www.logiqx.com/Tools/DatUtil/ ) 
- Links to individual pages are better, due to the removal of frames 
- You can still use any old URLs that you have for a while (to minimise transitional problems) 
- Fully XHTML compliant and use of CSS throughout');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('105', '9707fdcc3a', 'Ok.', 'I download the dat and redone the roms and samples. (lates dat) Still no go on Ms.Pacman.

Read this error.

=============================================

One or more files could not be load.

-5e
-5f
-u5
-u6
-u7

Files were looked for in the \"roms\" folder (also \"samples for sounds) and in the following archives:

-mspacman
-pacman
-puckman

=============================================

How is it mspacman works when the error came from pacman? mspacman have those roms already. Puckman and Pacman only works.

I use the default settings on cmpro.

I will try the new settings and see that I get the same problem when splits this time. Something isn\'t right about this when it working for you. :/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('106', '944901cfc0', 'RE:', '-5e
-5f
-u5
-u6
-u7

Are going back into the pacman.zip

I still think your dat still wrong because ms.pacman won\'t play unless pacman have those roms too.

You may want to show me how it working for you on ms.pacman.

I have no clue at all why it does that.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('107', 'f00334b7ed', '', 'I never knew John updated his I, Robot emulator! Thanks!

Hey, any progress on importing Jeff Mitchell\'s \"early days of emulation\" binary &amp; source archives you and I discussed way long ago?

I\'ll see if I can drum up support from someone to build AMOAD 20 &amp; AMOAD 22.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('108', 'e5ee7dddcc', '', 'There may be something wierd about your mspacman.zip (perhaps a format that CMPro recognises but Tickle doesn\'t like). Try extracting the files from it, deleting the zip and manually re-zipping mspacman.zip.

Look, Tickle on my system with just mspacman.zip and it runs fine:

[code:1:e5ee7dddcc]F&#58;\\Download\\tickle&gt;dir /s
 Volume in drive F is FILES
 Volume Serial Number is 2076-C3CB

 Directory of F&#58;\\Download\\tickle

19/08/2005  08&#58;47    &lt;DIR&gt;          .
19/08/2005  08&#58;47    &lt;DIR&gt;          ..
17/06/2001  02&#58;31            18,324 license.txt
12/07/2005  23&#58;43             6,033 readme.txt
19/08/2005  08&#58;47    &lt;DIR&gt;          roms
12/07/2005  22&#58;40           140,800 tickle.exe
21/06/2004  20&#58;03               234 tickle.ini
               4 File&#40;s&#41;        165,391 bytes

 Directory of F&#58;\\Download\\tickle\\roms

19/08/2005  08&#58;47    &lt;DIR&gt;          .
19/08/2005  08&#58;47    &lt;DIR&gt;          ..
13/07/2004  21&#58;18            21,528 mspacman.zip
               1 File&#40;s&#41;         21,528 bytes

     Total Files Listed&#58;
               5 File&#40;s&#41;        186,919 bytes
               5 Dir&#40;s&#41;  19,590,094,848 bytes free
[/code:1:e5ee7dddcc]

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('109', '041e93b00c', '', 'No, I lost contact with Jeff because of a bereavement in his family at that time (he needed time to deal with it). If you are still in touch with him, I\'d still love to get hold of that stuff.

I\'m keen to get the back catalogue complete in CAESAR, now that I have the PHP rerite off my todo list.  8) 

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('110', '6d5a4a1077', 'Logiqx', 'Thanks.

It was the zipping problem by the CMPro did. It was 24kb. Now correct zip size is 21.2kb and running great on ms.pacman. The cmp371d need more fixes on the zipping. I keep on downloading the updates on it. I glad that you told me to rezip it.

Sorry about that and I will keep that in mind. :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('111', '287fac05aa', '', 'Please warn Allessandro Scotti. My guess: Mr. Scotti\'s using an older version of zlib or something.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('112', 'e8b1fe1df9', 'The backlog', 'Nope, I\'m not in touch with Jeff either. But it doesn\'t look too hard, he has a blog and everything.

I went through his site here:
[url]http://www.rjmitchell.ca/~jeff/cgibin/execfilter.cgi?FILE=../history/history-arcade-static.html[/url]
And this is what I think is needed:
kong_020.zip 	Donkey Kong v.20
milli01.zip 	Millipedge
moon.zip 	Moon Patrol
mrdosaga.zip 	The Mr. Do-u-lators
nb2.exe 	Naughty Boy Alpha! (John Bugliarisi)
vanguard6.zip 	Vanguard v6
Xphoenix Source - Phoenix

and to play it safe, these too:
cloak.zip 	Cloak and Dag-ulator binary
kf.zip - Kung Fu Master

Plus anything else he hasn\'t mentioned on that page.

Unless you want the motherlode? (and I\'m not sure why you would...)

Also, see here:
[url]http://www.rjmitchell.ca/~jeff/cinem.html[/url]
Maybe try for the Palm version of Cinemu too!

Am I missing anything? Give me the okay and I\'ll try to talk with Jeff again.

------------------

I went through my notes from approx. three years ago on the first loose-ends attack and this is what I\'ll try for again:

Stargate+Defender (Joe Britt)
     Last time I talked to Joe, he thought he had this on a CD-R. He never got back to me.

WILLY - Williams Pinball Sound Emulator (Steve Hawley)
     Al Kossow thought he had this on a back-up tape, but never got back to me either - and that was BEFORE he moved and cleared out most of his storage. I had tried asking Jonathan Deitch to see if he had it (Tim from ArcadeCollecting.Com thought he had received it too) but he never emailed me back - but now I have Jon\'s work email, hehe.
Anyhow, it\'s not arcade, so not a CAESAR target. But maybe as a special case, as it would need a place to save it if it is ever located.

------------------

VecSim &amp; CentSim are available for download as of August 2003. Eric finally did make good on his offer to locate the projects. 

VecSim (Eric Smith &amp; Hedley Rainnie)
http://www.brouhaha.com/~eric/software/vecsim/
* Note that Eric mentions an unreleased Windows port on this page, maybe that is worth asking about.

CentSim (Eric Smith &amp; Hedley Rainnie)
http://www.brouhaha.com/~eric/software/centsim/

Add that to your to-do list!

------------------

AMOAD20 &amp; AMOAD22 are just a matter of someone resurrecting a DOS build system. According to his email to us, he was using the following apps to compile at that time:
27/03/1998  10:22            1,248,606 ALLEG30.ZIP
17/06/1998  10:25            1,896,445 BNU281B.ZIP
27/03/1998  10:06               40,719 CSDPMI3B.ZIP
27/03/1998  10:22            1,538,295 DJDEV201.ZIP
17/06/1998  10:27            1,311,315 GCC281B.ZIP
26/03/1998  09:46              681,045 GPP2721B.ZIP
27/03/1998  10:11               46,264 INVADERS.ZIP
26/03/1998  09:47              638,706 LGP271B.ZIP
26/03/1998  09:44              209,185 MAK375B.ZIP
10/01/1997  13:29              527,531 SEAL103B.ZIP
27/03/1998  11:29              466,929 TXI390B.ZIP

Once they\'re built, someone can re-write the README as he would have done it. I started on that but am not sure where I stopped nor where I left my files.

------------------

We still had that possibility of Chris Hardy sending you the CRC32/MD5/SHA1 to junoboot.zip...

------------------

The backlog as mentioned on CAESAR is:
NeoGEM v0.022
EMAME and E2MAME for Symbian devices
PacPackDC for the Dreamcast
A variety of emulators for the Dreamcast from Reaper2K2

and once you mentioned to me that you \"might\" write a decryption module for ROMBuild for Pengo (set 1 not encrypted) - Popcorn Music and Penta (not encrypted.

And of course there\'s that amusing emulator that may never be released... (I should check to see how close it is to being completely consumed by the other emulators)

------------------

Anything you can mention in your to-do list? Anything recent I\'m not thinking of?

We could always ask Charles MacDonald about Alien Storm (bootleg) in System16 (final beta)...

- Stiletto');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('113', 'a942547284', '', 'Ok, I\'ve just sent an e-mail to Jeff to see if I can get hold of everything from his classic emus page. I can then check that everything is in CAESAR (some are definitely not, as you listed).

Willy would be an interesting addition to CAESAR since in my view it is no different to any other arcade sound emulator. It\'s only the actual simulation of pinball mechanics that I don\'t want in CAESAR.

VecSim and CentSim are now on my PC in the \'caesar.todo\' folder. I never even knew that they existed, thanks for letting me know.

Finally, the Pengo decryption thing won\'t ever be done. Back at that time, I thought it was an interesting proposition but it would require a disproportional amount of work for the benefits it brings. I simply don\'t have time for such things now, what with my busy job and other hobbies that I have. I\'d be better off spending my limited PC time on other things. ;)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('114', 'e6d6ad9163', 'dat download', 'hi there,

i\'ve been trying to download mame dats but i keep getting this error message;

\"Forbidden
You don\'t have permission to access /Dats/MAMEBeta/MAME v0.99 (rc).zip on this server.

Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.\"

this has been happening for quite a while now, also its the same error on romcenters homepage...anyone else get the same error? anyone know whats happening?
thanks.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('115', '9e3446a5a6', 'M1 0.7.5 is out. But I try to make a dat and it won\'t do it.', 'What do I need to make a dat from the m1.exe?

Do I need to make one from the m1.dll???

Here is the news at http://www.mameworld.info/ubbthreads/showthreaded.php?Cat=&amp;Number=44761&amp;page=0&amp;view=expanded&amp;sb=5&amp;o=&amp;fpart=1&amp;vc=1');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('116', '74bf29e60f', 'M1 0.7.6 is out with some fixes.', 'http://www.mameworld.info/ubbthreads/showthreaded.php?Cat=&amp;Number=44891&amp;page=0&amp;view=expanded&amp;sb=5&amp;o=&amp;fpart=1&amp;vc=1

Let me know when the dat is out on your website for putting together the roms for this version. :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('117', '', '', 'What browser are you using? I have no trouble downloading the file right now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('118', 'cbc6d762ea', '', 'Sorry but you\'ll have to get by without it for at least a week. For the next five days I will not have access to my computer and then I imagine that I\'ll not do it until the weekend arrives.

Just use the -d option of M1 in the meantime.

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('119', '7322fdbef2', '', 'Whatever browser/download manager you are using, it is the hot-link prevention at logiqx.com that is causing your problem.

Basically, you can only download a zip if it was requested by clicking on a link from my web pages.

It works using the \'referer\' information provided by the browser/download manager. So, if you have some download manager that intercepts the request from your browser and it doesn\'t handle referals correctly, it will be blocked.

Logiqx');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('120', 'f6c60f3fd8', 'Ok.', 'I will wait. No problem. :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('121', '25c9edb0aa', '', 'Has this problem gone away now? I made a change last night which may help.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('122', 'f6de2611b0', 'DatLib v2.6', 'Just one change...

- Fixed a \'hang\' that occurred with circular cloneof relationships.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('123', '1b944e572d', 'DatUtil v2.18 and MAMEDiff v2.17', 'Recompiled with the new DatLib:

- Uses DatLib v2.6.
- Fixed a \'hang\' that occurred with circular cloneof relationships.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('124', '237c8ea66c', '', 'Data file for v0.7.6 has now been released');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('125', '402ca843f6', 'RAINE v0.43.0', 'Data files have now been updated and are available for download');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('126', '6ffcd1abf7', 'M1 v0.7.6', 'Data files have been updated and are available for download');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('127', '63557d2672', 'M1 0.7.7.', 'Just now released.

Few more games list been added on M1 plus more fixes. http://rbelmont.mameworld.info/?p=52

http://www.emuhype.com/files/m1077b-win32.zip');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('128', '193f0bb5b3', '', 'Ok, the new data file is online now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('129', 'ced4d422b2', 'M1 v0.7.7', 'Data files have been updated and are available for download');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('130', 'fa8bb13943', 'Compile Guides', 'I have updated the compile guides to use the latest tools and more importantly, added libpng for RAINE.

http://www.logiqx.com/HowTo/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('131', 'f6495329eb', 'M1 v0.7.7, RAINE 0.43.0, MinGW + Libraries', 'Emulator pages updated (plus the related ports):

http://caesar.logiqx.com/php/emulator.php?id=raine
http://caesar.logiqx.com/php/emulator.php?id=m1_linux

Tool pages updated:

http://caesar.logiqx.com/php/tool.php?id=mingw
http://caesar.logiqx.com/php/tool.php?id=allegro
http://caesar.logiqx.com/php/tool.php?id=libpng
http://caesar.logiqx.com/php/tool.php?id=sdl
http://caesar.logiqx.com/php/tool.php?id=zlib');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('132', 'ee4a45d40b', 'Daphne v0.99.7pre5', 'http://www.daphne-emu.com/download.php

I having a hard time to get all the miissing roms on this one. Hope a updated roms dat will be made and release soon. I kind of kick myself on this version. :D

I will wait until the dat is releaase before checking the roms again. :oops:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('133', '2e36f1a36a', '', 'I didn\'t even know that version had been released!

I doubt that I will be able to do an update for that before I go on holiday (Wednesday).

Mike');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('134', '', '', 'I just posted the news before checking this board. I didn\'t know about it either, just noticed this morning in the MW.info newsboard.

Murphy says that just when you do the update, a new version will come out...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('135', '190b71d2b3', '', 'hi Logiqx

i have search since 1 month and still missing those roms, you have them?? because no one have on IRC...

thx

Nebula - Virtua Fighter 3
	name vf3
	description \"Virtua Fighter 3 [Model 3 Step 1.0] [sound only]\"
	year 1996
	manufacturer \"Sega\"
	rom ( name ep19231.21 size 524288 crc 0xb416fe96 sha1 0xb508eb6802072a8d4f8fdc7ca4fba6c6a4aaadae )

Neo Geo - The King of Fighters 2003
	name kof2003a
	description \"The King of Fighters 2003 (MVS, non-MAME)\"
	year 2003
	manufacturer \"SNK Playmore\"
	romof neogeo
	rom ( name 271-p1c.bin size 4194304 crc 0x530ecc14 )
	rom ( name 271-p2c.bin size 4194304 crc 0xfd568da9 )
	rom ( name 271-p3c.bin size 1048576 crc 0xaec5b4a9 )');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('136', '4ec7853630', '', 'Be sure that those roms exist, but please do not ask for them in this board.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('137', '7e02f36c1b', 'RE:', '[quote:7e02f36c1b=\"Pi\"]I just posted the news before checking this board. I didn\'t know about it either, just noticed this morning in the MW.info newsboard.

Murphy says that just when you do the update, a new version will come out...[/quote:7e02f36c1b]

Good to hear that. I was chatting with them on the #lasergames channel. I think one of them is Bard33 there.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('138', '78981d7f12', 'Raine 0.43.1 : Haze\'s games !', 'http://www.rainemu.com/html/download/latest.html  :D');
#
# TABLE: phpbb_privmsgs
#
DROP TABLE IF EXISTS phpbb_privmsgs;
CREATE TABLE phpbb_privmsgs(
	privmsgs_id mediumint(8) unsigned NOT NULL auto_increment,
	privmsgs_type tinyint(4) NOT NULL,
	privmsgs_subject varchar(255) NOT NULL,
	privmsgs_from_userid mediumint(8) NOT NULL,
	privmsgs_to_userid mediumint(8) NOT NULL,
	privmsgs_date int(11) NOT NULL,
	privmsgs_ip varchar(8) NOT NULL,
	privmsgs_enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_enable_html tinyint(1) NOT NULL,
	privmsgs_enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_attach_sig tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (privmsgs_id), 
	KEY privmsgs_from_userid (privmsgs_from_userid), 
	KEY privmsgs_to_userid (privmsgs_to_userid)
);

#
# Table Data for phpbb_privmsgs
#

INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('6', '2', 'Re: Some help Please :)', '4', '37', '1118948344', '53d5305f', '0', '1', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('2', '2', 'I also thought of trying the PM\'s', '4', '3', '1113046496', '53d5305f', '0', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('4', '2', 'Some help Please :)', '37', '4', '1118935868', 'c9113816', '1', '1', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('5', '0', 'Re: Some help Please :)', '4', '37', '1118948344', '53d5305f', '0', '1', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('8', '2', 'Re: Some help Please :)', '37', '4', '1118951868', 'c9113816', '1', '1', '1', '0');
#
# TABLE: phpbb_privmsgs_text
#
DROP TABLE IF EXISTS phpbb_privmsgs_text;
CREATE TABLE phpbb_privmsgs_text(
	privmsgs_text_id mediumint(8) unsigned NOT NULL,
	privmsgs_bbcode_uid varchar(10) NOT NULL,
	privmsgs_text text, 
	PRIMARY KEY (privmsgs_text_id)
);

#
# Table Data for phpbb_privmsgs_text
#

INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('2', '', 'And see if the \"notify by email\" stuff works and what does it do and things  8)');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('6', '', 'I don\'t know shit about consoles. You might want to try at another *board* like e.g.:
http://www.mameworld.info/ubbthreads/postlist.php?Cat=&amp;Board=mamechat

Sending PM\'s to people you don\'t know asking for help is generally considered rude.');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('4', '087a34100a', 'Hello there,

I am new here and would like some help.

I just love a dreamcast game named Dynamite Cop II, but I just cant find a way to emulate it... pls help, I realy love this game.

Thanks in advance,

Andre
amcordeiro@yahoo.com.br');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('5', '', 'I don\'t know shit about consoles. You might want to try at another *board* like e.g.:
http://www.mameworld.info/ubbthreads/postlist.php?Cat=&amp;Board=mamechat

Sending PM\'s to people you don\'t know asking for help is generally considered rude.');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('8', 'e30f7d829f', 'Sorry to botter u, and I didnt mean to be rude (maybe u were)...

Anyway Dyamite Cop was originaly an arcade game, so I was hoping that maybe u knew something or to point some directions, like u did.

Thank you for ur time,

Andre');
#
# TABLE: phpbb_ranks
#
DROP TABLE IF EXISTS phpbb_ranks;
CREATE TABLE phpbb_ranks(
	rank_id smallint(5) unsigned NOT NULL auto_increment,
	rank_title varchar(50) NOT NULL,
	rank_min mediumint(8) NOT NULL,
	rank_special tinyint(1),
	rank_image varchar(255), 
	PRIMARY KEY (rank_id)
);

#
# Table Data for phpbb_ranks
#

INSERT INTO phpbb_ranks (rank_id, rank_title, rank_min, rank_special, rank_image) VALUES('1', 'Site Admin', '-1', '1', NULL);
#
# TABLE: phpbb_search_results
#
DROP TABLE IF EXISTS phpbb_search_results;
CREATE TABLE phpbb_search_results(
	search_id int(11) unsigned NOT NULL,
	session_id varchar(32) NOT NULL,
	search_array text NOT NULL, 
	PRIMARY KEY (search_id), 
	KEY session_id (session_id)
);

#
# Table Data for phpbb_search_results
#

INSERT INTO phpbb_search_results (search_id, session_id, search_array) VALUES('391412484', '54d37a007bd49678eb74e0487989b6c0', 'a:7:{s:14:\"search_results\";s:86:\"8, 4, 5, 7, 13, 15, 18, 19, 26, 34, 35, 37, 41, 42, 43, 44, 48, 49, 50, 51, 52, 53, 55\";s:17:\"total_match_count\";i:23;s:12:\"split_search\";N;s:7:\"sort_by\";i:0;s:8:\"sort_dir\";s:4:\"DESC\";s:12:\"show_results\";s:6:\"topics\";s:12:\"return_chars\";i:200;}');
#
# TABLE: phpbb_search_wordlist
#
DROP TABLE IF EXISTS phpbb_search_wordlist;
CREATE TABLE phpbb_search_wordlist(
	word_text varchar(50) NOT NULL,
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word_common tinyint(1) unsigned NOT NULL, 
	PRIMARY KEY (word_text), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordlist
#

INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mrgreen', '99', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('requests', '15', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rom', '16', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('roms', '17', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('available', '18', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('com', '19', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discussion', '20', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forums', '21', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hopefully', '22', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('logiqx', '23', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lots', '24', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prove', '25', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relating', '26', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('things', '27', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('useful', '28', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('made', '98', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('getting', '97', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dangerous', '96', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('still', '95', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('online', '94', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('link', '93', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fixed', '92', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('earlier', '91', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('data', '90', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('broken', '89', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('versions', '88', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('romcentre', '87', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('replys', '86', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('older', '85', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mame0', '84', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mame', '83', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('listxml', '82', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('listinfo', '81', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('i', '80', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('function', '79', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('format', '78', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('files', '77', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('file', '76', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dat', '75', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('copy', '74', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clrmamepro', '73', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chasing', '72', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('appreciated', '71', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyone', '70', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('84', '69', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0', '68', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tried', '67', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pacifi3d', '66', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pacifi', '65', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ive', '64', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('posts', '100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('registered', '101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('released', '102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('update', '103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('updated', '107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('3', '106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clue', '108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('datafiles', '109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('encouraging', '110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('give', '111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mameth', '112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('roll', '113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('think', '114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('try', '115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('updateth', '116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anything', '117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arcade', '118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brain', '119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cabinet', '120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('card', '121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cards', '122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cart', '123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('carts', '124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('collect', '125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compelling', '126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('computer', '127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('course', '128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('delta', '129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('designed', '130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('einhander', '131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('embarrace', '132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulation', '133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulator', '134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('favorite', '135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('few', '136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('first', '137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fit', '138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('games', '139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gnet', '140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guys', '141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hardware', '142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('help', '143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heres', '144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hooking', '145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hope', '146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('huh', '147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('idea', '148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ignorant', '149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('info', '150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interested', '151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('involved', '152', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('machine', '153', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('makes', '154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mark', '155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mind', '156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myself', '157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('offer', '158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('one', '159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('perfectly', '160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('play', '161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('playstation', '162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('possible', '163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('right', '164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rtype', '165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('run', '166', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sense', '167', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('similar', '168', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spot', '169', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('standardised', '170', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('store', '171', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stuff', '172', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sure', '173', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('surely', '174', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taito', '175', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tell', '176', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thanks', '177', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thought', '178', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('understand', '179', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uses', '180', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whats', '181', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('work', '182', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('working', '183', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actually', '184', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('addressing', '185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amount', '186', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amounts', '187', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyway', '188', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('approximation', '189', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('board', '190', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bootleg', '191', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('both', '192', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cd', '193', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('certain', '194', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('combined', '195', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consider', '196', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('converting', '197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cpu', '198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('developers', '199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('different', '200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('documentation', '201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulate', '202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulators', '203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('full', '204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('further', '205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('game', '206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('general', '207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('graphics', '208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gut', '209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hacking', '210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('huge', '211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('identical', '212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interesting', '213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('internals', '214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('least', '215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('likely', '216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('load', '217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('matter', '218', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mean', '219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('memory', '220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('message', '221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('opinions', '222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('original', '223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('own', '224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('porting', '225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('possibility', '226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('power', '227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('processing', '228', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('programs', '229', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reaction', '230', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('require', '231', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('required', '232', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('requires', '233', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('retrogames', '234', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rough', '235', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('running', '236', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seem', '237', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('simple', '238', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sound', '239', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('speed', '240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('substantial', '241', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('surface', '242', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('system', '243', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('systems', '244', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taitos', '245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('that', '246', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('together', '247', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('typically', '248', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unlikely', '249', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('viability', '250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('viable', '251', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('virtual', '252', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('write', '253', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('account', '254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allow', '255', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('another', '256', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arcades', '257', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('biggest', '258', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bootlegging', '259', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('capable', '260', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('case', '261', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('complex', '262', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('connector', '263', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('controls', '264', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('develope', '265', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('development', '266', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('devs', '267', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('difference', '268', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easy', '269', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulating', '270', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fact', '271', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fees', '272', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frown', '273', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hack', '274', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hard', '275', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('homebrew', '276', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jamma', '277', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kit', '278', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('make', '279', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('making', '280', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mimicing', '281', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neogeo', '282', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('notice', '283', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ones', '284', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('paying', '285', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('platform', '286', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('popular', '287', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('problem', '288', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('publically', '289', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quite', '290', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('real', '291', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sdk', '292', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('software', '293', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('solution', '294', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thing', '295', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('using', '296', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('very', '297', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanted', '298', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wouldnt', '299', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('count', '300', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smileyonly', '301', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twisted', '302', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cmp', '303', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('core', '304', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('datlib', '305', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daunting', '306', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('effort', '307', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guess', '308', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('itll', '309', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kind', '310', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manager', '311', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('surprised', '312', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('took', '313', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('used', '314', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boards', '315', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('check', '316', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lol', '317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moderator', '318', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('several', '319', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bandwidth', '320', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('costing', '321', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('money', '322', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attract', '323', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chloe', '324', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fancy', '325', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jones', '326', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('post', '327', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pr0n', '328', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('probably', '329', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tempted', '330', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visitors', '331', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dats', '332', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('place', '333', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('back', '334', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('logiqxs', '335', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('previous', '336', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('site', '337', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('viewing', '416', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('screen', '415', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('response', '414', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quick', '413', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pain', '412', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('main', '411', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('however', '410', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heading', '409', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hate', '408', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('changed', '407', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ass', '406', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('above', '349', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('click', '350', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('show', '351', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supplied', '352', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('96', '353', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('besides', '354', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boogie', '355', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bsdbased', '356', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('end', '357', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eventually', '358', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('join', '359', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jokes', '360', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kill', '361', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('licence', '362', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rb', '363', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('release', '364', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wings', '365', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wonder', '366', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('busy', '367', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finally', '368', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('late', '369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('updates', '370', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uploaded', '371', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('week', '372', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('8bit', '373', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('checking', '374', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('per', '375', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kept', '376', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pics', '377', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('porn', '378', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('url', '379', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('formats', '380', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twisty', '381', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('closest', '382', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contributed', '383', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('galleries', '384', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('image', '385', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mamend', '386', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seen', '387', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anymore', '388', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('note', '389', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('notes', '390', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('noticed', '391', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('regarding', '392', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('removed', '393', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rombuild', '394', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('superseded', '395', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zinc', '396', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crcs', '397', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('differences', '398', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exactly', '399', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('names', '400', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rebuild', '401', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('related', '402', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('same', '403', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('set', '404', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('since', '405', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('67', '417', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('addition', '418', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('began', '419', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('collection', '420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('command', '421', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('correct', '422', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('create', '423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('diff', '424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('differ', '425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('directory', '426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('e', '427', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('generate', '428', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jerry', '429', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kaillera', '430', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mame67', '431', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mame96', '432', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mamediff', '433', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('needed', '434', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('represent', '435', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('romset', '436', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('s', '437', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sets', '438', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('split', '439', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trying', '440', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('two', '441', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('txt', '442', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xml', '443', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zips', '444', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actions', '445', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('added', '446', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('backwards', '447', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('complete', '448', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('conflicting', '449', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('containing', '450', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('d2', '451', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('filenames', '452', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('giving', '453', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('last', '454', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('line', '455', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loads', '456', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('may', '457', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('minimum', '458', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('number', '459', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('option', '460', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('options', '461', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('point', '462', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pointless', '463', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('points', '464', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('refuse', '465', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relate', '466', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supplement', '467', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('turned', '468', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unnecessary', '469', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hehe', '470', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('knew', '471', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lucky', '472', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ton', '473', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wasnt', '474', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('double', '475', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dragon', '476', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('geo', '477', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neo', '478', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neoragex', '479', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('someone', '480', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('teach', '481', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('again', '482', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitswaps', '483', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cases', '484', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('certainly', '485', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('converted', '486', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corrected', '487', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dumps', '488', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('incorrect', '489', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('needs', '490', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ranging', '491', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zip', '614', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('works', '613', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tips', '612', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('romcenter', '611', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('named', '610', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('name', '609', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('missing', '608', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loading', '607', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('inside', '606', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('incorrectly', '605', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happens', '604', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('doubledr', '603', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragv2', '602', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragv1', '601', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddrags1', '600', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragp1', '599', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragm1', '598', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc8', '597', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc7', '596', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc6', '595', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc5', '594', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc4', '593', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc3', '592', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc2', '591', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ddragc1', '590', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crc', '589', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compatible', '588', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bin', '587', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082v2', '586', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082v1', '585', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082s1', '584', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082p1', '583', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082m1', '582', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c8', '581', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c7', '580', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c6', '579', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c5', '578', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c4', '577', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c3', '576', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c2', '575', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('082c1', '574', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('030p', '615', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('already', '616', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('d396c9cb', '617', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('folder', '618', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('replies', '619', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('winkawak', '620', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2020', '621', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('baseball', '622', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('particular', '623', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('super', '624', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blank', '625', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('changes', '626', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('column', '627', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('columns', '628', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('database', '629', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('delim', '630', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('delimitted', '631', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easier', '632', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('layout', '633', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('longer', '634', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('newer', '635', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rename', '636', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('second', '637', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supported', '638', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tab', '639', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('this', '640', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('updating', '641', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('verify', '642', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('statements', '650', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('people', '649', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('maintance', '648', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('caesar', '647', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2gb', '651', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('betatested', '652', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supossedly', '653', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('testing', '654', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wiped', '655', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easter', '656', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('egg', '657', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('regard', '658', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tools', '659', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sql', '660', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sweetness', '661', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crystal', '662', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dowload', '663', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kings', '664', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mx27l1000', '665', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thankz', '666', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('u14', '667', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bios', '668', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crysbios', '669', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asking', '670', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sorry', '671', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thr', '672', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('97', '673', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cps2', '674', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('renamed', '675', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sfz3a', '676', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supplements', '677', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supporting', '678', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gotta', '679', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hello', '680', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keep', '681', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ooops', '682', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raine', '683', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rules', '684', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('topic', '685', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0c12c2ad', '686', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0ce453a0', '687', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2004', '688', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('131072', '689', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('37bcd4d30f3892078b46841d895a6eff16dc921e', '690', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('4fa698e9', '691', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5dda0d84', '692', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('b24b44a0', '693', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cps2shock', '694', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('description', '695', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manufacturer', '696', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mistake', '697', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nonmame', '698', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('resource', '699', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sha1', '700', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('size', '701', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unibios', '702', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('universe', '703', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('v2', '704', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('year', '705', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1', '706', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('copypaste', '707', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('error', '708', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fix', '709', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hasnt', '710', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('includes', '711', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('posted', '712', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('specially', '713', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('details', '714', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('existance', '715', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ill', '716', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('include', '717', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mentioning', '718', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('next', '719', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('souledgb', '794', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('souledga', '793', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('so1sprg', '792', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('so1sprc', '791', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('report', '790', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('region', '789', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('proper', '788', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('let', '787', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('job', '786', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friends', '785', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('doing', '781', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('errors', '782', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('f6f682b7', '783', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('former', '784', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cpu2', '780', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('appropriate', '779', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('a64e19be3f6e630b8c34f34b46b95aadfabd3f63', '778', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2bbc118c', '777', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('262144', '776', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('souledge', '795', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tidying', '796', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('today', '797', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twos', '798', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whole', '799', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alzheimer', '800', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('change', '801', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('checked', '802', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('generated', '803', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lazy', '804', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lose', '805', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mamediffing', '806', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('might', '807', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relies', '808', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('remember', '809', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zincs', '810', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('against', '811', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('based', '812', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('checks', '813', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cmpro', '814', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compare', '815', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compared', '816', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consistency', '817', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('control', '818', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('created', '819', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('detect', '820', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faked', '821', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forgotten', '822', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('functionality', '823', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hand', '824', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('informed', '825', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interchanged', '826', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('letting', '827', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('listsets', '828', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mainly', '829', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('means', '830', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mentioned', '831', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('output', '832', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('procedures', '833', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quality', '834', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rarely', '835', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reason', '836', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sha1s', '837', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('slip', '838', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('switched', '839', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('therefore', '840', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('values', '841', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('add', '842', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comparison', '843', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('edit', '844', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('list', '845', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('notepad', '846', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('such', '847', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('todo', '848', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('low', '849', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nope', '850', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('priorities', '851', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bloody', '852', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('declare', '853', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forum', '854', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('healthy', '855', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hereby', '856', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('higienical', '857', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('infested', '858', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('internet', '859', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jerks', '860', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kiddiez', '861', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('knowmorethanyou', '862', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('n00bs', '863', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pests', '864', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('positive', '865', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trolls', '866', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('warez', '867', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clean', '868', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('living', '869', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alive', '870', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ban', '871', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('numbers', '872', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('read', '873', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thread', '874', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('views', '875', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('31', '876', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('36', '877', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('apologies', '878', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('appears', '879', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('binary', '880', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('concept', '881', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('confess', '882', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('confusion', '883', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('definitely', '884', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('determine', '885', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discovered', '886', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dismay', '887', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downloaded', '888', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eeproms', '889', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('existing', '890', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expect', '891', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('extension', '892', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('follow', '893', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forward', '894', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gamename', '895', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('generally', '896', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('impression', '897', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('input', '898', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('literally', '899', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('machines', '900', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mame32', '901', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mostly', '902', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('naming', '903', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('others', '904', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('palm', '905', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pattern', '906', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picked', '907', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('presumably', '908', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recognized', '909', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('redirects', '910', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reverse', '911', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reverting', '912', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('states', '913', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('successfully', '914', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('while', '915', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('always', '916', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('author', '917', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('base', '918', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('called', '919', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('changing', '920', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('circumstances', '921', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clrmame', '922', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('confusing', '923', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contents', '924', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('datfile', '925', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downdate', '926', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downgrade', '927', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dumped', '928', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('explain', '929', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('explained', '930', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faq', '931', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('folders', '932', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friend', '933', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('google', '934', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('holds', '935', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('information', '936', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interchangeably', '937', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('latest', '938', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loaded', '939', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('long', '940', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lower', '941', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manage', '942', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('managers', '943', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('many', '944', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('minor', '945', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('palmmame', '946', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('parentclone', '947', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('port', '948', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prepared', '949', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('proms', '950', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('properly', '951', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reasons', '952', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rebuilding', '953', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('redump', '954', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relationships', '955', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('replaced', '956', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('requirements', '957', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scan', '958', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shock', '959', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('treatment', '960', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tutorials', '961', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('undumpable', '962', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('you', '963', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('claimed', '964', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('correctly', '965', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('education', '966', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compatibility', '967', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('regardless', '968', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('20th', '969', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('98', '970', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('approximately', '971', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('he', '972', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jet', '973', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('july', '974', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lag', '975', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recovers', '976', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yeah', '977', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fortnight', '978', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nothingness', '979', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taken', '980', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('betcha', '981', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('choko', '982', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('done', '983', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forgot', '984', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('looks', '985', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seeing', '986', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vacation', '987', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wish', '988', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cuts', '989', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('datutil', '990', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('descriptions', '991', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discription', '992', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dutchman', '993', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('filename', '994', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flying', '995', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('longest', '996', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('revenge', '997', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spongebob', '998', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('squarepants', '999', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supersponge', '1000', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('truncates', '1001', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('download', '1002', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lengths', '1003', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('limits', '1004', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('onwards', '1005', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('string', '1006', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('web', '1007', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('upload', '1008', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2057', '1009', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('address', '1010', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('atm', '1011', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bar', '1012', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bit', '1013', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('noob', '1014', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reporting', '1015', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stupid', '1016', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wink', '1017', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('withouth', '1018', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yep', '1019', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fine', '1020', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prior', '1021', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rewrite', '1022', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('20', '1023', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('great', '1024', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uesed', '1025', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('961023', '1026', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fighter', '1027', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('street', '1028', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('usa', '1029', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xmen', '1030', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xor', '1031', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('150', '1032', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amp', '1033', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('approx', '1034', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('austria', '1035', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('away', '1036', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beginning', '1037', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bought', '1038', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('build', '1039', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buttons', '1040', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('choose', '1041', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coin', '1042', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('conect', '1043', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('connect', '1044', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('connet', '1045', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cop', '1046', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dead', '1047', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dream', '1048', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('especially', '1049', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eur', '1050', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('europe', '1051', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('example', '1052', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('furthermore', '1053', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('harddrive', '1054', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('house', '1055', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('insert', '1056', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('joystick', '1057', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lightguns', '1058', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('maschine', '1059', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('newbie', '1060', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('paralell', '1061', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pc', '1062', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pc2jamma', '1063', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pls', '1064', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('search', '1065', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shooter', '1066', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sincerly', '1067', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('the', '1068', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thoose', '1069', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tree', '1070', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('upgrade', '1071', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('virtua', '1072', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanna', '1073', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whre', '1074', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('01a', '1075', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('01b', '1076', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('01c', '1077', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('01d', '1078', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('03a', '1079', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('03b', '1080', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('03c', '1081', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('03d', '1082', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('05a', '1083', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('05b', '1084', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('9', '1085', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1995', '1086', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1996', '1087', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1999', '1088', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2003', '1089', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2005', '1090', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('524288', '1091', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('990527', '1092', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1048576', '1093', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2097152', '1094', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('4194304', '1095', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('20050606', '1096', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('20050712', '1097', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x0c12c2ad', '1098', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x1fe8c213', '1099', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x2cd141bf', '1100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x3aaeb90b', '1101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x4614a3b2', '1102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x4cb79672', '1103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x530ecc14', '1104', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x7f68b88a', '1105', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x8dabf76b', '1106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0x97894cea', '1107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xaec5b4a9', '1108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xb416fe96', '1109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xba0fe27b', '1110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xc23b6f22', '1111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xe29e4c26', '1112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xe5f2e14a', '1113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xec737d9d', '1114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xf6f682b7', '1115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0xfd568da9', '1116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('271p1c', '1117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('271p2c', '1118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('271p3c', '1119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allowed', '1120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asked', '1121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('capcom', '1122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('collectors', '1123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('edge', '1124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ep19231', '1125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exact', '1126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fighters', '1127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('haoh', '1128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('impossible', '1129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('japan', '1130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jgokushi', '1131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jukebox', '1132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jyangokushi', '1133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('king', '1134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kof2003a', '1135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('maj', '1136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('majj', '1137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('majsim', '1138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('miss', '1139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('model', '1140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mvs', '1141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('namco', '1142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nebula', '1143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('playmore', '1144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('problems', '1145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('request', '1146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('romof', '1147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saihai', '1148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sega', '1149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('snk', '1150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('so1', '1151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('so3', '1152', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('soul', '1153', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('step', '1154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thx', '1155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ver', '1156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vf3', '1157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wrong', '1158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('000', '1159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('100', '1160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2002', '1161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('able', '1162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ads', '1163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('apaches', '1164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('april', '1165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aspect', '1166', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('baddump', '1167', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('browsers', '1168', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cease', '1169', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('code', '1170', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coding', '1171', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compliant', '1172', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('december', '1173', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disks', '1174', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dormant', '1175', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('driver', '1176', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dull', '1177', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ending', '1178', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enjoy', '1179', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('extra', '1180', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('facility', '1181', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('february', '1182', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feel', '1183', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finished', '1184', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fun', '1185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('g', '1186', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('history', '1187', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('holiday', '1188', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('html', '1189', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hypersleep', '1190', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ice', '1191', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ideal', '1192', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('improved', '1193', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('improvements', '1194', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('integrity', '1195', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('issues', '1196', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lastly', '1197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('life', '1198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('linking', '1199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('logic', '1200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('managing', '1201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mangle', '1202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manner', '1203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manually', '1204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('miracles', '1205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('modrewrite', '1206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('month', '1207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moved', '1208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mysql', '1209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nodump', '1210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('november', '1211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pages', '1212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('past', '1213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('period', '1214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('php', '1215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('powerful', '1216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pretty', '1217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('project', '1218', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('puckman', '1219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('queries', '1220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ratio', '1221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reccomend', '1222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('remapped', '1223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rendered', '1224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('requirement', '1225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('server', '1226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('setting', '1227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shtml', '1228', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('snaps', '1229', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('started', '1230', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('style', '1231', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('summer', '1232', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('task', '1233', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('test', '1234', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uncover', '1235', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('urls', '1236', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visible', '1237', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wished', '1238', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wohooo', '1239', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('worked', '1240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wow', '1241', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xhtml', '1242', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('years', '1243', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ztnet', '1244', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adding', '1245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('congrats', '1246', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crossposting', '1247', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finishing', '1248', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hundred', '1249', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mile', '1250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('start', '1251', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trimming', '1252', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('august', '1253', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cancel', '1254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dude', '1255', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('instead', '1256', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spain', '1257', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suppose', '1258', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('supposed', '1259', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trip', '1260', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visiting', '1261', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('answers', '1262', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('apparently', '1263', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brief', '1264', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exist', '1265', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exists', '1266', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('given', '1267', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoarded', '1268', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rereleased', '1269', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shortly', '1270', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('typos', '1271', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xacrow', '1272', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rest', '1273', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('issue', '1274', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('10', '1275', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('12', '1276', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('42', '1277', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('99', '1278', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asteroidsgl', '1279', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('battlezonegl', '1280', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('completely', '1281', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corresponding', '1282', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daphne', '1283', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('edition', '1284', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rebound', '1285', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('robot', '1286', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tempestgl', '1287', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tickle', '1288', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vantage', '1289', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('waiting', '1290', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brit', '1291', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('decision', '1292', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drunk', '1293', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wise', '1356', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sound1', '1355', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saying', '1354', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('paste', '1353', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pacman', '1352', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('midway', '1351', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gfx2', '1350', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gfx1', '1349', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('f45fbbcd', '1348', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cpu1', '1347', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('c82cd714', '1346', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('c1e6ab10', '1345', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bellow', '1344', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bcdd1beb', '1343', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('a9cc86bf', '1342', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('a90e7000', '1341', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('958fedf9', '1340', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('82s126', '1339', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('82s123', '1338', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('817d94e3', '1337', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('77245b66', '1336', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('615af909', '1335', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5c281d01', '1334', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fixs', '1317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('4096', '1333', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('3eb3a8e4', '1332', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2fc650bd', '1331', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2048', '1330', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1980', '1329', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('256', '1328', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1a6fb2d4', '1327', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('0c944964', '1326', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alarms', '1357', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('avoid', '1358', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clone', '1359', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('false', '1360', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forcemerging', '1361', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('glad', '1362', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lunch', '1363', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mspacman', '1364', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('necessary', '1365', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reading', '1366', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reported', '1367', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('source', '1368', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suggest', '1369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ways', '1370', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('current', '1371', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('free', '1372', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frontpage', '1373', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gagaplay', '1374', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gt', '1375', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jemu2', '1376', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nice', '1377', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('target', '1378', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visit', '1379', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relevant', '1380', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weekend', '1381', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emulated', '1382', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gonna', '1383', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pii500', '1384', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rush', '1385', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sanfran', '1386', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('threads', '1387', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uhmmmm', '1388', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uhmmmmm', '1389', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xxxx', '1390', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ages', '1391', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('annoying', '1392', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beneath', '1393', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blue', '1394', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('css', '1395', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('due', '1396', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frames', '1397', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fully', '1398', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('individual', '1399', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('links', '1400', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('massively', '1401', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('minimise', '1402', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('removal', '1403', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('simpler', '1404', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('slightly', '1405', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('throughout', '1406', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('transitional', '1407', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanting', '1408', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('splits', '1430', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sounds', '1429', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('settings', '1428', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('samples', '1427', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('redone', '1426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ms', '1425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lates', '1424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('following', '1423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('default', '1422', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('came', '1421', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('archives', '1420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unless', '1432', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amoad', '1433', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discussed', '1434', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drum', '1435', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('early', '1436', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hey', '1437', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('importing', '1438', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jeff', '1439', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('john', '1440', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mitchells', '1441', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('progress', '1442', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('support', '1443', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('03', '1444', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('06', '1445', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('07', '1446', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('08', '1447', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('18', '1448', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('033', '1449', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('40', '1450', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('43', '1451', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('47', '1452', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('094', '1453', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('140', '1454', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('165', '1455', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('186', '1456', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('234', '1457', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('324', '1458', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('391', '1459', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('528', '1460', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('590', '1461', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('800', '1462', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('848', '1463', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('919', '1464', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2001', '1465', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2076c3cb', '1466', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bytes', '1467', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('deleting', '1468', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dir', '1469', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drive', '1470', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exe', '1471', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('extracting', '1472', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('f', '1473', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('listed', '1474', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('perhaps', '1475', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('readme', '1476', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recognises', '1477', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rezipping', '1478', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('runs', '1479', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('serial', '1480', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('total', '1481', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vol', '1482', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wierd', '1483', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bereavement', '1484', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('catalog', '1485', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contact', '1486', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('deal', '1487', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('family', '1488', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hold', '1489', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keen', '1490', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lost', '1491', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('love', '1492', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rerite', '1493', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touch', '1494', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('told', '1510', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rezip', '1509', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fixes', '1508', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downloading', '1507', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cmp371d', '1506', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2kb', '1505', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('24kb', '1504', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('21', '1503', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zipping', '1511', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allessandro', '1512', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scotti', '1513', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scottis', '1514', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('warn', '1515', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zlib', '1516', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('willy', '1845', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('williams', '1844', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vecsim', '1843', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('variety', '1842', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vanguard6', '1841', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vanguard', '1840', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('us', '1839', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unreleased', '1838', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('txi390b', '1837', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tim', '1836', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('three', '1835', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thinking', '1834', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tape', '1833', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talked', '1832', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talk', '1831', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('system16', '1830', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('symbian', '1829', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('storm', '1828', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('storage', '1827', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stopped', '1826', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stiletto', '1825', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('steve', '1824', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stargate', '1823', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('special', '1822', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smith', '1821', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sending', '1820', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seal103b', '1819', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('save', '1818', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('safe', '1817', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('resurrecting', '1816', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('received', '1815', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reaper2k2', '1814', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rainnie', '1813', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('projects', '1812', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('popcorn', '1811', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plus', '1810', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pinball', '1809', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phoenix', '1808', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('penta', '1807', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pengo', '1806', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('patrol', '1805', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('backlog', '1558', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pacpackdc', '1804', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('okay', '1803', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nor', '1802', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neogem', '1801', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nb2', '1800', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('naughty', '1799', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('music', '1798', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mrdosaga', '1797', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('motherlode', '1796', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moon', '1795', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('module', '1794', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('millipedge', '1793', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('milli01', '1792', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mentions', '1791', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mention', '1790', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('md5', '1789', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('master', '1788', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mak375b', '1787', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('macdonald', '1786', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('looseends', '1785', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('located', '1784', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('locate', '1783', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lgp271b', '1782', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('left', '1781', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kung', '1780', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kossow', '1779', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kong020', '1778', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kong', '1777', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('junoboot', '1776', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jons', '1775', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jonathan', '1774', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('joe', '1773', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('invaders', '1772', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('historyarcadestatic', '1771', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hedley', '1770', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hawley', '1769', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hardy', '1768', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gpp2721b', '1767', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gcc281b', '1766', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('final', '1765', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('execfilter', '1764', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everything', '1763', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eric', '1762', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('encrypted', '1761', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emame', '1760', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emailed', '1759', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('email', '1758', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('e2mame', '1757', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dreamcast', '1756', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('doulators', '1755', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dos', '1754', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('donkey', '1753', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('djdev201', '1752', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('devices', '1751', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('deitch', '1750', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('defender', '1749', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('decryption', '1748', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dagulator', '1747', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('csdpmi3b', '1746', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crc32', '1745', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consumed', '1744', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compile', '1743', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('close', '1742', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cloak', '1741', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cleared', '1740', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cinemu', '1739', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cinem', '1738', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chris', '1737', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charles', '1736', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cgibin', '1735', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cgi', '1734', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('centsim', '1733', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cdr', '1732', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('built', '1731', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bugliarisi', '1730', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('britt', '1729', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boy', '1728', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bnu281b', '1727', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blog', '1726', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beta', '1725', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('backup', '1724', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attack', '1723', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arcadecollecting', '1722', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('apps', '1721', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyhow', '1720', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amusing', '1719', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amoad22', '1718', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amoad20', '1717', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alpha', '1716', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alleg30', '1715', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alien', '1714', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('according', '1713', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1998', '1712', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1997', '1711', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('929', '1710', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('896', '1709', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('719', '1708', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('706', '1707', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('681', '1706', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('638', '1705', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('606', '1704', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('538', '1703', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('531', '1702', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('527', '1701', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('466', '1700', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('445', '1699', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('315', '1698', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('311', '1697', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('295', '1696', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('264', '1695', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('248', '1694', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('209', '1693', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('185', '1692', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('46', '1691', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('045', '1690', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('44', '1689', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('29', '1688', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('27', '1687', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('25', '1686', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('022', '1685', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('11', '1684', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('01', '1683', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('windows', '1846', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('worth', '1847', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xphoenix', '1848', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actual', '1849', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('benefits', '1850', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brings', '1851', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('classic', '1852', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disproportional', '1853', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('emus', '1854', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('existed', '1855', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hobbies', '1856', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('limited', '1857', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mechanics', '1858', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('proposition', '1859', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sent', '1860', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('simply', '1861', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('simulation', '1862', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spending', '1863', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('view', '1864', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('404', '1865', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('access', '1866', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('additionally', '1867', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('encountered', '1868', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('errordocument', '1869', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forbidden', '1870', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('handle', '1871', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happening', '1872', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('homepage', '1873', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mamebeta', '1874', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('permission', '1875', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('romcenters', '1876', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('44761', '1880', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5', '1879', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dll', '1881', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expanded', '1882', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fpart', '1883', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vc', '1884', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('6', '1885', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('44891', '1886', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('putting', '1887', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('website', '1888', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('browser', '1889', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trouble', '1890', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arrives', '1891', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('five', '1892', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('imagine', '1893', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('m1', '1894', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meantime', '1895', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('basically', '1896', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blocked', '1897', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('causing', '1898', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clicking', '1899', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hotlink', '1900', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('intercepts', '1901', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prevention', '1902', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('provided', '1903', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('referals', '1904', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('referer', '1905', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('requested', '1906', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whatever', '1907', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wait', '1908', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('night', '1909', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('circular', '1910', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cloneof', '1911', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hang', '1912', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('occurred', '1913', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('17', '1914', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recompiled', '1915', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('7', '1916', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('v0', '1917', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guides', '1918', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('importantly', '1919', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('libpng', '1920', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('libraries', '1921', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mingw', '1922', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ports', '1923', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tool', '1924', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('miissing', '1930', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kick', '1929', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('7pre5', '1928', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('releaase', '1931', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('doubt', '1932', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mike', '1933', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wednesday', '1934', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('morning', '1935', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('murphy', '1936', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('newsboard', '1937', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('irc', '1938', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bard33', '1939', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('channel', '1940', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chatting', '1941', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hear', '1942', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lasergames', '1943', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hazes', '1944', '0');
#
# TABLE: phpbb_search_wordmatch
#
DROP TABLE IF EXISTS phpbb_search_wordmatch;
CREATE TABLE phpbb_search_wordmatch(
	post_id mediumint(8) unsigned NOT NULL,
	word_id mediumint(8) unsigned NOT NULL,
	title_match tinyint(1) NOT NULL, 
	KEY post_id (post_id), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordmatch
#

INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '17', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '16', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '15', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '15', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '16', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '17', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '15', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '16', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '17', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '24', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '26', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '21', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '91', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '76', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '75', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '72', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '69', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '71', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '72', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '79', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '82', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '84', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '86', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '87', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('12', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '65', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '96', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '97', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '66', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '106', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('16', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '126', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '143', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('18', '148', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '228', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '234', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '235', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '241', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '244', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '246', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '248', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '249', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '251', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '252', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '255', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '257', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '258', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '259', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '262', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '263', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '266', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '267', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '268', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '269', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '270', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '271', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '272', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '273', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '274', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '276', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '277', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '278', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '281', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '283', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '285', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '286', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '289', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '291', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '292', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '293', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '297', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '126', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '143', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '148', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '303', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '304', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '311', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '16', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '315', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '316', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '318', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '319', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '321', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '323', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '324', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '325', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '326', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '327', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '328', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '330', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '331', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '332', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '333', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '335', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '336', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '333', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '332', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '414', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '336', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '412', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '409', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '354', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '357', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '358', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '363', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '365', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '353', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '371', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '353', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '375', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '327', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '328', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '385', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '387', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '388', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '394', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '396', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '398', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '399', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '400', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '401', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '394', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '419', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '428', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '431', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '443', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '433', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '445', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '449', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '453', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '462', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '464', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '465', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '466', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '467', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '468', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '469', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '470', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '472', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '473', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '474', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '475', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '476', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '477', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '478', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '479', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '481', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '475', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '476', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '477', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '478', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '475', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '476', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '479', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '574', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '575', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '576', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '577', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '578', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '579', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '580', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '581', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '582', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '583', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '584', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '585', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '586', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '588', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '590', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '591', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '592', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '593', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '594', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '595', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '596', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '597', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '598', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '599', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '600', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '601', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '602', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '603', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '604', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '605', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '606', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '610', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '611', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '612', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('45', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '615', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '617', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '619', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '620', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '621', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '622', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '475', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '476', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '623', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '624', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '625', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '627', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '628', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '631', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '268', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '633', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '636', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '637', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '638', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '639', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '640', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '642', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '630', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '633', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '433', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '639', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '648', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('49', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '654', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '655', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '656', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '657', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '658', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '269', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '660', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '661', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '662', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '663', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '664', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '665', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '666', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '667', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '76', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '665', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '667', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('54', '668', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('54', '669', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('54', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('54', '243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('54', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '670', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '671', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '672', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('55', '671', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '673', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '674', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '675', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '676', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '677', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '678', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '673', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('56', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '673', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '682', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '684', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '685', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '680', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '686', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '687', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '689', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '688', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '690', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '691', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '692', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '693', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '668', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '694', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '696', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '699', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '90', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '697', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '282', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '700', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('59', '702', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '711', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '715', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '717', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '718', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '799', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '798', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '795', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '791', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '790', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '788', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '786', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '785', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '784', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '783', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '780', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '779', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '778', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '777', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('62', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '802', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '268', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '804', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '805', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '806', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '808', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '813', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '815', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '817', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '818', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '822', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '823', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '824', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '825', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '826', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '827', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '828', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '829', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '830', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '831', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '400', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '832', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '833', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '834', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '835', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '836', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '837', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '838', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '839', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '840', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '813', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '815', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '843', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '817', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '818', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '844', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '829', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '846', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '833', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '834', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '837', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '838', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '840', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '851', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '852', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '853', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '854', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '855', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '856', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '857', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '858', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '860', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '862', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '863', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '864', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '866', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '867', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '215', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '865', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '868', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '869', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '870', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '871', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '872', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '873', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '874', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '875', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '71', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '623', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '854', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '876', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '877', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '878', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '879', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '880', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '881', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '882', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '884', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '885', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '886', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '887', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '888', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '890', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '891', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '893', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '895', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '897', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '898', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '899', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '900', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '901', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '902', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '903', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '904', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '906', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '907', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '908', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '909', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '910', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '911', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '913', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '914', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '883', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '16', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '370', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '24', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '673', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '717', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '876', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '877', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '917', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '920', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '922', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '923', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '924', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '925', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '926', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '928', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '929', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '931', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '932', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '933', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '934', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '935', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '937', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '939', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '941', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '942', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '943', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '944', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '945', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '947', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '948', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '949', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '950', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '951', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '952', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '953', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '954', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '955', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '956', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '957', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '958', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '959', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '960', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '961', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '962', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '963', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '964', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '965', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '966', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '904', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('72', '177', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '877', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '967', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '968', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '969', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '971', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '891', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '972', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '973', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '975', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '976', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '970', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '977', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '978', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '980', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('76', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '981', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '982', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '674', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '986', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '671', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '987', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '988', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '674', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '332', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '984', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '985', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '922', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '989', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '992', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '993', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '994', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '995', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '895', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '996', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '997', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '611', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '998', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '999', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '1000', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '990', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '991', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '1001', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1003', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1004', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1005', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1006', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '1007', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '984', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '1008', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1009', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1011', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1012', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1013', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1014', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1015', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '671', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1016', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1017', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1018', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '1019', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '1020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '1021', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '1022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '1023', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '1024', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '1025', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '674', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '959', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1031', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1026', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1027', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1028', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1029', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '1030', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1032', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1035', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1037', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1038', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1040', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1042', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1043', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1044', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1045', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1046', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1047', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1048', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1049', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1050', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1051', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1052', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '79', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '477', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1054', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1055', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '277', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1058', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1059', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '902', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '478', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1061', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1062', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1063', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1066', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1067', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1068', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1069', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1070', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1071', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1073', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '143', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1060', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '1064', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '624', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '668', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '674', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '680', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '689', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '694', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '696', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1027', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1075', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1076', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1077', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1078', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1080', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1081', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1082', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1083', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1084', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1085', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1086', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1087', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1088', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1090', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1092', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1094', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1095', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1096', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1097', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1098', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '75', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '782', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '1129', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '17', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '829', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '980', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1228', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1234', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1235', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1241', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1244', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '647', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '1215', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '829', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '980', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1228', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1234', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1235', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1241', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1244', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '647', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '1215', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '871', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1246', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1248', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1249', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1251', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '1252', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1255', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1257', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1258', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1259', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '1261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1096', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1097', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1085', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1092', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1262', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1263', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '668', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '674', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '269', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1266', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1027', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1267', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1268', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1269', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1270', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1271', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1272', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '75', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '782', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '1129', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '17', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '1273', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '1155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1255', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1257', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1258', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1259', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '1261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '977', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '1145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '980', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '1274', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1276', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1277', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1278', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1281', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1283', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1285', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1286', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1289', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '647', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '370', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1291', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1292', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1293', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1317', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1284', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1354', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1285', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '950', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '696', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1348', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1346', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1345', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1344', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1343', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1342', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1341', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1340', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1339', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1338', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1336', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1335', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1333', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1331', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1328', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1330', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1327', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1326', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1285', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1288', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1357', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1358', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1363', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1365', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '836', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '1371', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '953', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '625', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1375', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '678', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1376', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '94', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1278', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '83', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1090', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '670', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '479', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1385', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1387', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1388', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1394', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1398', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1399', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1400', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1401', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1068', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '468', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1428', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '873', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '880', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1286', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1443', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1449', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1445', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1453', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1465', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '688', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1090', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1466', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '876', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1462', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1464', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1467', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1468', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1469', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1470', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1472', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1473', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1474', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1475', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1476', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1477', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1478', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1479', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1481', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1494', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1510', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '671', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1509', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1024', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1507', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1506', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1505', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1504', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1503', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '1511', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('110', '23', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1512', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1513', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1516', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1846', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1684', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1685', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1686', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1687', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1688', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1689', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1690', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1691', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1692', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1693', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1694', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1696', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1697', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1699', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1711', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1715', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1717', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1718', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1720', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1721', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1722', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1723', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1724', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1725', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1726', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1727', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1728', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1729', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1730', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1731', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1732', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1734', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1735', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1736', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1737', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1738', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1740', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1741', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1743', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1744', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1745', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1746', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1747', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1748', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1749', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1750', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1751', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1752', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1753', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1754', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1755', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1756', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1757', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1758', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1759', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1760', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1761', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1762', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1763', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1764', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1765', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1766', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1767', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1768', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1769', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1770', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1771', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1772', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1773', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1774', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1775', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1777', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1778', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1779', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1780', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1783', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1784', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1785', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1786', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1788', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1790', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1791', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1795', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1798', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1799', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1802', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1804', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1805', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1806', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1808', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1813', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1815', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1817', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1818', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1822', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1823', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1824', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1825', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1826', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1827', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1828', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1829', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1830', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1831', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1832', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1833', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1834', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1835', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1836', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1837', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1838', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1839', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1840', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1843', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1844', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1494', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1476', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1445', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1281', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1068', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1023', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '972', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '948', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '880', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '831', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '670', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '470', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '394', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '333', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '293', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1558', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1851', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1852', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1748', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '884', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1853', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1758', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1854', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1763', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1855', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1856', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '786', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '827', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1857', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1474', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1858', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1806', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1860', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1862', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1863', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1843', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1864', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1865', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1278', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1866', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1867', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1868', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1869', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1870', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1871', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1872', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1873', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '681', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1874', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1875', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1876', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '75', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1002', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1883', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1882', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1881', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1879', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1880', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1884', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1864', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '68', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1879', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '75', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '279', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '115', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1886', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1879', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1882', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1883', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1887', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1884', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1864', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1888', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '68', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1885', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1508', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1507', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1890', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1866', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1891', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1893', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1895', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '671', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1897', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1898', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1899', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '965', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1871', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1900', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1901', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1902', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1903', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1904', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1906', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1007', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1907', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1908', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1909', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '288', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1910', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1911', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1913', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '955', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1885', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '305', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1885', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1910', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1911', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1913', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '955', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1914', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1448', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '990', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '433', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1451', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '683', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '1885', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '1917', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1916', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '68', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('128', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('128', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('128', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '1916', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '1917', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1743', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1920', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1743', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1918', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1923', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1924', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1451', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1916', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1921', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1922', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '683', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1917', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1931', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1929', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1908', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1928', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1278', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1283', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1932', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1933', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1934', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1935', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1937', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1087', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1095', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '695', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1027', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '477', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '696', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '478', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '1265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1939', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1941', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1942', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1943', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1935', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1937', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '1451', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '139', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '1944', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '683', '1');
#
# TABLE: phpbb_sessions
#
DROP TABLE IF EXISTS phpbb_sessions;
CREATE TABLE phpbb_sessions(
	session_id char(32) NOT NULL,
	session_user_id mediumint(8) NOT NULL,
	session_start int(11) NOT NULL,
	session_time int(11) NOT NULL,
	session_ip char(8) NOT NULL,
	session_page int(11) NOT NULL,
	session_logged_in tinyint(1) NOT NULL, 
	PRIMARY KEY (session_id), 
	KEY session_user_id (session_user_id), 
	KEY session_id_ip_user_id (session_id, session_ip, session_user_id)
);

#
# Table Data for phpbb_sessions
#

INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('ef0f8146ec40bbadcab644ba60807332', '4', '1126001478', '1126002276', '53d5305f', '0', '1');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('8b6e68ed0efd1792288f630b191f012f', '3', '1126003472', '1126003472', 'c29f1fa5', '0', '1');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('345660cea1d21ef8687d64dae31e586d', '-1', '1126000616', '1126000616', 'cf2e622c', '-4', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('6b9ba135521a4ab663496f0aad80a401', '-1', '1126001916', '1126001916', 'cf2e622c', '-4', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('caeb1585083c87da7967de61a69cb83a', '3', '1126003862', '1126003956', 'c29f1fa5', '0', '1');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('4f5a1744c2eaec70a5d2da9c49399f6d', '-1', '1126001170', '1126001170', 'cf2e622c', '-4', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('92f6b16f50d25152835b3634e05300b8', '-1', '1126002728', '1126002728', 'cf2e622c', '-4', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in) VALUES('3231123cb3ff1d91e2483c78dfaeb3f8', '-1', '1126001619', '1126001619', 'cf2e622c', '14', '0');
#
# TABLE: phpbb_smilies
#
DROP TABLE IF EXISTS phpbb_smilies;
CREATE TABLE phpbb_smilies(
	smilies_id smallint(5) unsigned NOT NULL auto_increment,
	code varchar(50),
	smile_url varchar(100),
	emoticon varchar(75), 
	PRIMARY KEY (smilies_id)
);

#
# Table Data for phpbb_smilies
#

INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('1', ':D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('2', ':-D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('3', ':grin:', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('4', ':)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('5', ':-)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('6', ':smile:', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('7', ':(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('8', ':-(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('9', ':sad:', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('10', ':o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('11', ':-o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('12', ':eek:', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('13', ':shock:', 'icon_eek.gif', 'Shocked');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('14', ':?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('15', ':-?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('16', ':???:', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('17', '8)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('18', '8-)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('19', ':cool:', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('20', ':lol:', 'icon_lol.gif', 'Laughing');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('21', ':x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('22', ':-x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('23', ':mad:', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('24', ':P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('25', ':-P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('26', ':razz:', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('27', ':oops:', 'icon_redface.gif', 'Embarassed');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('28', ':cry:', 'icon_cry.gif', 'Crying or Very sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('29', ':evil:', 'icon_evil.gif', 'Evil or Very Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('30', ':twisted:', 'icon_twisted.gif', 'Twisted Evil');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('31', ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('32', ':wink:', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('33', ';)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('34', ';-)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('35', ':!:', 'icon_exclaim.gif', 'Exclamation');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('36', ':?:', 'icon_question.gif', 'Question');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('37', ':idea:', 'icon_idea.gif', 'Idea');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('38', ':arrow:', 'icon_arrow.gif', 'Arrow');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('39', ':|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('40', ':-|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('41', ':neutral:', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('42', ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green');
#
# TABLE: phpbb_themes
#
DROP TABLE IF EXISTS phpbb_themes;
CREATE TABLE phpbb_themes(
	themes_id mediumint(8) unsigned NOT NULL auto_increment,
	template_name varchar(30) NOT NULL,
	style_name varchar(30) NOT NULL,
	head_stylesheet varchar(100),
	body_background varchar(100),
	body_bgcolor varchar(6),
	body_text varchar(6),
	body_link varchar(6),
	body_vlink varchar(6),
	body_alink varchar(6),
	body_hlink varchar(6),
	tr_color1 varchar(6),
	tr_color2 varchar(6),
	tr_color3 varchar(6),
	tr_class1 varchar(25),
	tr_class2 varchar(25),
	tr_class3 varchar(25),
	th_color1 varchar(6),
	th_color2 varchar(6),
	th_color3 varchar(6),
	th_class1 varchar(25),
	th_class2 varchar(25),
	th_class3 varchar(25),
	td_color1 varchar(6),
	td_color2 varchar(6),
	td_color3 varchar(6),
	td_class1 varchar(25),
	td_class2 varchar(25),
	td_class3 varchar(25),
	fontface1 varchar(50),
	fontface2 varchar(50),
	fontface3 varchar(50),
	fontsize1 tinyint(4),
	fontsize2 tinyint(4),
	fontsize3 tinyint(4),
	fontcolor1 varchar(6),
	fontcolor2 varchar(6),
	fontcolor3 varchar(6),
	span_class1 varchar(25),
	span_class2 varchar(25),
	span_class3 varchar(25),
	img_size_poll smallint(5) unsigned,
	img_size_privmsg smallint(5) unsigned, 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes
#

INSERT INTO phpbb_themes (themes_id, template_name, style_name, head_stylesheet, body_background, body_bgcolor, body_text, body_link, body_vlink, body_alink, body_hlink, tr_color1, tr_color2, tr_color3, tr_class1, tr_class2, tr_class3, th_color1, th_color2, th_color3, th_class1, th_class2, th_class3, td_color1, td_color2, td_color3, td_class1, td_class2, td_class3, fontface1, fontface2, fontface3, fontsize1, fontsize2, fontsize3, fontcolor1, fontcolor2, fontcolor3, span_class1, span_class2, span_class3, img_size_poll, img_size_privmsg) VALUES('1', 'subSilver', 'subSilver', 'subSilver.css', '', 'E5E5E5', '000000', '006699', '5493B4', '', 'DD6900', 'EFEFEF', 'DEE3E7', 'D1D7DC', '', '', '', '98AAB1', '006699', 'FFFFFF', 'cellpic1.gif', 'cellpic3.gif', 'cellpic2.jpg', 'FAFAFA', 'FFFFFF', '', 'row1', 'row2', '', 'Verdana, Arial, Helvetica, sans-serif', 'Trebuchet MS', 'Courier, \'Courier New\', sans-serif', '10', '11', '12', '444444', '006600', 'FFA34F', '', '', '', NULL, NULL);
#
# TABLE: phpbb_themes_name
#
DROP TABLE IF EXISTS phpbb_themes_name;
CREATE TABLE phpbb_themes_name(
	themes_id smallint(5) unsigned NOT NULL,
	tr_color1_name char(50),
	tr_color2_name char(50),
	tr_color3_name char(50),
	tr_class1_name char(50),
	tr_class2_name char(50),
	tr_class3_name char(50),
	th_color1_name char(50),
	th_color2_name char(50),
	th_color3_name char(50),
	th_class1_name char(50),
	th_class2_name char(50),
	th_class3_name char(50),
	td_color1_name char(50),
	td_color2_name char(50),
	td_color3_name char(50),
	td_class1_name char(50),
	td_class2_name char(50),
	td_class3_name char(50),
	fontface1_name char(50),
	fontface2_name char(50),
	fontface3_name char(50),
	fontsize1_name char(50),
	fontsize2_name char(50),
	fontsize3_name char(50),
	fontcolor1_name char(50),
	fontcolor2_name char(50),
	fontcolor3_name char(50),
	span_class1_name char(50),
	span_class2_name char(50),
	span_class3_name char(50), 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes_name
#

INSERT INTO phpbb_themes_name (themes_id, tr_color1_name, tr_color2_name, tr_color3_name, tr_class1_name, tr_class2_name, tr_class3_name, th_color1_name, th_color2_name, th_color3_name, th_class1_name, th_class2_name, th_class3_name, td_color1_name, td_color2_name, td_color3_name, td_class1_name, td_class2_name, td_class3_name, fontface1_name, fontface2_name, fontface3_name, fontsize1_name, fontsize2_name, fontsize3_name, fontcolor1_name, fontcolor2_name, fontcolor3_name, span_class1_name, span_class2_name, span_class3_name) VALUES('1', 'The lightest row colour', 'The medium row color', 'The darkest row colour', '', '', '', 'Border round the whole page', 'Outer table border', 'Inner table border', 'Silver gradient picture', 'Blue gradient picture', 'Fade-out gradient on index', 'Background for quote boxes', 'All white areas', '', 'Background for topic posts', '2nd background for topic posts', '', 'Main fonts', 'Additional topic title font', 'Form fonts', 'Smallest font size', 'Medium font size', 'Normal font size (post body etc)', 'Quote & copyright text', 'Code text colour', 'Main table header text colour', '', '', '');
#
# TABLE: phpbb_topics
#
DROP TABLE IF EXISTS phpbb_topics;
CREATE TABLE phpbb_topics(
	topic_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(8) unsigned NOT NULL,
	topic_title char(60) NOT NULL,
	topic_poster mediumint(8) NOT NULL,
	topic_time int(11) NOT NULL,
	topic_views mediumint(8) unsigned NOT NULL,
	topic_replies mediumint(8) unsigned NOT NULL,
	topic_status tinyint(3) NOT NULL,
	topic_vote tinyint(1) NOT NULL,
	topic_type tinyint(3) NOT NULL,
	topic_first_post_id mediumint(8) unsigned NOT NULL,
	topic_last_post_id mediumint(8) unsigned NOT NULL,
	topic_moved_id mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (topic_id), 
	KEY forum_id (forum_id), 
	KEY topic_moved_id (topic_moved_id), 
	KEY topic_status (topic_status), 
	KEY topic_type (topic_type)
);

#
# Table Data for phpbb_topics
#

INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('8', '14', 'Do not ask where to find ROMs. No ROM Requests!', '3', '1112999523', '1031', '0', '1', '0', '1', '8', '8', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('4', '15', 'Do not ask where to find ROMs. No ROM Requests!', '3', '1112912141', '1029', '0', '1', '0', '1', '4', '4', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('5', '12', 'Do not ask where to find ROMs. No ROM Requests!', '3', '1112912200', '984', '0', '1', '0', '1', '5', '5', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('10', '15', 'Pacifi 3D new version...', '4', '1113250486', '1415', '2', '0', '0', '0', '11', '17', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('7', '1', 'New Forums', '3', '1112912388', '1038', '0', '1', '0', '2', '7', '7', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('11', '14', 'Chasing dat file for MAME v0.84', '9', '1113262181', '1352', '1', '0', '0', '0', '12', '13', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('12', '15', 'It\'s getting dangerous', '4', '1113408729', '1647', '2', '0', '0', '0', '14', '22', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('13', '1', 'Pacifi3D v0.3', '3', '1113420068', '1051', '0', '0', '0', '2', '16', '16', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('14', '15', 'Help me with this compelling idea!', '14', '1113514182', '1628', '2', '0', '0', '0', '18', '20', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('15', '9', 'Core for a rom manager?', '4', '1114001881', '740', '0', '0', '0', '0', '23', '23', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('16', '15', 'As a moderator, I check these boards several times a day...', '4', '1114267323', '2336', '6', '0', '0', '0', '24', '36', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('17', '12', 'Is there a place to find old MAME DATs?', '20', '1114635760', '1773', '3', '0', '0', '0', '27', '30', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('18', '15', 'MAME 0.96', '4', '1115146949', '959', '0', '0', '0', '0', '31', '31', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('19', '1', 'MAME v0.96', '3', '1115497456', '890', '0', '0', '0', '0', '32', '32', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('20', '6', 'So does ROMBuild do Zinc anymore?', '25', '1116171568', '903', '1', '0', '0', '0', '37', '38', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('21', '3', 'MameDiff Question', '26', '1116369124', '1162', '2', '0', '0', '0', '39', '41', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('22', '15', 'Double Dragon(Neo Geo)', '29', '1117002358', '1754', '5', '0', '0', '0', '42', '47', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('23', '3', 'mamediff tab delim layout', '31', '1117223179', '1485', '4', '0', '0', '0', '48', '52', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('24', '15', 'mx27l1000.u14 file', '32', '1117809249', '1350', '2', '0', '0', '0', '53', '55', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('25', '1', 'MAME v0.97', '3', '1118093293', '782', '1', '0', '0', '0', '56', '57', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('26', '15', 'Hello, is anybody there?', '4', '1118511919', '690', '0', '0', '0', '0', '58', '58', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('27', '12', 'An sha1 mistake about uni-bios in NeoGeo data for cm?', '34', '1118580023', '1994', '8', '0', '0', '0', '59', '94', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('28', '15', 'Well, at least there\'s something positive...', '4', '1119453086', '911', '2', '0', '0', '0', '67', '69', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('29', '15', 'Confusion about ROM updates', '41', '1120140689', '1038', '3', '0', '0', '0', '70', '73', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('31', '1', 'MAME 0.98', '4', '1121117395', '725', '2', '0', '0', '0', '74', '76', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('32', '12', 'Looks like you forgot the CPS2 dats.....', '45', '1121474606', '545', '1', '0', '0', '0', '77', '80', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('33', '3', 'datutil truncates descriptions?', '46', '1121593900', '857', '4', '0', '0', '0', '78', '83', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('34', '15', 'X-Men Vs. Street Fighter (USA 961023)', '34', '1122001000', '399', '0', '0', '0', '0', '84', '84', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('35', '15', 'i\'m a newbie pls help', '47', '1122277699', '381', '0', '0', '0', '0', '85', '85', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('36', '12', 'DAT Errors or Impossible to find roms?', '48', '1122680833', '630', '5', '0', '0', '0', '86', '136', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('37', '1', 'CAESAR gone PHP!', '3', '1122718139', '537', '0', '0', '0', '2', '87', '87', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('38', '15', 'CAESAR gone PHP!', '3', '1122718186', '664', '4', '0', '0', '2', '88', '97', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('39', '15', 'CAESAR Updates', '3', '1122838669', '616', '4', '0', '0', '0', '96', '113', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('40', '12', 'Tickle Rebound Edition is fixs.', '49', '1122967936', '714', '7', '0', '0', '0', '98', '111', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('41', '15', 'JEmu2 online', '4', '1123089979', '304', '0', '0', '0', '0', '101', '101', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('42', '1', 'MAME v0.99', '3', '1123492506', '274', '0', '0', '0', '0', '102', '102', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('43', '15', 'Uhmmmm....', '4', '1123845823', '239', '0', '0', '0', '0', '103', '103', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('44', '1', 'New Look', '3', '1124405718', '147', '0', '0', '0', '2', '104', '104', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('45', '14', 'dat download', '51', '1124827102', '243', '3', '0', '0', '0', '114', '121', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('46', '12', 'M1 0.7.5 is out. But I try to make a dat and it won\'t do it.', '49', '1124830420', '288', '6', '0', '0', '0', '115', '128', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('47', '9', 'DatLib v2.6', '3', '1125519456', '59', '0', '0', '0', '0', '122', '122', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('48', '3', 'DatUtil v2.18 and MAMEDiff v2.17', '3', '1125519583', '52', '0', '0', '0', '0', '123', '123', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('49', '1', 'RAINE v0.43.0', '3', '1125519686', '62', '0', '0', '0', '0', '125', '125', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('50', '1', 'M1 v0.7.6', '3', '1125519715', '62', '0', '0', '0', '0', '126', '126', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('51', '1', 'M1 v0.7.7', '3', '1125757588', '37', '0', '0', '0', '0', '129', '129', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('52', '1', 'Compile Guides', '3', '1125757644', '34', '0', '0', '0', '0', '130', '130', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('53', '15', 'M1 v0.7.7, RAINE 0.43.0, MinGW + Libraries', '3', '1125757843', '36', '0', '0', '0', '0', '131', '131', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('54', '15', 'Daphne v0.99.7pre5', '49', '1125890667', '45', '3', '0', '0', '0', '132', '137', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('55', '15', 'Raine 0.43.1 : Haze\'s games !', '49', '1125967923', '14', '0', '0', '0', '0', '138', '138', '0');
#
# TABLE: phpbb_topics_watch
#
DROP TABLE IF EXISTS phpbb_topics_watch;
CREATE TABLE phpbb_topics_watch(
	topic_id mediumint(8) unsigned NOT NULL,
	user_id mediumint(8) NOT NULL,
	notify_status tinyint(1) NOT NULL, 
	KEY topic_id (topic_id), 
	KEY user_id (user_id), 
	KEY notify_status (notify_status)
);

#
# Table Data for phpbb_topics_watch
#

INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('8', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('4', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('5', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('11', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('7', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('10', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('13', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('14', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('16', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('17', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('19', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('20', '25', '1');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('21', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('22', '29', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('22', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('23', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('25', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('27', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('29', '41', '1');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('31', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('33', '46', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('33', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('32', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('36', '48', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('37', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('38', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('36', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('39', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('40', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('42', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('44', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('40', '49', '1');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('46', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('48', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('49', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('50', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('46', '49', '1');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('51', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('52', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('53', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('54', '3', '0');
INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('54', '49', '0');
#
# TABLE: phpbb_user_group
#
DROP TABLE IF EXISTS phpbb_user_group;
CREATE TABLE phpbb_user_group(
	group_id mediumint(8) NOT NULL,
	user_id mediumint(8) NOT NULL,
	user_pending tinyint(1), 
	KEY group_id (group_id), 
	KEY user_id (user_id)
);

#
# Table Data for phpbb_user_group
#

INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('1', '-1', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('5', '5', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('3', '3', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('4', '4', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('6', '6', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('7', '7', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('8', '8', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('9', '9', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('10', '10', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('11', '11', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('12', '12', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('13', '13', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('14', '14', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('15', '15', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('16', '16', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('17', '17', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('18', '18', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('19', '19', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('20', '20', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('21', '21', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('22', '22', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('23', '23', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('24', '24', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('25', '25', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('26', '26', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('27', '27', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('28', '28', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('29', '29', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('30', '30', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('31', '31', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('32', '32', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('33', '33', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('34', '34', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('35', '35', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('36', '36', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('37', '37', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('38', '38', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('39', '39', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('40', '40', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('41', '41', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('42', '42', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('43', '43', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('44', '44', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('45', '45', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('46', '46', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('47', '47', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('48', '48', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('49', '49', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('50', '50', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('51', '51', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('52', '52', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('53', '53', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('54', '54', '0');
#
# TABLE: phpbb_users
#
DROP TABLE IF EXISTS phpbb_users;
CREATE TABLE phpbb_users(
	user_id mediumint(8) NOT NULL,
	user_active tinyint(1) DEFAULT '1',
	username varchar(25) NOT NULL,
	user_password varchar(32) NOT NULL,
	user_session_time int(11) NOT NULL,
	user_session_page smallint(5) NOT NULL,
	user_lastvisit int(11) NOT NULL,
	user_regdate int(11) NOT NULL,
	user_level tinyint(4),
	user_posts mediumint(8) unsigned NOT NULL,
	user_timezone decimal(5,2) DEFAULT '0.00' NOT NULL,
	user_style tinyint(4),
	user_lang varchar(255),
	user_dateformat varchar(14) DEFAULT 'd M Y H:i' NOT NULL,
	user_new_privmsg smallint(5) unsigned NOT NULL,
	user_unread_privmsg smallint(5) unsigned NOT NULL,
	user_last_privmsg int(11) NOT NULL,
	user_emailtime int(11),
	user_viewemail tinyint(1),
	user_attachsig tinyint(1),
	user_allowhtml tinyint(1) DEFAULT '1',
	user_allowbbcode tinyint(1) DEFAULT '1',
	user_allowsmile tinyint(1) DEFAULT '1',
	user_allowavatar tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_pm tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_viewonline tinyint(1) DEFAULT '1' NOT NULL,
	user_notify tinyint(1) DEFAULT '1' NOT NULL,
	user_notify_pm tinyint(1) NOT NULL,
	user_popup_pm tinyint(1) NOT NULL,
	user_rank int(11),
	user_avatar varchar(100),
	user_avatar_type tinyint(4) NOT NULL,
	user_email varchar(255),
	user_icq varchar(15),
	user_website varchar(100),
	user_from varchar(100),
	user_sig text,
	user_sig_bbcode_uid varchar(10),
	user_aim varchar(255),
	user_yim varchar(255),
	user_msnm varchar(255),
	user_occ varchar(100),
	user_interests varchar(255),
	user_actkey varchar(32),
	user_newpasswd varchar(32), 
	PRIMARY KEY (user_id), 
	KEY user_session_time (user_session_time)
);

#
# Table Data for phpbb_users
#

INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('-1', '0', 'Anonymous', '', '0', '0', '0', '1112905709', '0', '0', '0.00', NULL, '', '', '0', '0', '0', NULL, '0', '0', '0', '1', '1', '1', '0', '1', '0', '1', '0', NULL, '', '0', '', '', '', '', '', NULL, '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('5', '1', 'Mevi', 'a432bc26395ec23529123b31ca61a691', '1122833317', '0', '1122833164', '1113173373', '0', '1', '2.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'mevi@emu-france.com', '12769980', '', 'Belgium', '', '', '', '', '', 'Occasionaly, team member @ www.emu-france.com', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('3', '1', 'Logiqx', '4fc7038380e5519903026b0e599829f3', '1126003956', '0', '1126003472', '1112908224', '1', '52', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1113237284', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1258829969425c0c9050924.gif', '1', 'logiqxaguard-forum@yahoo.co.uk', '', 'http://www.logiqx.com/', 'UK', '', '', '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('4', '1', 'Pi', 'ca1db3e360bc3852de148b42d846d647', '1126002276', '0', '1125959120', '1112908902', '1', '34', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1118954028', NULL, '0', '1', '1', '0', '1', '1', '1', '0', '0', '1', '0', '1', '766615507425c29963835a.png', '1', 'pi@logiqx.com', '', 'http://caesar.logiqx.com', 'Jupiter', '', '', '', '', '', 'Female handkerchief, slayer of absolute truths', 'Stuff', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('6', '1', 'Iron Man', '9101e965c72791d2693ea7e2a957e5ab', '0', '0', '0', '1113248646', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'jan@in03.de', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('7', '1', 'cutebutwrong', '874a00325d20a88b0ee08f727a90b1c0', '1124258700', '0', '1123446625', '1113250363', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'cutebutwrong@gmail.com', '', 'http://www.mameworld.net/maws/', 'N. London', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('8', '1', 'krawler', 'ee7a0f70ece130b7d3ce3a0fb2b0a3c2', '1118044695', '0', '1113257662', '1113257625', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'rolft@attglobal.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('9', '1', 'hangover', 'ca5338eb5c76bdaa819781d164b79e19', '1113262376', '-4', '1113261370', '1113261289', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'ricki.horan@stanwell.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('10', '1', 'Bedfford', '7a7b48971d44b1c95484bfe56c137487', '1123873762', '0', '1113930794', '1113346285', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'bedfford@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('11', '1', 'greatxerox', 'cbbcc9303fcd3481c52e2fd8579f59d1', '1125218879', '0', '1125218879', '1113398082', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'greatxerox@yahoo.fr', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('12', '0', 'ShadowKing', '1e8ec5930a88992e802cd1bae6c059cf', '0', '0', '0', '1113446791', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'logiqx@mattlowe.com', '', '', '', 'Matt', '070bb63905', '', '', '', '', '', 'bd33b24f75e5bbf', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('13', '1', 'Ad_Enuff', 'f266ecb028df56c036b58178312b9798', '1114510103', '0', '1113656530', '1113472503', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'Ad_Enuff@hotmail.com', '', '', 'London, UK', '', '', '', '', '', 'Forensic Scientist', 'Arcade &amp; Console Emulation, Airsoft, Digital Home Cinema, Film Collecting', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('14', '1', 'dpful', '765ae843192a0f1b071f4446ee4c5fa3', '1121872854', '1', '1120142054', '1113513334', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'dpful@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('15', '1', 'coldlipzz', 'a5d6217806b1bf2ade22f219897690f7', '1113583199', '0', '1113583199', '1113582893', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'coldlipzz@yahoo.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('16', '1', 'DubaiShark', '28e44776632f325e803cd40780628fd5', '1113858046', '0', '1113858046', '1113857862', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'dubaishark@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('17', '1', 'astek28', 'fea1d68ae1067fbd17440361d1dfbbd4', '1114265829', '0', '1114265829', '1114265767', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'astek28@yahoo.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('18', '0', 'joedirt0009', '334c4a4c42fdb79d7ebc3e73b517e6f8', '0', '0', '0', '1114309333', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'joedirt0009@juno.com', '', '', '', '', '', '', '', '', '', '', '5869fda9459b10a', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('19', '1', 'gillian', '931810435ac7336be1da4f785797e14b', '1114315458', '0', '1114315458', '1114315185', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'xixi9114@yahoo.com.cn', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('20', '1', 'melvin', '02c80caf9b8b9c0127b232616c809729', '1114641118', '12', '1114635632', '1114635536', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1114635632', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'versinojunk@sbcglobal.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('21', '0', 'sharkyali', '5f4dcc3b5aa765d61d8327deb882cf99', '0', '0', '0', '1115381668', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'sharkyali@hotmail.com', '', '', '', 'i dunno nuttin', '725fdc5e0a', '', '', '', '', '', '228b8e195d296dd', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('22', '1', 'zankuro', '391a03db2b51ae91be825bd04970498f', '1115815054', '-2', '1115814478', '1115814395', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'confusius@fastmail.fm', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('23', '1', 'Stiletto', '57224c621c10156bd067024baa037050', '1124609567', '-9', '1124598455', '1115891002', '0', '3', '-5.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '0', '0', '1', '0', '0', '', '0', 'stiletto@fastmail.fm', '', 'http://research.mame.net', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('24', '0', 'deixxervaisul', '6f0839e1ae98abe8aa9c198058b914ad', '0', '0', '0', '1116098832', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '1', '0', '0', '0', '0', '1', '1', '1', '0', '0', '0', '0', '', '0', 'deixxervaisul@flashcubicle.com', '', '', 'United Kingdom', '', '', '', '', '', 'King of the Web', '', 'd6c4fb60919669a', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('25', '1', 'snakemeat', '72059ef5b9c318bfe1ea88c08a6288cd', '1116172116', '6', '1116171410', '1116171359', '0', '1', '-8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'snakemeat@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('26', '1', 'JerryBlade', '01cc4957a6ee18eb4d69188af85c5e08', '1116467407', '-9', '1116371870', '1116368421', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1116368514', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'jerry@lavishzone.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('27', '0', 'tao7even', '25d55ad283aa400af464c76d713c07ad', '0', '0', '0', '1116543993', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'tao7even@hotmail.com', '', '', '', '', '', '', '', '', '', '', '4d7bcbb2f4b2048', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('28', '1', 'superlilly', 'a1ab11a8212b75d55c52a1b2973fc783', '1116600653', '-2', '1116600575', '1116600510', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '0', '0', '0', '', '0', 'superlilly@excite.it', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('29', '1', 'druan', '10bd80e9d04c9691d87325f62a1cee62', '1117106696', '15', '1117098101', '1117001947', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'druan@optushome.com.au', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('30', '1', 'tonymiz01', '3f1656d9668dffcf8119e3ecff873558', '1121091828', '-4', '1117104231', '1117029624', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'tonymiz01@yahoo.co.uk', '', '', '', '', '', '', 'tonymiz01', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('31', '1', 'sirpoonga', 'eb9442450a28582c736ce428cf2aa29e', '1118088578', '0', '1117547002', '1117222925', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'kevin.jonas@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('32', '1', 'roikenzy', '5f2a6f361ed570482183068d8604b7b3', '1117861539', '15', '1117811162', '1117809041', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '0', '', '0', 'roikenzy99@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('33', '1', 'Wonko', 'ce04e97ae0909b6d10bc6ec25cb6b80b', '1117974111', '0', '1117974111', '1117974044', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'thesane2k@gmx.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('34', '1', 'Hakkk', 'cae223b09425658f6c2c584ff3eec826', '1124852420', '15', '1124852254', '1118579339', '0', '4', '8.00', '1', 'english', 'Y-m-d D H:i', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', 'http://www.ppxbbs.com/images/avatars/17.gif', '2', 'mike_woo214@hotmail.com', '', '', '', '', '', '', '', 'mike_woo214@hotmail.com', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('35', '0', 'joedirt00009', 'f46ef81f2464441ba58aeecbf654ee41', '0', '0', '0', '1118590920', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'joedirt00009@juno.com', '', '', '', '', '', '', '', '', '', '', '585a8b8080d0d82', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('36', '1', 'Jr_0079', 'f46ef81f2464441ba58aeecbf654ee41', '1118591223', '0', '1118591223', '1118591098', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'Jr_0079@juno.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('37', '1', 'amcordeiro', '018b6a4998cacef2e31b319a6421d5f2', '1118951868', '-10', '1118935868', '1118866958', '0', '0', '-3.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1118951616', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'amcordeiro@yahoo.com.br', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('38', '1', 'bandoogiemanz', '878fe83fbf0c5ecd534eb09cf444aca8', '0', '0', '0', '1118909289', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'bandoogiemanz@aol.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('39', '1', 'crazyxf', '194074085945b26f6921c2f220994523', '1118992168', '14', '1118991772', '1118991317', '0', '0', '8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'crazyxf@yahoo.com.cn', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('40', '0', 'SainT+AngeR', '65fbef05e01fac390cb3fa073fb3e8cf', '0', '0', '0', '1119451108', '0', '0', '4.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'tcrouse@grantthornton.caq', '', '', 'New Brunswick', '', '', '', '', 'wolf_redden@hotmail.com', 'Network Adminsitrator', '', '99b0037c32d4ed8', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('41', '1', 'byproduct', '5c4323b89191ea5832cb57cdb2c1f27b', '1120152134', '-9', '1120140326', '1120140223', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'byproduct@comcast.net', '', '', '', '', '', 'byproduct0', '', '', 'Electrical Engineer', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('42', '0', 'anonymous2', 'd8d3a01ba7e5d44394b6f0a8533f4647', '0', '0', '0', '1120234276', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '0', '1', '1', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'anonymous@yahoo.com', '', '', '', '', '', '', '', '', '', '', 'e5dee46b478c88a', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('43', '0', 'pepeuchi', 'e10adc3949ba59abbe56e057f20f883e', '0', '0', '0', '1120445577', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'pepeuchi@yahoo.com.ar', '', '', '', '', '', '', '', '', '', '', '480bce2075048fb', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('44', '0', 'gyikk', 'caf2fc039a5702964c3fe533c563e931', '0', '0', '0', '1121170611', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'tcr@freemail.hu', '', '', '', '', '', '', '', '', '', '', '0ced78088f1e1e3', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('45', '1', 'babelfish', '96b68fad56863d99c26d7cae853714c5', '1121477167', '12', '1121474065', '1121474007', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'babelfish@mytrashmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('46', '1', 'xlox', '7d75f1598aa52058cd8b6c99d196a8eb', '1121715938', '3', '1121714130', '1121593726', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'mascia_r@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('47', '1', 'AJDSTMK', '25d55ad283aa400af464c76d713c07ad', '1122390177', '0', '1122277760', '1122276847', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'alessandrodimas@lycos.de', '', '', 'Vienna', '', '', '', '', '', 'Student', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('48', '1', 'Pentium', '2fc01ec765ec0cb3dcc559126de20b30', '1125987749', '0', '1125938652', '1122680371', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'tidusa@caramail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('49', '1', 'KingHanco', '6c872fd7b05f29d4fb89a055a49f4ec4', '1125967923', '-9', '1125967460', '1122967475', '0', '11', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'coonstation@sbcglobal.net', '', '', '', 'KingHanco: The Great', 'ba2fbaeca1', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('50', '0', 'Finlay', '65aba82ac5db373aeb287e476e100430', '0', '0', '0', '1123686984', '0', '0', '2.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'merlingoodall@msn.co.uk', '', '', '', '', '', '', '', '', '', '', '2c6c906c72c6cd9', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('51', '1', 'darko', 'b2ba5c559ee003029eeba161f8e36586', '1124827240', '1', '1124826729', '1124826655', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'thedark22@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('52', '0', 'strettoasino', '5fa4bdc21e94b0e772f77fd5126d3e9f', '0', '0', '0', '1125083914', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'st0we24@yahoo.com', '', '', 'nevarca', '', '', '', '', '', '', '', '9c7308e3933e577', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('53', '1', 'venusin7', 'ba535ef5a9f7b8bc875812bb081286bb', '1125299189', '0', '1125299189', '1125291141', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '0', '', '0', 'venusin7@aol.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('54', '1', 'counterproductive', '2fd51c507f44249099546ee986dd1a71', '1125997182', '-9', '1125997091', '1125316596', '0', '0', '0.00', '0', 'english', 'D M d, Y g:i a', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '0', '0', '0', '', '0', 'isiseb@yandex.ru', '', '', '', '', '', '', '', '', '', '', '', NULL);
#
# TABLE: phpbb_vote_desc
#
DROP TABLE IF EXISTS phpbb_vote_desc;
CREATE TABLE phpbb_vote_desc(
	vote_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	vote_text text NOT NULL,
	vote_start int(11) NOT NULL,
	vote_length int(11) NOT NULL, 
	PRIMARY KEY (vote_id), 
	KEY topic_id (topic_id)
);
#
# TABLE: phpbb_vote_results
#
DROP TABLE IF EXISTS phpbb_vote_results;
CREATE TABLE phpbb_vote_results(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_option_id tinyint(4) unsigned NOT NULL,
	vote_option_text varchar(255) NOT NULL,
	vote_result int(11) NOT NULL, 
	KEY vote_option_id (vote_option_id), 
	KEY vote_id (vote_id)
);
#
# TABLE: phpbb_vote_voters
#
DROP TABLE IF EXISTS phpbb_vote_voters;
CREATE TABLE phpbb_vote_voters(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_user_id mediumint(8) NOT NULL,
	vote_user_ip char(8) NOT NULL, 
	KEY vote_id (vote_id), 
	KEY vote_user_id (vote_user_id), 
	KEY vote_user_ip (vote_user_ip)
);
#
# TABLE: phpbb_words
#
DROP TABLE IF EXISTS phpbb_words;
CREATE TABLE phpbb_words(
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word char(100) NOT NULL,
	replacement char(100) NOT NULL, 
	PRIMARY KEY (word_id)
);
#
# TABLE: phpbb_confirm
#
DROP TABLE IF EXISTS phpbb_confirm;
CREATE TABLE phpbb_confirm(
	confirm_id char(32) NOT NULL,
	session_id char(32) NOT NULL,
	code char(6) NOT NULL, 
	PRIMARY KEY (session_id, confirm_id)
);

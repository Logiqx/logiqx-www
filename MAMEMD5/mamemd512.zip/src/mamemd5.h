/* --- A simple limit! --- */

#define PATH_LENGTH 256

/* --- Maximum file size is 32MB --- */

#define MAX_ROM_SIZE 0x2000000

/* --- Maximum number of ROMs in mamemd5.dat --- */

#define MAX_ROMS 100000
#define MAX_ROMSIZES 100

/* --- Structures --- */

struct rom
{
	UINT32 crc;
	UINT32 size;
	unsigned char md5[16];
};

struct romsize
{
	UINT32 size;
	UINT32 count;
};

/* --- Function prototypes --- */

int scan_dir(char *dir, struct rom *roms, int num_roms, int generate, FILE *out);
int search_function(const void *, const void *);

int prob_using_size(void);

#define UPPER(ST) \
{ \
	int i; \
	for (i=0; i<strlen(ST); i++) \
		ST[i]=toupper(ST[i]); \
}


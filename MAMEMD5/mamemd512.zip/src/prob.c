#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define UNIQUE_CRCS   29937
#define POSSIBLE_CRCS 4294967296

/* --- Definitions for MAME's unzip routines --- */

#include "mame/unzip.h"

/* --- My type definitions and the ROM information --- */

#include "mamemd5.h"

int main(int argc, char **argv)
{
	int errflg=0;
	double i, res;

	for (res=1, i=0; i<UNIQUE_CRCS; i++)
		res*=(POSSIBLE_CRCS-i)/POSSIBLE_CRCS;
	res=1-res;
	printf("Chance of a CRC collision in MAME v0.54 is %f%% (ignoring ~ CRCs)\n\n", res*100);

	for (res=1, i=0; i<UNIQUE_CRCS*2; i++)
		res*=(POSSIBLE_CRCS-i)/POSSIBLE_CRCS;
	res=1-res;
	printf("Chance of a CRC collision in MAME v0.54 is %f%% (including ~ CRCs)\n\n", res*100);

	errflg+=prob_using_size();

	return(errflg);
}

int prob_using_size(void)
{
	int errflg=0;

	char st[1024+1];
	char *ptr;

	int i=0, found;

	struct romsize *romsizes=0;
	int num_romsizes=0;

	struct rom *roms=0;
	int num_roms=0;

	FILE *in=0;

	double j, res, tmpres;

	/* --- Get going then! --- */

	if (!errflg && !(roms=malloc(MAX_ROMS*sizeof(struct rom))))
	{
		printf("Failed to allocated ROM cache (%ld bytes)\n", (long)MAX_ROMS*sizeof(struct rom));
		errflg++;
	}

	if (!errflg && !(romsizes=calloc(1, MAX_ROMSIZES*sizeof(struct romsize))))
	{
		printf("Failed to allocated ROM size cache (%ld bytes)\n", (long)MAX_ROMSIZES*sizeof(struct romsize));
		errflg++;
	}

	if (!errflg && ((in=fopen("mamemd5.dat", "r"))==0))
	{
		printf("Couldn't open mamemd5.dat for reading\n");
		errflg++;
	}

	while (!errflg && fgets(st, 1024, in))
	{
		while (st[strlen(st)-1]==10 || st[strlen(st)-1]==13)
			st[strlen(st)-1]='\0';

		ptr=st;
		roms[num_roms].crc=strtoul(ptr, &ptr, 16);
		ptr++;
		roms[num_roms].size=strtoul(ptr, &ptr, 16);
		ptr++;
		
		for (found=i=0; i<num_romsizes; i++)
		{
			if (romsizes[i].size==roms[num_roms].size)
			{
				found++;
				romsizes[i].count++;
			}
		}

		if (!found)
		{
			if (num_romsizes<MAX_ROMSIZES)
			{
				romsizes[num_romsizes].size=roms[num_roms].size;
				romsizes[num_romsizes].count=1;
				num_romsizes++;
			}
			else
			{
				printf("Too many rom sizes!\n");
				errflg++;
			}
		}

		for (i=0; i<16; i++)
		{
			strncpy(st, ptr, 2);
			st[2]='\0';
			roms[num_roms].md5[i]=strtoul(st, 0, 16);
			ptr+=2;
		}

		num_roms++;
	}

	res=0;
	for (i=0; !errflg && i<num_romsizes; i++)
	{
		printf("Romsize %08lx: count=%d, chance of conflict= ", (unsigned long)romsizes[i].size, romsizes[i].count);

		for (tmpres=1, j=0; j<romsizes[i].count/2; j++)
			tmpres*=(POSSIBLE_CRCS-j)/POSSIBLE_CRCS;

		tmpres=1-tmpres;
		res+=tmpres;

		printf("%f%%\n", tmpres*100);
	}
	if (!errflg)
		printf("Chance of a CRC+size collision in MAME v0.54 is %f%% (ignoring ~ CRCs)\n\n", res*100);

	res=0;
	for (i=0; !errflg && i<num_romsizes; i++)
	{
		printf("Romsize %08lx: count=%d, chance of conflict= ", (unsigned long)romsizes[i].size, romsizes[i].count);

		for (tmpres=1, j=0; j<romsizes[i].count; j++)
			tmpres*=(POSSIBLE_CRCS-j)/POSSIBLE_CRCS;

		tmpres=1-tmpres;
		res+=tmpres;

		printf("%f%%\n", tmpres*100);
	}
	if (!errflg)
		printf("Chance of a CRC+size collision in MAME v0.54 is %f%% (including ~ CRCs)\n", res*100);

	if (in) fclose(in);
	if (romsizes) free(romsizes);
	if (roms) free(roms);

	return(errflg);
}

/* --------------------------------------------------------------------------
 * MAMEMD5 - Written by Logiqx (http://www.logiqx.com)
 *
 * A simple little utility for checking ROMS using MD5
 * -------------------------------------------------------------------------- */

#define MAMEMD5_VERSION "v1.2"
#define MAMEMD5_DATE "8 September 2001"

/* --- The standard includes --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <zlib.h>

/* --- Although DJGPP has a getopt function, MinGW, CygWin and MSVC don't --- */

#include "getopt.c"	// Same functions as in unistd library

/* --- Definitions for MAME's unzip routines --- */

#include "mame/unzip.h"

/* --- Definitions for MD5 routines --- */

#define MD 5

#include "md5/global.h"
#include "md5/md5.h"

/* --- My type definitions and the ROM information --- */

#include "mamemd5.h"

int collisions=0;
int roms_recognised=0;
int roms_unrecognised=0;
int roms_too_big=0;

/* --------------------------------------------------------------------------
 * The main() function just works out what the user wants to do then calls the
 * appropriate function.
 *
 * Uses the getopt() function from unistd to interpret command line options.
 * -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
	extern char *optarg;

	int c, errflg = 0;

	char st[1024+1];
	char fn[PATH_LENGTH+1];
	char dir[PATH_LENGTH+1]=".";
	char *ptr;

	int i, generate=0;
	UINT32 last_crc=0, last_size=0;

	struct rom *roms=0;
	int num_roms=0;
	FILE *in=0, *out=0;

	printf("===============================================================================\n");
	printf("MAMEMD5 %s (%s)\n", MAMEMD5_VERSION, MAMEMD5_DATE);
	printf("Written by Logiqx (http://www.logiqx.com)\n");
	printf("===============================================================================\n");

	/* --- Get the options specified on the command line --- */

	while ((c = getopt(argc, argv, "d:g")) != EOF)
	switch (c)
	{
		case 'd':
			strcpy(dir, optarg);
			break;
		case 'g':
			generate++;
			break;
		case '?':
			errflg++;   /* User wants help! */
	}

	/* --- Display the help page if required --- */

	if (errflg)
	{
		printf("Usage: mamemd5 [-d in_dir]\n");
		exit (1);
	}

	/* --- Get going then! --- */

	if (!errflg && !(roms=malloc(MAX_ROMS*sizeof(struct rom))))
	{
		printf("Failed to allocated ROM cache (%ld bytes)\n", (long)MAX_ROMS*sizeof(struct rom));
		errflg++;
	}

	if (!errflg && !generate)
	{
		if ((in=fopen("mamemd5.dat", "r"))==0)
		{
			printf("Couldn't open mamemd5.dat for reading\n");
			errflg++;
		}

		while (!errflg && fgets(st, 1024, in))
		{
			while (st[strlen(st)-1]==10 || st[strlen(st)-1]==13)
				st[strlen(st)-1]='\0';

			ptr=st;
			roms[num_roms].crc=strtoul(ptr, &ptr, 16);
			ptr++;
			roms[num_roms].size=strtoul(ptr, &ptr, 16);
			ptr++;
			
			for (i=0; i<16; i++)
			{
				strncpy(st, ptr, 2);
				st[2]='\0';
				roms[num_roms].md5[i]=strtoul(st, 0, 16);
				ptr+=2;
			}

			/*printf("%08lx,%08lx,", (unsigned long)roms[num_roms].crc, (unsigned long)roms[num_roms].size);

			for (i = 0; i < 16; i++)
				printf ("%02x", roms[num_roms].md5[i]);

			printf("\n");*/

			if (roms[num_roms].crc==last_crc && roms[num_roms].size==last_size)
			{
				printf("Duplicates in mamemd5.dat... aborting\n");
				errflg++;
			}

			if (roms[num_roms].crc<last_crc || (roms[num_roms].crc==last_crc && roms[num_roms].size<last_size))
			{
				printf("You must use a sorted mamemd5.dat... aborting\n");
				errflg++;
			}

			last_crc=roms[num_roms].crc;
			last_size=roms[num_roms].size;

			num_roms++;
		}

		if (in) fclose(in);
	}

	if (generate)
		sprintf(fn, "mamemd5.new");
	else
		sprintf(fn, "mamemd5.log");

	if (!errflg && (out=fopen(fn, "w"))==0)
	{
		printf("Couldn't open mamemd5.log for writing\n");
		errflg++;
	}

	if (!errflg)
	{
		scan_dir(dir, roms, num_roms, generate, out);
		if (!generate)
		{
			if (collisions==0)
			{
				printf("All done.\n\nNo collisions were found.\n");
				fprintf(out, "All done.\n\nNo collisions were found.\n");
			}
			else
			{
				printf("All done.\n\n%d collisions were found (see 'mamemd5.log').\n", collisions);
				fprintf(out, "All done.\n\n%d collisions were found.\n", collisions);
			}

			printf("\nSummary: %d recognised, %d unrecognised, %d too big to check.\n", roms_recognised, roms_unrecognised, roms_too_big);
			fprintf(out, "\nSummary: %d recognised, %d unrecognised, %d too big to check.\n", roms_recognised, roms_unrecognised, roms_too_big);

		}
		else
		{
			printf("\nAll done. Use 'sort -u mamemd5.new >mamemd5.dat' to generate the data file.\n");
		}
	}

	if (out) fclose(out);

	if (roms) free(roms);

	/* --- All done --- */

	exit(errflg);
}

/* --------------------------------------------------------------------------
 * The directory scan routine - recursive
 * -------------------------------------------------------------------------- */

int scan_dir(char *dir, struct rom *roms, int num_roms, int generate, FILE *out)
{
	DIR *dirp=0;
	struct dirent *direntp;
	struct stat buf;

	ZIP *zip;
	struct zipent *zipent;

	MD5_CTX context;

	unsigned char *mem=0;

	UINT32 crc;
	unsigned char md5[16];

	struct rom *idx=0;
	struct rom curr;

	int i, match=1, errflg=0;

	char fn[PATH_LENGTH+1];
	char ufn[PATH_LENGTH+1];

	if (!(mem=malloc(MAX_ROM_SIZE)))
	{
		printf("Failed to allocated 16MB block\n");
		errflg++;
	}

	if (!errflg)
		dirp = opendir(dir);

	while (!errflg && dirp && ((direntp = readdir(dirp)) != NULL))
	{
		sprintf(fn, "%s/%s", dir, direntp->d_name);
		strcpy(ufn, direntp->d_name);
		UPPER(ufn);
		if (stat(fn, &buf) == 0)
		{
			if (!(buf.st_mode & S_IFDIR))
			{
				if (strrchr(ufn, '.') && !strcmp(strrchr(ufn, '.'), ".ZIP"))
				{
					printf("Processing %s...\n", fn);
					if ((zip = openzip(fn)))
					{
						while ((zipent = readzip(zip)) != 0)
						{
							if (zipent->uncompressed_size>MAX_ROM_SIZE)
							{
								printf("Ignoring %s because it is too big!\n", zipent->name);
								roms_too_big++;
							}
							else
							{
								if (zipent->uncompressed_size>0)
								{
									if (readuncompresszip(zip, zipent, mem))
										printf("(error was for %s)\n", zipent->name);
								}
								crc = crc32(0, NULL, 0);
								crc = crc32(crc, mem, zipent->uncompressed_size);
								/*if (crc!=zipent->crc32)
									printf("Warning: CRC wrong for %s in %s\n", zipent->name, fn);*/
 								MD5Init (&context);
								MD5Update (&context, mem, zipent->uncompressed_size);
 								MD5Final (md5, &context);
								if (generate)
								{
									fprintf(out, "%08lx,%08lx,", (unsigned long)crc, (unsigned long)zipent->uncompressed_size);
									for (i = 0; i < 16; i++)
										fprintf (out, "%02x", md5[i]);
									fprintf(out, "\n");

									fprintf(out, "%08lx,%08lx,", (unsigned long)~crc, (unsigned long)zipent->uncompressed_size);
									for (i = 0; i < 16; i++)
										fprintf (out, "%02x", md5[i]);
									fprintf(out, "\n");
								}
								else
								{
									curr.crc=crc;
									curr.size=zipent->uncompressed_size;
									idx=bsearch(&curr, roms, num_roms, sizeof(struct rom), search_function);

									if (idx)
										roms_recognised++;
									else
										roms_unrecognised++;
								}

								if (idx)
								{
									match=1;
									for (i=0; match && i<16; i++)
									{
										if (idx->md5[i]!=md5[i])
											match=0;
									}

									if (!match)
									{
										fprintf(out, "Content mismatch for %s in %s (CRC %08lx, size %ld)\n", zipent->name, fn, (unsigned long)crc, (unsigned long)zipent->uncompressed_size);
										collisions++;
									}
								}
							}
						}
						closezip(zip);
					}
				}
			}
			else
			{
				if (fn[strlen(fn)-1]!='.')	/* Don't try . or .. entries */
					scan_dir(fn, roms, num_roms, generate, out);
			}
		}
		else
		{
			printf("Error getting attributes of %s\n", direntp->d_name);
		}
	}

	if (dirp) closedir(dirp);

	if (mem) free(mem);

	return (0);
}

int search_function(const void *idx1, const void *idx2)
{
	UINT32 crc1=((struct rom *)idx1)->crc;
	UINT32 crc2=((struct rom *)idx2)->crc;
	UINT32 size1=((struct rom *)idx1)->size;
	UINT32 size2=((struct rom *)idx2)->size;

	if (crc1<crc2)
		return(-1);
	if (crc1>crc2)
		return(1);
	if (size1<size2)
		return(-1);
	if (size1>size2)
		return(1);
	return(0);
}


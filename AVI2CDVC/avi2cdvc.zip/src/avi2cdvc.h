/* --------------------------------------------------------------------------
 * AVI2CDVC - Written by Logiqx (http://www.logiqx.com/)
 *
 * A little tool that alters the FourCC of AVI files to 'cdvc' (Canopus DV)
 * -------------------------------------------------------------------------- */

/* --- Size declarations --- */

#define FILENAME_LENGTH 1024
#define BUFFER_SIZE 512

/* --- Function protoypes --- */

int process_dir(char *, int, char *, char *);
int process_file(char *, char *, char *);

/* --- Useful macros --- */

#define CALLOC(PTR, NUMBER, TYPE) \
if (!(PTR=calloc(NUMBER, sizeof(struct TYPE)))) \
{ \
	printf("Not enough memory\n"); \
	errflg++; \
}

#define FREE(PTR) \
if (PTR) \
{ \
	free(PTR);\
}

#define FOPEN(PTR, FN, MODE) \
if (!(PTR=fopen(FN, MODE))) \
{ \
	printf("Error opening %s for mode '%s'\n", FN, MODE); \
	errflg++; \
}

#define FCLOSE(PTR) \
if (PTR) \
{ \
	fclose(PTR); \
	PTR=0; \
}

#define LOWER(ST) \
{ \
	char *ptr=ST; \
	int i; \
	for (i=0; i<strlen(ptr); i++) \
		ptr[i]=tolower(ptr[i]); \
}


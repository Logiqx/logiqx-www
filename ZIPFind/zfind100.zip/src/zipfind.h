/* --------------------------------------------------------------------------
 * ZIPIdent - Written by Logiqx (http://www.logiqx.com/)
 *
 * Little tool that tries to identify ZIP files that are emulated by MAME
 * -------------------------------------------------------------------------- */

/* --- Size declarations --- */

#define MAX_GAMES 20000
#define MAX_ROMS 200000

#define FILE_NAME_LENGTH 256
#define TITLE_LENGTH 100
 
#define BUFFER_SIZE 1024

/* --- Dat structures --- */

struct rom
{
	char name[FILE_NAME_LENGTH+1];
	int size;
	unsigned long crc;
	int match;
};

struct game
{
	char name[FILE_NAME_LENGTH+1];
	char title[TITLE_LENGTH+1];
	struct rom *first_rom;
	int num_roms;
	long size;
	int match;
	double score;
};

struct rom_idx
{
	struct game *game;
	struct rom *rom;
};

struct game_idx
{
	struct game *game;
};

struct dat
{
	char *name;
	struct game *games;
	struct game_idx *game_score_idx;
	struct rom *roms;
	struct rom_idx *rom_crc_idx;
	int num_games;
	long num_roms;
};

/* --- Function protoypes --- */

int init_dat(struct dat *, char *);
int load_mame_listinfo(struct dat *);
int load_ziplist(struct dat *);
int release_dat(struct dat *);

int game_report(struct dat *, struct dat *, int);
int zip_report(struct dat *, struct dat *, int);
int url_report(struct dat *, char *);

int sort_roms_by_crc(const void *, const void *);
int sort_idx_by_rom_crc(const void *, const void *);
int sort_idx_by_game_score(const void *, const void *);

int find_rom_by_crc(const void *, const void *);
int find_rom_by_comp_crc(const void *, const void *);
int find_rom_by_crc_idx(const void *, const void *);
int find_rom_by_comp_crc_idx(const void *, const void *);

/* --- Useful macros --- */

#define REMOVE_CR_LF(ST) \
{ \
	while ((ST[strlen(ST)-1]==10) || (ST[strlen(ST)-1]==13)) \
		ST[strlen(ST)-1]='\0'; \
}

#define CALLOC(PTR, NUMBER, TYPE) \
if (!(PTR=calloc(NUMBER, sizeof(struct TYPE)))) \
{ \
	printf("Not enough memory\n"); \
	errflg++; \
}

#define FREE(PTR) \
if (PTR) \
{ \
	free(PTR);\
}

#define FOPEN(PTR, FN, MODE) \
if (!(PTR=fopen(FN, MODE))) \
{ \
	printf("Error opening %s for mode '%s'\n", FN, MODE); \
	errflg++; \
}

#define FCLOSE(PTR) \
if (PTR) \
{ \
	fclose(PTR); \
	PTR=0; \
}

#define LOWER(ST) \
{ \
	char *ptr=ST; \
	int i; \
	for (i=0; i<strlen(ptr); i++) \
		ptr[i]=tolower(ptr[i]); \
}

#define GET_TOKEN(TOKEN, ST_PTR) \
{ \
	int token_idx=0; \
\
	while (*ST_PTR==' ' || *ST_PTR=='	') \
		ST_PTR++; \
\
	if (*ST_PTR=='"') \
	{ \
		ST_PTR++; \
		while (*ST_PTR!='"' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
		if (*ST_PTR!='\0') \
			ST_PTR++; \
	} \
	else \
	{ \
		while (*ST_PTR!=' ' && *ST_PTR!='	' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
	} \
}

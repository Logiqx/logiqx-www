/* --------------------------------------------------------------------------
 * ZIPFind - Written by Logiqx (http://www.logiqx.com/)
 *
 * Little tool that tries to find ZIP files that you need!
 * -------------------------------------------------------------------------- */

#define ZIPFIND_VERSION "v1.00"
#define ZIPFIND_DATE "2 February 2003"

/* --- The standard includes --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* --- Although DJGPP has a getopt function, MinGW, CygWin and MSVC don't --- */

#if defined (__MINGW32_VERSION) || defined (__CYGWIN__) || defined (_MSC_VER)
#include "getopt.c"	// Same functions as in unistd library
#else
#include <unistd.h>
#endif

/* --- My type definitions and macros --- */

#include "zipfind.h"

/* --------------------------------------------------------------------------
 * The main() function
 * -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
	/* --- For getopt function --- */

	extern int optind;

	struct dat *missing=0, *ziplist=0;
	int c, errflg=0;

	int verbose=0;
	char *url=0;

	printf("===============================================================================\n");
	printf("ZIPFind %s (%s)\n", ZIPFIND_VERSION, ZIPFIND_DATE);
	printf("Written by Logiqx (http://www.logiqx.com/)\n");
	printf("===============================================================================\n");

	while (!errflg && (c = getopt(argc, argv, "vu:?")) != EOF)
	switch (c)
	{
		case 'v':
			verbose++;
			break;
		case 'u':
			url=optarg;
			break;
		case '?':
			errflg++;														/* User wants help! */
	}

	/* --- Display the help page if required --- */

	if (argc-optind<2)
	{
		printf("Usage: zipfind [-v] [-u <url>] <missing.dat> <ziplist.txt>\n");
		errflg++;
	}

	/* --- Load the 'missing' data file --- */

	if (!errflg)
		CALLOC(missing, 1, dat)

	if (!errflg)
		missing->name=argv[optind];

	if (!errflg)
		errflg=load_mame_listinfo(missing);

	/* --- Load the 'ziplist' data file --- */

	if (!errflg)
		CALLOC(ziplist, 1, dat)

	if (!errflg)
		ziplist->name=argv[optind+1];

	if (!errflg)
		errflg=load_ziplist(ziplist);

	/* --- Generate reports --- */

	if (!errflg)
		errflg=game_report(missing, ziplist, verbose);

	if (!errflg)
		errflg=zip_report(missing, ziplist, verbose);

	if (!errflg)
		errflg=url_report(ziplist, url);

	/* --- Clean up --- */

	release_dat(ziplist);
	release_dat(missing);

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Game Report
 * -------------------------------------------------------------------------- */

int game_report(struct dat *missing, struct dat *ziplist, int verbose)
{
	struct rom_idx *rom_match_idx;
	struct rom *rom_match;

	int i, j, k;
	int num_found, num_useful;
	long bytes_found, bytes_useful;
	double usefulness, completeness, score;

	FILE *out=0;

	int errflg=0;

	FOPEN(out, "zf_games.log", "w")

	for (i=0; !errflg && i<missing->num_games; i++)
	{
		for (j=0; j<missing->games[i].num_roms; j++)
		{
			/* --- Search for matching CRCs in ziplist --- */

			rom_match_idx=bsearch(&missing->games[i].first_rom[j], ziplist->rom_crc_idx, ziplist->num_roms, sizeof(struct rom_idx), find_rom_by_crc_idx);

			if (rom_match_idx)
			{
				while (rom_match_idx>ziplist->rom_crc_idx && rom_match_idx->rom->crc==(rom_match_idx-1)->rom->crc)
					rom_match_idx--;

				while (rom_match_idx<ziplist->rom_crc_idx+ziplist->num_roms && rom_match_idx->rom->crc==missing->games[i].first_rom[j].crc)
				{
					missing->games[i].match++;
					missing->games[i].first_rom[j].match++;
					rom_match_idx->game->match++;
					rom_match_idx++;
				}
			}

			/* --- Search for matching ~CRCs in ziplist --- */

			rom_match_idx=bsearch(&missing->games[i].first_rom[j], ziplist->rom_crc_idx, ziplist->num_roms, sizeof(struct rom_idx), find_rom_by_comp_crc_idx);

			if (rom_match_idx)
			{
				while (rom_match_idx>ziplist->rom_crc_idx && rom_match_idx->rom->crc==(rom_match_idx-1)->rom->crc)
					rom_match_idx--;

				while (rom_match_idx<ziplist->rom_crc_idx+ziplist->num_roms && rom_match_idx->rom->crc==~missing->games[i].first_rom[j].crc)
				{
					missing->games[i].match++;
					missing->games[i].first_rom[j].match++;
					rom_match_idx->game->match++;
					rom_match_idx++;
				}
			}
		}

		/* --- If some ROMs were found in the ziplist then print game info --- */

		if (missing->games[i].match)
		{
			/* --- Count up totals for ROMs found --- */

			num_found=bytes_found=0;

			for (j=0; j<missing->games[i].num_roms; j++)
			{
				if (missing->games[i].first_rom[j].match)
				{
					num_found++;
					bytes_found+=missing->games[i].first_rom[j].size;
				}
			}

			/* --- Report totals for ROMs found --- */

			fprintf(out, "Game          : %s\n", missing->games[i].name);
			fprintf(out, "Description   : %s\n", missing->games[i].title);
			fprintf(out, "Total Needed  : %d ROMs, %ld bytes\n", missing->games[i].num_roms, missing->games[i].size);
			fprintf(out, "Total Found   : %d/%d ROMs, %ld/%ld bytes (%.2f%%)\n\n", num_found, missing->games[i].num_roms, bytes_found, missing->games[i].size, (float)100*bytes_found/missing->games[i].size);

			/* --- Report details of ROMs found (verbose mode) --- */

			if (verbose)
			{
				fprintf(out, "Contents      : ");
				for (j=0; j<missing->games[i].num_roms; j++)
				{
					if (j>0)
						fprintf(out, "                ");

					if (missing->games[i].first_rom[j].match==1)
						fprintf(out, "%s, %d bytes, crc %08lx, (1 match)\n",
							missing->games[i].first_rom[j].name, missing->games[i].first_rom[j].size,
							missing->games[i].first_rom[j].crc); 
					else
						fprintf(out, "%s, %d bytes, crc %08lx, (%d matches)\n",
							missing->games[i].first_rom[j].name, missing->games[i].first_rom[j].size,
							missing->games[i].first_rom[j].crc, missing->games[i].first_rom[j].match); 
				}
				fprintf(out, "\n");
			}

			/* --- Report ZIPs that were found --- */

			for (j=0; j<ziplist->num_games; j++)
			{
				if (ziplist->games[j].match)
				{
					/* --- Initialise counts for missing ROMs --- */

					for (k=0; k<missing->games[i].num_roms; k++)
						missing->games[i].first_rom[k].match=0;

					for (k=0; k<ziplist->games[j].num_roms; k++)
					{
						/* --- Check which CRCs are available in the ZIP --- */

						rom_match=bsearch(&ziplist->games[j].first_rom[k], missing->games[i].first_rom, missing->games[i].num_roms, sizeof(struct rom), find_rom_by_crc);
				
						if (rom_match)
						{
							while (rom_match>missing->roms && rom_match->crc==(rom_match-1)->crc)
								rom_match--;
			
							while (rom_match<missing->roms+missing->num_roms && rom_match->crc==ziplist->games[j].first_rom[k].crc)
							{
								ziplist->games[j].first_rom[k].match++;
								rom_match->match++;
								rom_match++;
							}
						}
			
						/* --- Check which ~CRCs are available in the ZIP --- */

						rom_match=bsearch(&ziplist->games[j].first_rom[k], missing->games[i].first_rom, missing->games[i].num_roms, sizeof(struct rom), find_rom_by_comp_crc);

						if (rom_match)
						{
							while (rom_match>missing->roms && rom_match->crc==(rom_match-1)->crc)
								rom_match--;
			
							while (rom_match<missing->roms+missing->num_roms && rom_match->crc==~ziplist->games[j].first_rom[k].crc)
							{
								ziplist->games[j].first_rom[k].match++;
								rom_match->match++;
								rom_match++;
							}
						}
					}

					/* --- Count up totals found in ZIP --- */

					num_found=bytes_found=0;

					for (k=0; k<missing->games[i].num_roms; k++)
					{
						if (missing->games[i].first_rom[k].match)
						{
							num_found++;
							bytes_found+=missing->games[i].first_rom[k].size;
						}
					}

					/* --- Calculate usefulness of ZIP --- */

					num_useful=bytes_useful=0;

					for (k=0; k<ziplist->games[j].num_roms; k++)
					{
						if (ziplist->games[j].first_rom[k].match)
						{
							num_useful++;
							bytes_useful+=ziplist->games[j].first_rom[k].size;
						}
					}

					/* --- Calculate scores and print summary for the ZIP ---  */

					usefulness=(float)bytes_useful/ziplist->games[j].size;
					completeness=(float)bytes_found/missing->games[i].size;
					score=usefulness*completeness;

					fprintf(out, "        File          : %s\n", ziplist->games[j].name);
					fprintf(out, "        Contents      : %d ROMs, %ld bytes\n", ziplist->games[j].num_roms, ziplist->games[j].size);
					fprintf(out, "        Usefulness    : %d/%d ROMs, %ld/%ld bytes (%.2f%%)\n", num_useful, ziplist->games[j].num_roms, bytes_useful, ziplist->games[j].size, 100*usefulness);
					fprintf(out, "        Completeness  : %d/%d ROMs, %ld/%ld bytes (%.2f%%)\n", num_found, missing->games[i].num_roms, bytes_found, missing->games[i].size, 100*completeness);
					fprintf(out, "        Score         : %.2f%%\n\n", 100*score);

					/* --- Report contents of the ZIP (verbose mode) --- */

					if (verbose)
					{
						fprintf(out, "        Contents      : ");
						for (k=0; k<ziplist->games[j].num_roms; k++)
						{
							if (k>0)
								fprintf(out, "                        ");
		
							if (ziplist->games[j].first_rom[k].match==1)
								fprintf(out, "%s, %d bytes, crc %08lx, (1 match)\n",
									ziplist->games[j].first_rom[k].name, ziplist->games[j].first_rom[k].size,
									ziplist->games[j].first_rom[k].crc); 
							else
								fprintf(out, "%s, %d bytes, crc %08lx, (%d matches)\n",
									ziplist->games[j].first_rom[k].name, ziplist->games[j].first_rom[k].size,
									ziplist->games[j].first_rom[k].crc, ziplist->games[j].first_rom[k].match); 
						}
						fprintf(out, "\n");
					}

					/* --- Remember the ZIPs score but blank the match fields ---  */

					ziplist->games[j].score+=score;
					ziplist->games[j].match=0;

					for (k=0; k<ziplist->games[j].num_roms; k++)
						ziplist->games[j].first_rom[k].match=0;
				}
			}
		}
	}

	/* --- Sort the ziplist based on their scores --- */

	for (i=0; i<ziplist->num_games; i++)
		ziplist->game_score_idx[i].game=&ziplist->games[i];
	
	qsort(ziplist->game_score_idx, ziplist->num_games, sizeof(struct game_idx), sort_idx_by_game_score);

	/* --- Close the log and end the function --- */

	FCLOSE(out)

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Zip Report
 * -------------------------------------------------------------------------- */

int zip_report(struct dat *missing, struct dat *ziplist, int verbose)
{
	struct rom_idx *rom_match_idx;
	struct rom *rom_match;

	int i, j, k;
	int num_found, num_useful;
	long bytes_found, bytes_useful;
	double completeness;

	FILE *out=0;

	int errflg=0;

	FOPEN(out, "zf_zips.log", "w")

	/* --- Blank counts in the missing data file --- */

	for (i=0; i<missing->num_games; i++)
	{
		missing->games[i].match=0;

		for (j=0; j<missing->games[i].num_roms; j++)
			missing->games[i].first_rom[j].match=0;
	}

	for (i=0; !errflg && i<ziplist->num_games; i++)
	{
		if (ziplist->game_score_idx[i].game->score)
		{
			for (j=0; j<ziplist->game_score_idx[i].game->num_roms; j++)
			{
				/* --- Search for matching CRCs in missing --- */

				rom_match_idx=bsearch(&ziplist->game_score_idx[i].game->first_rom[j], missing->rom_crc_idx, missing->num_roms, sizeof(struct rom_idx), find_rom_by_crc_idx);

				if (rom_match_idx)
				{
					while (rom_match_idx>missing->rom_crc_idx && rom_match_idx->rom->crc==(rom_match_idx-1)->rom->crc)
						rom_match_idx--;

					while (rom_match_idx<missing->rom_crc_idx+missing->num_roms && rom_match_idx->rom->crc == ziplist->game_score_idx[i].game->first_rom[j].crc)
					{
						ziplist->game_score_idx[i].game->match++;
						ziplist->game_score_idx[i].game->first_rom[j].match++;
						rom_match_idx->game->match++;
						rom_match_idx++;
					}
				}

				/* --- Search for matching ~CRCs in missing --- */


				rom_match_idx=bsearch(&ziplist->game_score_idx[i].game->first_rom[j], missing->rom_crc_idx, missing->num_roms, sizeof(struct rom_idx), find_rom_by_comp_crc_idx);

				if (rom_match_idx)
				{
					while (rom_match_idx>missing->rom_crc_idx && rom_match_idx->rom->crc==(rom_match_idx-1)->rom->crc)
						rom_match_idx--;

					while (rom_match_idx<missing->rom_crc_idx+missing->num_roms && rom_match_idx->rom->crc == ~ziplist->game_score_idx[i].game->first_rom[j].crc)
					{
						ziplist->game_score_idx[i].game->match++;
						ziplist->game_score_idx[i].game->first_rom[j].match++;
						rom_match_idx->game->match++;
						rom_match_idx++;
					}
				}
			}

			/* --- If some ROMs were found in the missing dat then print game info --- */

			if (ziplist->game_score_idx[i].game->match)
			{
				/* --- Count up totals for ROMs found --- */

				num_useful=bytes_useful=0;

				for (j=0; j<ziplist->game_score_idx[i].game->num_roms; j++)
				{
					if (ziplist->game_score_idx[i].game->first_rom[j].match)
					{
						num_useful++;
						bytes_useful+=ziplist->game_score_idx[i].game->first_rom[j].size;
					}
				}

				/* --- Report totals for files found --- */

				fprintf(out, "File          : %s\n", ziplist->game_score_idx[i].game->name);
				fprintf(out, "Contents      : %d files, %ld bytes\n", ziplist->game_score_idx[i].game->num_roms, ziplist->game_score_idx[i].game->size);
				fprintf(out, "Usefulness    : %d/%d ROMs, %ld/%ld bytes (%.2f%%)\n", num_useful, ziplist->game_score_idx[i].game->num_roms, bytes_useful, ziplist->game_score_idx[i].game->size, (float)100*bytes_useful/ziplist->game_score_idx[i].game->size);
				fprintf(out, "Total Score   : %.2f%%\n\n", 100*ziplist->game_score_idx[i].game->score);

				/* --- Report details of files that are useful (verbose mode) --- */

				if (verbose)
				{
					fprintf(out, "Contents      : ");
					for (j=0; j<ziplist->game_score_idx[i].game->num_roms; j++)
					{
						if (j>0)
							fprintf(out, "                ");

						if (ziplist->game_score_idx[i].game->first_rom[j].match==1)
							fprintf(out, "%s, %d bytes, crc %08lx, (1 match)\n",
								ziplist->game_score_idx[i].game->first_rom[j].name, ziplist->game_score_idx[i].game->first_rom[j].size,
								ziplist->game_score_idx[i].game->first_rom[j].crc); 
						else
							fprintf(out, "%s, %d bytes, crc %08lx, (%d matches)\n",
								ziplist->game_score_idx[i].game->first_rom[j].name, ziplist->game_score_idx[i].game->first_rom[j].size,
								ziplist->game_score_idx[i].game->first_rom[j].crc, ziplist->game_score_idx[i].game->first_rom[j].match); 
					}
					fprintf(out, "\n");
				}

				/* --- Report files that were found --- */

				for (j=0; j<missing->num_games; j++)
				{
					if (missing->games[j].match)
					{
						/* --- Initialise counts for ziplist ROMs --- */

						for (k=0; k<ziplist->game_score_idx[i].game->num_roms; k++)
							ziplist->game_score_idx[i].game->first_rom[k].match=0;

						for (k=0; k<missing->games[j].num_roms; k++)
						{
							/* --- Check which CRCs are available in the ZIP --- */

							rom_match=bsearch(&missing->games[j].first_rom[k], ziplist->game_score_idx[i].game->first_rom, ziplist->game_score_idx[i].game->num_roms, sizeof(struct rom), find_rom_by_crc);
					
							if (rom_match)
							{
								while (rom_match>ziplist->roms && rom_match->crc==(rom_match-1)->crc)
									rom_match--;
				
								while (rom_match<ziplist->roms+ziplist->num_roms && rom_match->crc==missing->games[j].first_rom[k].crc)
								{
									missing->games[j].first_rom[k].match++;
									rom_match->match++;
									rom_match++;
								}
							}
				
							/* --- Check which ~CRCs are available in the ZIP --- */

							rom_match=bsearch(&missing->games[j].first_rom[k], ziplist->game_score_idx[i].game->first_rom, ziplist->game_score_idx[i].game->num_roms, sizeof(struct rom), find_rom_by_comp_crc);

							if (rom_match)
							{
								while (rom_match>ziplist->roms && rom_match->crc==(rom_match-1)->crc)
									rom_match--;
				
								while (rom_match<ziplist->roms+ziplist->num_roms && rom_match->crc==~missing->games[j].first_rom[k].crc)
								{
									missing->games[j].first_rom[k].match++;
									rom_match->match++;
									rom_match++;
								}
							}
						}

						/* --- Calculate usefulness of ZIP --- */
	
						num_found=bytes_found=0;
	
						for (k=0; k<missing->games[j].num_roms; k++)
						{
							if (missing->games[j].first_rom[k].match)
							{
								num_found++;
								bytes_found+=missing->games[j].first_rom[k].size;
							}
						}

						/* --- Calculate completeness and print summary for the ZIP ---  */

						completeness=(float)bytes_found/missing->games[j].size;

						fprintf(out, "        Game          : %s\n", missing->games[j].name);
						fprintf(out, "        Description   : %s\n", missing->games[j].title);
						fprintf(out, "        Total Needed  : %d ROMs, %ld bytes\n", missing->games[j].num_roms, missing->games[j].size);
						fprintf(out, "        Completeness  : %d/%d ROMs, %ld/%ld bytes (%.2f%%)\n\n", num_found, missing->games[j].num_roms, bytes_found, missing->games[j].size, (float)100*completeness);

						/* --- Report contents of the ZIP (verbose mode) --- */

						if (verbose)
						{
							fprintf(out, "        Contents      : ");
							for (k=0; k<missing->games[j].num_roms; k++)
							{
								if (k>0)
									fprintf(out, "                        ");
			
								if (missing->games[j].first_rom[k].match==1)
									fprintf(out, "%s, %d bytes, crc %08lx, (1 match)\n",
										missing->games[j].first_rom[k].name, missing->games[j].first_rom[k].size,
										missing->games[j].first_rom[k].crc); 
								else
									fprintf(out, "%s, %d bytes, crc %08lx, (%d matches)\n",
										missing->games[j].first_rom[k].name, missing->games[j].first_rom[k].size,
										missing->games[j].first_rom[k].crc, missing->games[j].first_rom[k].match); 
							}
							fprintf(out, "\n");
						}

						/* --- Blank the match fields ---  */

						missing->games[j].match=0;

						for (k=0; k<missing->games[j].num_roms; k++)
							missing->games[j].first_rom[k].match=0;
					}
				}
			}
		}
	}

	/* --- Close the log and end the function --- */

	FCLOSE(out)

	return(errflg);
}

/* --------------------------------------------------------------------------
 * URL Report
 * -------------------------------------------------------------------------- */

int url_report(struct dat *ziplist, char *url)
{
	FILE *out=0;
	int i, count=0;
	int errflg=0;

	FOPEN(out, "zf_fetch.log", "w")

	for (i=0; i<ziplist->num_games; i++)
	{
		if (ziplist->game_score_idx[i].game->score)
		{
			if (url)
				fprintf(out, "%s", url);
			fprintf(out, "%s\n", ziplist->game_score_idx[i].game->name);
			count++;
		}
	}

	FCLOSE(out)

	switch (count)
	{
		case 0:
			printf("\nNo ZIPs found!\n");
			break;
		case 1:
			printf("\n1 ZIP identified for download - see zf_fetch.log\n");
			break;
		default:
			printf("\n%d ZIPs identified for download - see zf_fetch.log\n", count);
			break;
	}

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Loads MAME Listinfo into memory
 * -------------------------------------------------------------------------- */

int load_mame_listinfo(struct dat *dat_info)
{
	FILE *in;
	char st[BUFFER_SIZE], token[BUFFER_SIZE];
	char *st_ptr;
	struct game *games;
	struct rom *roms; struct rom_idx *rom_crc_idx;
	int num_games=0; long num_roms=0;
	int in_header=0;
	int i, j;
	int errflg=0;

	if (!errflg)
		FOPEN(in, dat_info->name, "r")

	if (!errflg)
		CALLOC(dat_info->games, MAX_GAMES, game)

	if (!errflg)
		CALLOC(dat_info->game_score_idx, MAX_GAMES, game_idx)

	if (!errflg)
		CALLOC(dat_info->roms, MAX_ROMS, rom)

	if (!errflg)
		CALLOC(dat_info->rom_crc_idx, MAX_ROMS, rom_idx)

	if (!errflg)
	{
		games=dat_info->games;
		roms=dat_info->roms;
		rom_crc_idx=dat_info->rom_crc_idx;

		games[0].first_rom=&roms[0];

		printf("Loading %s...", dat_info->name);
	}

	while (!errflg && fgets(st, BUFFER_SIZE, in))
	{
		REMOVE_CR_LF(st)

		st_ptr=st;
		GET_TOKEN(token, st_ptr)

		if (!strcmp(token, "clrmamepro") || !strcmp(token, "emulator"))
		{
			in_header++;
		}

		if (!strcmp(token, "name"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].name, token, FILE_NAME_LENGTH);
			games[num_games].name[FILE_NAME_LENGTH]='\0';
		}

		if (!strcmp(token, "description"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].title, token, TITLE_LENGTH);
			games[num_games].title[TITLE_LENGTH]='\0';
		}

		if (!strcmp(token, "rom"))
		{
			/* --- Extract details and store them --- */ 
			st_ptr=st; 
			GET_TOKEN(token, st_ptr) /* skip rom token */ 
			GET_TOKEN(token, st_ptr) /* skip bracket */ 
			GET_TOKEN(token, st_ptr) 
			while (*token) 
			{ 
				/* --- ROM name --- */ 
				if (!strcmp(token, "name")) 
				{ 
					GET_TOKEN(token, st_ptr) 
					LOWER(token) 
					strncpy(roms[num_roms].name, token, FILE_NAME_LENGTH); 
					roms[num_roms].name[FILE_NAME_LENGTH]='\0'; 
					*token='\0'; 
				} 
				/* --- ROM size --- */ 
				if (!strcmp(token, "size")) 
				{ 
					GET_TOKEN(token, st_ptr) 
					roms[num_roms].size=strtoul(token, NULL, 10); 
				} 
				/* --- ROM CRC --- */ 
				if (!strcmp(token, "crc") || !strcmp(token, "crc32")) 
				{ 
					GET_TOKEN(token, st_ptr) 
					roms[num_roms].crc=strtoul(token, NULL, 16); 
				} 
				/* --- Onto next property... --- */ 
				GET_TOKEN(token, st_ptr) 
			} 

			/* --- That's one more ROM --- */ 
			rom_crc_idx[num_roms].rom=&roms[num_roms]; 
			rom_crc_idx[num_roms].game=&games[num_games]; 
		
			games[num_games].num_roms++; 
			num_roms++; 
		}

		if (token[0]==')')
		{
			if (!in_header)
			{
				qsort(games[num_games].first_rom, games[num_games].num_roms, sizeof(struct rom), sort_roms_by_crc);
				games[++num_games].first_rom=&roms[num_roms];
			}

			in_header=0;
		}

		if (num_roms>=MAX_ROMS)
		{
			printf("Maximum number of ROMs exceeded - aborting!\n");
			errflg++;
		}

		if (num_games>=MAX_GAMES)
		{
			printf("Maximum number of games exceeded - aborting!\n");
			errflg++;
		}
	}

	if (!errflg)
	{
		for (i=0; i<num_games; i++)
			for (j=0; j<games[i].num_roms; j++)
				games[i].size+=games[i].first_rom[j].size;
			
		dat_info->num_games=num_games;
		dat_info->num_roms=num_roms;

		/* --- Sort the ROM index so that a binary search can be used later --- */
		qsort(rom_crc_idx, num_roms, sizeof(struct rom_idx), sort_idx_by_rom_crc);

		/* --- Print summary --- */
		printf(" %d games/resources (%ld ROMs)\n", dat_info->num_games, dat_info->num_roms);
	}

	FCLOSE(in)

	return(errflg);
}

int load_ziplist(struct dat *dat_info)
{
	FILE *in;
	char st[BUFFER_SIZE];
	char *ptr;
	struct game *games;
	struct rom *roms; struct rom_idx *rom_crc_idx;
	int num_games=0; long num_roms=0;
	char delimiter[2];
	int i, j;
	int invalid=0, errflg=0;

	if (!errflg)
		FOPEN(in, dat_info->name, "r")

	if (!errflg)
		CALLOC(dat_info->games, MAX_GAMES, game)

	if (!errflg)
		CALLOC(dat_info->game_score_idx, MAX_GAMES, game_idx)

	if (!errflg)
		CALLOC(dat_info->roms, MAX_ROMS, rom)

	if (!errflg)
		CALLOC(dat_info->rom_crc_idx, MAX_ROMS, rom_idx)

	if (!errflg)
	{
		games=dat_info->games;
		roms=dat_info->roms;
		rom_crc_idx=dat_info->rom_crc_idx;

		games[0].first_rom=&roms[0];

		printf("Loading %s...", dat_info->name);
	}

	while (!errflg && fgets(st, BUFFER_SIZE, in))
	{
		REMOVE_CR_LF(st)

		if (!strncmp(st, "./", 2))
			strcpy(st, st+2);

		invalid=0;

		if (strchr(st, '\t'))
			sprintf(delimiter, "\t");
		else
			sprintf(delimiter, " ");

		if ((ptr=strtok(st, delimiter))!=0)
		{
			if (games[num_games].name[0] && strncmp(games[num_games].name, ptr, FILE_NAME_LENGTH))
			{
				qsort(games[num_games].first_rom, games[num_games].num_roms, sizeof(struct rom), sort_roms_by_crc);
				num_games++;

				if (num_games<MAX_GAMES)
				{
					games[num_games].first_rom=&roms[num_roms];
				}
				else
				{
					printf("Maximum number of games exceeded - aborting!\n");
					errflg++;
				}
			}

			if (!errflg)
			{
				strncpy(games[num_games].name, ptr, FILE_NAME_LENGTH);
				games[num_games].name[FILE_NAME_LENGTH]='\0';
			}
		}
		else
			invalid++;

		if ((ptr=strtok(NULL, delimiter))!=0)
		{
			strncpy(roms[num_roms].name, ptr, FILE_NAME_LENGTH); 
			roms[num_roms].name[FILE_NAME_LENGTH]='\0'; 
		}
		else
			invalid++;

		if ((ptr=strtok(NULL, delimiter))!=0)
			roms[num_roms].size=strtoul(ptr, NULL, 10);
		else
			invalid++;

		if ((ptr=strtok(NULL, delimiter))!=0)
			roms[num_roms].crc=strtoul(ptr, NULL, 16); 
		else
			invalid++;

		if (!invalid && roms[num_roms].size)
		{
			rom_crc_idx[num_roms].rom=&roms[num_roms]; 
			rom_crc_idx[num_roms].game=&games[num_games]; 
		
			games[num_games].num_roms++; 
			num_roms++;

			if (num_roms>=MAX_ROMS)
			{
				printf("Maximum number of ROMs exceeded - aborting!\n");
				errflg++;
			}
		}
		else
		{
			/* --- Forget the gamename that was stored --- */
			games[num_games].name[0]='\0';
		}
	}

	if (!errflg && games[num_games].name[0])
	{
		qsort(games[num_games].first_rom, games[num_games].num_roms, sizeof(struct rom), sort_roms_by_crc);
		num_games++;
	}

	if (!errflg)
	{
		for (i=0; i<num_games; i++)
			for (j=0; j<games[i].num_roms; j++)
				games[i].size+=games[i].first_rom[j].size;
			
		dat_info->num_games=num_games;
		dat_info->num_roms=num_roms;

		/* --- Sort the ROM index so that a binary search can be used later --- */
		qsort(rom_crc_idx, num_roms, sizeof(struct rom_idx), sort_idx_by_rom_crc);

		/* --- Print summary --- */
		printf(" %d ZIPs (%ld ROMs)\n", dat_info->num_games, dat_info->num_roms);
	}

	FCLOSE(in)

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Sorting functions for qsort - not very complicated!
 * -------------------------------------------------------------------------- */

int sort_roms_by_crc(const void *rom1, const void *rom2)
{
	if (((struct rom *)rom2)->crc > ((struct rom *)rom1)->crc)
		return(-1);

	if (((struct rom *)rom2)->crc < ((struct rom *)rom1)->crc)
		return(1);

	return(0);
}

int sort_idx_by_rom_crc(const void *idx1, const void *idx2)
{
	if (((struct rom_idx *)idx2)->rom->crc > ((struct rom_idx *)idx1)->rom->crc)
		return(-1);

	if (((struct rom_idx *)idx2)->rom->crc < ((struct rom_idx *)idx1)->rom->crc)
		return(1);

	return(0);
}

int sort_idx_by_game_score(const void *idx1, const void *idx2)
{
	if (((struct game_idx *)idx2)->game->score < ((struct game_idx *)idx1)->game->score)
		return(-1);

	if (((struct game_idx *)idx2)->game->score > ((struct game_idx *)idx1)->game->score)
		return(1);

	return(0);
}

int find_rom_by_crc(const void *rom_to_find, const void *rom_to_check)
{
	if (((struct rom *)rom_to_check)->crc > ((struct rom *)rom_to_find)->crc)
		return(-1);

	if (((struct rom *)rom_to_check)->crc < ((struct rom *)rom_to_find)->crc)
		return(1);

	return(0);
}

int find_rom_by_crc_idx(const void *rom_to_find, const void *idx_to_check)
{
	if (((struct rom_idx *)idx_to_check)->rom->crc > ((struct rom *)rom_to_find)->crc)
		return(-1);

	if (((struct rom_idx *)idx_to_check)->rom->crc < ((struct rom *)rom_to_find)->crc)
		return(1);

	return(0);
}

int find_rom_by_comp_crc(const void *rom_to_find, const void *rom_to_check)
{
	if (((struct rom *)rom_to_check)->crc > ~((struct rom *)rom_to_find)->crc)
		return(-1);

	if (((struct rom *)rom_to_check)->crc < ~((struct rom *)rom_to_find)->crc)
		return(1);

	return(0);
}

int find_rom_by_comp_crc_idx(const void *rom_to_find, const void *idx_to_check)
{
	if (((struct rom_idx *)idx_to_check)->rom->crc > ~((struct rom *)rom_to_find)->crc)
		return(-1);

	if (((struct rom_idx *)idx_to_check)->rom->crc < ~((struct rom *)rom_to_find)->crc)
		return(1);

	return(0);
}

/* --------------------------------------------------------------------------
 * Function to release dat from memory
 * -------------------------------------------------------------------------- */

int release_dat(struct dat *dat_info)
{
	if (dat_info)
	{
		FREE(dat_info->rom_crc_idx)
		FREE(dat_info->roms)
		FREE(dat_info->game_score_idx)
		FREE(dat_info->games)
	}

	FREE(dat_info)

	return(0);
}


/* --------------------------------------------------------------------------
 * MAMEDiff - Written by Logiqx (http://www.logiqx.com/)
 *
 * A simple little utility for comparing different versions of MAME to identify
 * changes required to your ROM sets.
 * -------------------------------------------------------------------------- */

/* --- Size declarations --- */

#define MAX_GAMES 6000
#define MAX_RESOURCE_ROMS 100
#define MAX_ROMS MAX_GAMES*15

#define LONG_NAME_LENGTH 128
#define FILE_NAME_LENGTH 20
#define GAME_NAME_LENGTH 20
#define MANUFACTURER_LENGTH 60
#define YEAR_LENGTH 4
#define TITLE_LENGTH 100
#define CRC_LENGTH 8
#define SIZE_LENGTH 9

#define BUFFER_SIZE 32768

/* --- Enumerated types and flags --- */

enum
{
	ANY_MERGING,
	FULL_MERGING,
	SPLIT_MERGING,
	NO_MERGING
};

enum
{
	NO_SET_TYPE,
	NON_MERGED_SETS,
	SPLIT_SETS,
	MERGED_SETS,
	NON_MERGED_ZIPS,
	SPLIT_ZIPS,
	MERGED_ZIPS
};

#define PROCESSED       0x00000001
#define RESOURCE        0x10000000
#define RESOURCE_NEEDED 0x20000000

#define GAME_RENAMED    0x00000002  /* name of game changed */
#define GAME_NEW_CLONE  0x00000004  /* cloneof property of game changed */
#define GAME_ADDED      0x00000008  /* game only exists in 2nd dat */
#define GAME_REMOVED    0x00000010  /* game only exists in 1st dat */

#define ROMS_CHANGED    0x00000020  /* only used by ZIP comparison routines */
#define ROMS_RENAMED    0x00000040  /* name has changed for some ROMs in game */
#define ROMS_MERGED     0x00000080  /* merging now used for some ROMs in game */
#define ROMS_UNMERGED   0x00000100  /* merging stopped for some ROMs in game */
#define ROMS_ADDED      0x00000200  /* ROMs were added to the game in dat2 */
#define ROMS_REMOVED    0x00000400  /* ROMs were removed from the game */

#define P_ROMS_CHANGED  0x00000800  /* currently UNUSED by MameDiff */
#define P_ROMS_RENAMED  0x00001000  /* name has changed for some ROMs in parent */
#define P_ROMS_ADDED    0x00002000  /* ROMs were added to the parent in dat2 */
#define P_ROMS_REMOVED  0x00004000  /* ROMs were removed from the parent */

#define ROMS_COMP_CRC   0x00008000  /* ROMs CRCs were complimented */
#define P_ROMS_COMP_CRC 0x00010000  /* ROMs CRCs were complimented */

/* --- Dat structures --- */

struct zip_entry
{
	char game_name[GAME_NAME_LENGTH+1];
	char rom_name[FILE_NAME_LENGTH+1];
	char crc[CRC_LENGTH+1];
	char size[SIZE_LENGTH+1];
};

struct zip_change
{
	char name[GAME_NAME_LENGTH+1];
	unsigned long flags;
};

struct rom
{
	char crc[CRC_LENGTH+1];
	char name[FILE_NAME_LENGTH+1];
	char merge[FILE_NAME_LENGTH+1];
	char size[SIZE_LENGTH+1];
};

struct rom_idx
{
	struct rom *rom;
	struct game *game;
};

struct game
{
	char name[GAME_NAME_LENGTH+1];
	char title[TITLE_LENGTH+1];
	char manufacturer[MANUFACTURER_LENGTH+1];
	char year[YEAR_LENGTH+1];
	char cloneof[GAME_NAME_LENGTH+1];
	char romof[GAME_NAME_LENGTH+1];
	char parent_title[TITLE_LENGTH+1];
	struct rom *first_rom;
	int num_roms;
	unsigned long flags;
	unsigned long crc;
};

struct game_idx
{
	unsigned long crc;
	struct game *game;
};

struct dat
{
	char name[LONG_NAME_LENGTH+1];
	int merging;
	struct game *games;
	struct game_idx *games_idx;
	struct rom *roms;
	struct rom *resource_roms;
	struct rom_idx *roms_idx;
	int num_games;
	long num_roms;
	int num_resource_roms;
};

struct game_change
{
	struct game *game1;
	struct game *game2;
	struct rom_change *rom_changes;
	unsigned long flags;
	int num_rom_changes;
};

struct game_change_text
{
	char name[GAME_NAME_LENGTH+1];
	char title[TITLE_LENGTH+1];
};

struct rom_change
{
	struct rom *rom1;
	struct rom *rom2;
	unsigned long flags;
};

/* --- Function prototypes for the sorting functions --- */

int standard_compare(int, char *, char *, int, int);
int zip_compare(int, char *, char *);
int tiny_compare(int, int, char *, char *);
int is_resource_rom(struct dat *, struct rom *);
void print_game(FILE *, struct dat *, struct game *, int);

void report_game_changes(FILE *, unsigned long, char *, struct rom_idx *, long, struct game_change *, int, int);
void report_required_roms(FILE *, unsigned long, char *, struct game_change *, int);
void report_required_rebuilds(FILE *, int, int, char *, struct game_change *, int);
void output_title(FILE *, char *);

int init_dat(struct dat *, char *);
int load_mame_listinfo(struct dat *);
void fix_merge_info(struct dat *);
int release_dat(struct dat *);

int zip_entry_sort_function(const void *, const void *);
int zip_entry_search_function(const void *, const void *);
int game_search_function(const void *, const void *);

int game_sort_function(const void *, const void *);
int idx_sort_function(const void *, const void *);

int rom_sort_function(const void *, const void *);
int rom_idx_sort_function(const void *, const void *);
int rom_idx_find_function_1(const void *, const void *);
int rom_idx_find_function_2(const void *, const void *);

int rebuild_text_sort_function(const void *, const void *);


/* --------------------------------------------------------------------------
 * STORE_ROM macro
 *
 * Based on code from DatUtil (but stripped out non-MAME related bits)
 * -------------------------------------------------------------------------- */

#define LOWER(ST) \
{ \
	char *ptr=ST; \
	int i; \
	for (i=0; i<strlen(ptr); i++) \
		ptr[i]=tolower(ptr[i]); \
}

#define GET_TOKEN(TOKEN, ST_PTR) \
{ \
	int token_idx=0; \
\
	while (*ST_PTR==' ' || *ST_PTR=='	') \
		ST_PTR++; \
\
	if (*ST_PTR=='"') \
	{ \
		ST_PTR++; \
		while (*ST_PTR!='"' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
		if (*ST_PTR!='\0') \
			ST_PTR++; \
	} \
	else \
	{ \
		while (*ST_PTR!=' ' && *ST_PTR!='	' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
	} \
}

#define STORE_ROM(ST) \
{ \
	/* --- Extract details and store them --- */ \
	st_ptr=ST; \
	GET_TOKEN(token, st_ptr) /* skip rom token */ \
	GET_TOKEN(token, st_ptr) /* skip bracket */ \
	GET_TOKEN(token, st_ptr) \
	while (*token) \
	{ \
		/* --- ROM name --- */ \
		if (!strcmp(token, "name")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			strncpy(roms[num_roms].name, token, FILE_NAME_LENGTH); \
			roms[num_roms].name[FILE_NAME_LENGTH]='\0'; \
			*token='\0'; \
		} \
		/* --- ROM 'merge' name --- */ \
		if (!strcmp(token, "merge")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			strncpy(roms[num_roms].merge, token, FILE_NAME_LENGTH); \
			roms[num_roms].merge[FILE_NAME_LENGTH]='\0'; \
			*token='\0'; \
		} \
		/* --- ROM size --- */ \
		if (!strcmp(token, "size")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			strncpy(roms[num_roms].size, token, TITLE_LENGTH); \
			roms[num_roms].size[TITLE_LENGTH]='\0'; \
		} \
		/* --- ROM CRC --- */ \
		if (!strcmp(token, "crc") || !strcmp(token, "crc32")) \
		{ \
			GET_TOKEN(token, st_ptr) \
			LOWER(token) \
			if (!strncmp(token, "0x", 2)) \
				strcpy(roms[num_roms].crc, token+2); \
			else \
				strcpy(roms[num_roms].crc, token); \
		} \
		/* --- Onto next property... --- */ \
		GET_TOKEN(token, st_ptr) \
	} \
	/* --- That's one more ROM --- */ \
	roms_idx[num_roms].rom=&roms[num_roms]; \
	roms_idx[num_roms].game=&games[num_games]; \
\
	if (in_resource) \
	{ \
		memcpy(&resource_roms[num_resource_roms], &roms[num_roms], sizeof(struct rom)); \
		num_resource_roms++; \
	} \
\
	games[num_games].num_roms++; \
	num_roms++; \
}

/* --------------------------------------------------------------------------
 * COMPARE_GAMES
 *
 * Compares two games for differences and adds results to game_changes array
 * -------------------------------------------------------------------------- */

int compare_games(struct game_change *game_change, struct game *game1, struct game *game2, int set_type)
{
	struct rom *roms1;
	struct rom *roms2;
	int game_flags=0, rom_flags;
	int i=0, j=0, k;
	int diff;
	char comp[CRC_LENGTH+1];
	int found;

	if (game1 && !game2)
		game_flags|=GAME_REMOVED;

	if (!game1 && game2)
		game_flags|=GAME_ADDED;

	if (game1 && game2)
	{
		roms1=game1->first_rom;
		roms2=game2->first_rom;

		if (strcmp(game1->name, game2->name))
			game_flags|=GAME_RENAMED;

		if (strcmp(game1->cloneof, game2->cloneof))
			game_flags|=GAME_NEW_CLONE;

		while (i<game1->num_roms || j<game2->num_roms)
		{
			game_change->rom_changes[game_change->num_rom_changes].rom1=&roms1[i];
			game_change->rom_changes[game_change->num_rom_changes].rom2=&roms2[j];
			rom_flags=0;

			if (i>=game1->num_roms) diff=1;
			if (j>=game2->num_roms) diff=-1;
			if (i<game1->num_roms && j<game2->num_roms)
				diff=strcmp(roms1[i].crc, roms2[j].crc);

			if (diff==0)
			{
				if (strcmp(roms1[i].name, roms2[j].name))
				{
					if (i<game1->num_roms-1 &&
						!strcmp(roms1[i+1].crc, roms2[j].crc) &&
						strcmp(roms1[i+1].name, roms2[j].name)<=0)
					{
						if (*roms1[i].merge)
							rom_flags|=P_ROMS_REMOVED;
						else
							rom_flags|=ROMS_REMOVED;
					}
					else if (j<game2->num_roms-1 &&
						!strcmp(roms1[i].crc, roms2[j+1].crc) &&
						strcmp(roms1[i].name, roms2[j+1].name)>=0)
					{
						if (*roms2[j].merge)
							rom_flags|=P_ROMS_ADDED;
						else
							rom_flags|=ROMS_ADDED;
					}
					else
					{
						if (*roms1[i].merge)
							rom_flags|=P_ROMS_RENAMED;
						else
							rom_flags|=ROMS_RENAMED;

						if (*roms1[i].merge && !*roms2[j].merge)
							rom_flags|=ROMS_UNMERGED;

						if (!*roms1[i].merge && *roms2[j].merge)
							rom_flags|=ROMS_MERGED;
					}
				}
				else
				{
					if (*roms1[i].merge && !*roms2[j].merge)
						rom_flags|=ROMS_UNMERGED;

					if (!*roms1[i].merge && *roms2[j].merge)
						rom_flags|=ROMS_MERGED;
				}

				if (!(rom_flags & (ROMS_ADDED | P_ROMS_ADDED)))
					i++;

				if (!(rom_flags & (ROMS_REMOVED | P_ROMS_REMOVED)))
					j++;
			}

			if (diff<0)
			{
				sprintf(comp, "%08lx", ~strtoul(roms1[i].crc, NULL, 16));

				for (found=k=0; k<game2->num_roms; k++)
				{
					if (!strcmp(roms2[k].crc, comp))
					{
						game_change->rom_changes[game_change->num_rom_changes].rom2=&roms2[k];

						if (*roms1[i].merge)
							rom_flags|=P_ROMS_COMP_CRC;
						else
							rom_flags|=ROMS_COMP_CRC;

						if (*roms1[i].merge && !*roms2[k].merge)
							rom_flags|=ROMS_UNMERGED;

						if (!*roms1[i].merge && *roms2[k].merge)
							rom_flags|=ROMS_MERGED;

						if (strcmp(roms1[i].name, roms2[k].name))
						{
							if (*roms1[i].merge)
								rom_flags|=P_ROMS_RENAMED;
							else
								rom_flags|=ROMS_RENAMED;
						}
						found=1;
					}
				}

				if (!found)
				{
					if (*roms1[i].merge)
						rom_flags|=P_ROMS_REMOVED;
					else
						rom_flags|=ROMS_REMOVED;
				}
	
				i++;
			}

			if (diff>0)
			{
				sprintf(comp, "%08lx", ~strtoul(roms2[j].crc, NULL, 16));

				for (found=k=0; k<game1->num_roms; k++)
					if (!strcmp(roms1[k].crc, comp))
						found=1;

				if (!found)
				{
					if (*roms2[j].merge)
						rom_flags|=P_ROMS_ADDED;
					else
						rom_flags|=ROMS_ADDED;
				}

				j++;
			}

			if (rom_flags)
				game_change->rom_changes[game_change->num_rom_changes++].flags=rom_flags;

			game_flags|=rom_flags;
		}
	}

	if (game_flags)
	{
		game_change->game1=game1;
		game_change->game2=game2;
		game_change->flags=game_flags;
	}

	return(game_flags);
}

#define COMPARE_GAMES(GAME1, GAME2) \
{ \
	if (compare_games(&game_changes[num_game_changes], GAME1, GAME2, set_type)) \
	{ \
		game_changes[num_game_changes+1].rom_changes=game_changes[num_game_changes].rom_changes+ \
			game_changes[num_game_changes].num_rom_changes; \
		num_game_changes++; \
	} \
\
	if (GAME1) \
		((struct game *)GAME1)->flags|=PROCESSED; \
	if (GAME2) \
		((struct game *)GAME2)->flags|=PROCESSED; \
}

#define FORMAT_GAME_NAME(ST, GAME) \
{ \
	strncpy(st, GAME->title, 41); \
	st[41]='\0'; \
	strcat(st, " [name: "); \
	strcat(st, GAME->name); \
	if (strcmp(GAME->name, GAME->cloneof)) \
	{ \
		strcat(st, " - parent: "); \
		strcat(st, GAME->cloneof); \
	} \
	strcat(st, "]"); \
}

#define FORMAT_ROM_NAME(ST, ROM) \
{ \
	strcpy(st, "rom ( name "); \
	strcat(st, ROM->name); \
	if (*ROM->merge) \
	{ \
		strcat(st, " merge " ); \
		strcat(st, ROM->merge); \
	} \
	strcat(st, " size " ); \
	strcat(st, ROM->size); \
	strcat(st, " crc " ); \
	strcat(st, ROM->crc); \
	strcat(st, " )" ); \
}

/* --------------------------------------------------------------------------
 * CRC32 Definitions
 *
 * MameDiff uses CRC32 for fast game identification
 * -------------------------------------------------------------------------- */

#define CRC32_XINIT 0xFFFFFFFFL		/* initial value */
#define CRC32_XOROT 0xFFFFFFFFL		/* final xor value */

unsigned long crctable[256] =
{
	0x00000000L, 0x77073096L, 0xEE0E612CL, 0x990951BAL,
	0x076DC419L, 0x706AF48FL, 0xE963A535L, 0x9E6495A3L,
	0x0EDB8832L, 0x79DCB8A4L, 0xE0D5E91EL, 0x97D2D988L,
	0x09B64C2BL, 0x7EB17CBDL, 0xE7B82D07L, 0x90BF1D91L,
	0x1DB71064L, 0x6AB020F2L, 0xF3B97148L, 0x84BE41DEL,
	0x1ADAD47DL, 0x6DDDE4EBL, 0xF4D4B551L, 0x83D385C7L,
	0x136C9856L, 0x646BA8C0L, 0xFD62F97AL, 0x8A65C9ECL,
	0x14015C4FL, 0x63066CD9L, 0xFA0F3D63L, 0x8D080DF5L,
	0x3B6E20C8L, 0x4C69105EL, 0xD56041E4L, 0xA2677172L,
	0x3C03E4D1L, 0x4B04D447L, 0xD20D85FDL, 0xA50AB56BL,
	0x35B5A8FAL, 0x42B2986CL, 0xDBBBC9D6L, 0xACBCF940L,
	0x32D86CE3L, 0x45DF5C75L, 0xDCD60DCFL, 0xABD13D59L,
	0x26D930ACL, 0x51DE003AL, 0xC8D75180L, 0xBFD06116L,
	0x21B4F4B5L, 0x56B3C423L, 0xCFBA9599L, 0xB8BDA50FL,
	0x2802B89EL, 0x5F058808L, 0xC60CD9B2L, 0xB10BE924L,
	0x2F6F7C87L, 0x58684C11L, 0xC1611DABL, 0xB6662D3DL,
	0x76DC4190L, 0x01DB7106L, 0x98D220BCL, 0xEFD5102AL,
	0x71B18589L, 0x06B6B51FL, 0x9FBFE4A5L, 0xE8B8D433L,
	0x7807C9A2L, 0x0F00F934L, 0x9609A88EL, 0xE10E9818L,
	0x7F6A0DBBL, 0x086D3D2DL, 0x91646C97L, 0xE6635C01L,
	0x6B6B51F4L, 0x1C6C6162L, 0x856530D8L, 0xF262004EL,
	0x6C0695EDL, 0x1B01A57BL, 0x8208F4C1L, 0xF50FC457L,
	0x65B0D9C6L, 0x12B7E950L, 0x8BBEB8EAL, 0xFCB9887CL,
	0x62DD1DDFL, 0x15DA2D49L, 0x8CD37CF3L, 0xFBD44C65L,
	0x4DB26158L, 0x3AB551CEL, 0xA3BC0074L, 0xD4BB30E2L,
	0x4ADFA541L, 0x3DD895D7L, 0xA4D1C46DL, 0xD3D6F4FBL,
	0x4369E96AL, 0x346ED9FCL, 0xAD678846L, 0xDA60B8D0L,
	0x44042D73L, 0x33031DE5L, 0xAA0A4C5FL, 0xDD0D7CC9L,
	0x5005713CL, 0x270241AAL, 0xBE0B1010L, 0xC90C2086L,
	0x5768B525L, 0x206F85B3L, 0xB966D409L, 0xCE61E49FL,
	0x5EDEF90EL, 0x29D9C998L, 0xB0D09822L, 0xC7D7A8B4L,
	0x59B33D17L, 0x2EB40D81L, 0xB7BD5C3BL, 0xC0BA6CADL,
	0xEDB88320L, 0x9ABFB3B6L, 0x03B6E20CL, 0x74B1D29AL,
	0xEAD54739L, 0x9DD277AFL, 0x04DB2615L, 0x73DC1683L,
	0xE3630B12L, 0x94643B84L, 0x0D6D6A3EL, 0x7A6A5AA8L,
	0xE40ECF0BL, 0x9309FF9DL, 0x0A00AE27L, 0x7D079EB1L,
	0xF00F9344L, 0x8708A3D2L, 0x1E01F268L, 0x6906C2FEL,
	0xF762575DL, 0x806567CBL, 0x196C3671L, 0x6E6B06E7L,
	0xFED41B76L, 0x89D32BE0L, 0x10DA7A5AL, 0x67DD4ACCL,
	0xF9B9DF6FL, 0x8EBEEFF9L, 0x17B7BE43L, 0x60B08ED5L,
	0xD6D6A3E8L, 0xA1D1937EL, 0x38D8C2C4L, 0x4FDFF252L,
	0xD1BB67F1L, 0xA6BC5767L, 0x3FB506DDL, 0x48B2364BL,
	0xD80D2BDAL, 0xAF0A1B4CL, 0x36034AF6L, 0x41047A60L,
	0xDF60EFC3L, 0xA867DF55L, 0x316E8EEFL, 0x4669BE79L,
	0xCB61B38CL, 0xBC66831AL, 0x256FD2A0L, 0x5268E236L,
	0xCC0C7795L, 0xBB0B4703L, 0x220216B9L, 0x5505262FL,
	0xC5BA3BBEL, 0xB2BD0B28L, 0x2BB45A92L, 0x5CB36A04L,
	0xC2D7FFA7L, 0xB5D0CF31L, 0x2CD99E8BL, 0x5BDEAE1DL,
	0x9B64C2B0L, 0xEC63F226L, 0x756AA39CL, 0x026D930AL,
	0x9C0906A9L, 0xEB0E363FL, 0x72076785L, 0x05005713L,
	0x95BF4A82L, 0xE2B87A14L, 0x7BB12BAEL, 0x0CB61B38L,
	0x92D28E9BL, 0xE5D5BE0DL, 0x7CDCEFB7L, 0x0BDBDF21L,
	0x86D3D2D4L, 0xF1D4E242L, 0x68DDB3F8L, 0x1FDA836EL,
	0x81BE16CDL, 0xF6B9265BL, 0x6FB077E1L, 0x18B74777L,
	0x88085AE6L, 0xFF0F6A70L, 0x66063BCAL, 0x11010B5CL,
	0x8F659EFFL, 0xF862AE69L, 0x616BFFD3L, 0x166CCF45L,
	0xA00AE278L, 0xD70DD2EEL, 0x4E048354L, 0x3903B3C2L,
	0xA7672661L, 0xD06016F7L, 0x4969474DL, 0x3E6E77DBL,
	0xAED16A4AL, 0xD9D65ADCL, 0x40DF0B66L, 0x37D83BF0L,
	0xA9BCAE53L, 0xDEBB9EC5L, 0x47B2CF7FL, 0x30B5FFE9L,
	0xBDBDF21CL, 0xCABAC28AL, 0x53B39330L, 0x24B4A3A6L,
	0xBAD03605L, 0xCDD70693L, 0x54DE5729L, 0x23D967BFL,
	0xB3667A2EL, 0xC4614AB8L, 0x5D681B02L, 0x2A6F2B94L,
	0xB40BBE37L, 0xC30C8EA1L, 0x5A05DF1BL, 0x2D02EF8DL
};


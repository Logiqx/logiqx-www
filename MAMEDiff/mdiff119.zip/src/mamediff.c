/* --------------------------------------------------------------------------
 * MAMEDiff - Written by Logiqx (http://www.logiqx.com/)
 *
 * A simple little utility for comparing different versions of MAME to identify
 * changes required to your ROM sets.
 * -------------------------------------------------------------------------- */

#define MAMEDIFF_VERSION "v1.19"
#define MAMEDIFF_DATE "20 May 2003"

/* --- The standard includes --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* --- Although DJGPP has a getopt function, MinGW, CygWin and MSVC don't --- */

#if defined (__MINGW32_VERSION) || defined (__CYGWIN__) || defined (_MSC_VER)
#include "getopt.c"	// Same functions as in unistd library
#else
#include <unistd.h>
#endif

/* --- My type definitions and macros --- */

#include "mamediff.h"

/*#define DEBUG 1*/

/* --------------------------------------------------------------------------
 * The main() function just works out what the user wants to do then calls the
 * appropriate function.
 *
 * Uses the getopt() function from unistd to interpret command line options.
 * -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
	/* --- For getopt function --- */

	//extern char *optarg;
	extern int optind;

	int c, errflg = 0;
	int set_type=0;
	int verbose=0, tiny=0, crc_support=0, caesar=0;

	printf("===============================================================================\n");
	printf("MAMEDiff %s (%s)\n", MAMEDIFF_VERSION, MAMEDIFF_DATE);
	printf("Written by Logiqx (http://www.logiqx.com/)\n");
	printf("===============================================================================\n");

	/* --- Get the options specified on the command line --- */

	while ((c = getopt(argc, argv, "msnMSNtTvc?")) != EOF)      /* MSN - Eurghhh! */
	switch (c)
	{
		case 'm':
			errflg+=set_type;
			set_type=MERGED_SETS;
			break;
		case 's':
			errflg+=set_type;
			set_type=SPLIT_SETS;
			break;
		case 'n':
			errflg+=set_type;
			set_type=NON_MERGED_SETS;
			break;
		case 'M':
			errflg+=set_type;
			set_type=MERGED_ZIPS;
			break;
		case 'S':
			errflg+=set_type;
			set_type=SPLIT_ZIPS;
			break;
		case 'N':
			errflg+=set_type;
			set_type=NON_MERGED_ZIPS;
			break;
		case 'v':
			errflg+=set_type;
			verbose++;
			break;
		case 't':
			tiny=1; crc_support=0;
			break;
		case 'T':
			tiny=1; crc_support=1;
			break;
		case 'c':
			errflg+=set_type;
			caesar++;
			break;
		case '?':
			errflg++;   /* User wants help! */
	}

	/* --- The user must specify either one or two dat files --- */

	if (tiny && set_type==0)
		errflg++;

	if (argc-optind!=2)
		errflg++;

	/* --- Display the help page if required --- */

	if (errflg)
	{
		printf("Usage: mamediff [[-v|m|s|n] | [-M|S|N [-t|T]]] <old listinfo> <new listinfo>\n\n");
		printf("Running MAMEDiff without specifying a type of ROM set will produce a summary of\nchanges made to the ROM sets of individual games. If you specify a type of ROM\nset, MAMEDiff will tell you which ZIP files need rebuilding (if you have them).\n\n");
		printf("The three ROM set types are 'm'erged, 's'plit or 'n'on-merged.\n\n");
		printf("Use verbose mode (the -v option) for a detailed report of ROM changes.\n\n");
		printf("Use capital M/S/N to list changes at ZIP level (instead of game level).\n\n");
		printf("Use 'tiny' mode in addition to M/S/N for a minimal mamediff.dat.\n");
		exit (1);
	}

	if (set_type < NON_MERGED_ZIPS)
		errflg=standard_compare(set_type, argv[optind], argv[optind+1], verbose, caesar);
	else if (tiny==0)
		errflg=zip_compare(set_type, argv[optind], argv[optind+1]);
	else
		errflg=tiny_compare(set_type, crc_support, argv[optind], argv[optind+1]);

	/* --- All done --- */

	exit(errflg);
}

/* --------------------------------------------------------------------------
 * Comparison
 * -------------------------------------------------------------------------- */

int standard_compare(int set_type, char *datname1, char *datname2, int verbose, int caesar)
{
	struct dat dat1, dat2;
	struct game_change *game_changes;
	struct rom_change *rom_changes;
	struct game *games1, *games2;
	struct game_idx *idx;
	
	int num_game_changes=0;
	int i=0, j=0;
	int namediff;
	int errflg;

	FILE *out=0;
	FILE *new=0;
	FILE *grep=0;

	errflg=init_dat(&dat1, datname1);
	errflg+=init_dat(&dat2, datname2);

	if (!(game_changes=calloc(MAX_GAMES, sizeof(struct game_change))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!(rom_changes=calloc(MAX_ROMS, sizeof(struct rom_change))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!errflg)
		errflg=load_mame_listinfo(&dat1);

	if (!errflg)
		fix_merge_info(&dat1);

	if (!errflg)
		errflg=load_mame_listinfo(&dat2);

	if (!errflg)
		fix_merge_info(&dat2);

	if (!errflg && !(out=fopen("mamediff.log", "w")))
	{
		printf("Error opening mamediff.log for writing\n");
		errflg=1;
	}

	if (!errflg && caesar && !(new=fopen("new.dat", "w")))
	{
		printf("Error opening new.dat for writing\n");
		errflg=1;
	}

	if (!errflg && caesar && !(grep=fopen("mapcheck.bat", "w")))
	{
		printf("Error opening mapcheck.bat for writing\n");
		errflg=1;
	}

	if (!errflg)
	{
		game_changes->rom_changes=rom_changes;

		games1=dat1.games; games2=dat2.games;

		while (i<dat1.num_games || j<dat2.num_games)
		{
			if (i>=dat1.num_games) namediff=1;
			if (j>=dat2.num_games) namediff=-1;
			if (i<dat1.num_games && j<dat2.num_games)
				namediff=strcmp(games1[i].name, games2[j].name);

			if (namediff==0)
			{
				if (games1[i].crc != games2[j].crc)
				{
					idx=bsearch(&games1[i].crc, dat2.games_idx, dat2.num_games, sizeof(struct game_idx), idx_sort_function);

					if (idx)
					{
						COMPARE_GAMES(&games1[i], idx->game)
						i++;
					}
					else
					{
						COMPARE_GAMES(&games1[i], &games2[j])
						i++; j++;
					}
				}
				else
				{
					COMPARE_GAMES(&games1[i], &games2[j])
					i++; j++;
				}
			}

			if (namediff<0)
			{
				if (games1[i].num_roms)
					idx=bsearch(&games1[i].crc, dat2.games_idx, dat2.num_games, sizeof(struct game_idx), idx_sort_function);
				else
					idx=0;

				if (idx)
					COMPARE_GAMES(&games1[i], idx->game)
				else
					COMPARE_GAMES(&games1[i], 0)
				i++;
			}

			if (namediff>0)
				j++;
		}

		for (i=0; i<dat2.num_games; i++)
		{
			if (!(games2[i].flags & PROCESSED))
				COMPARE_GAMES(0, &games2[i])
		}

		for (i=j=0; caesar && i<num_game_changes; i++)
		{
			if (game_changes[i].flags & GAME_ADDED)
			{
				while (strcmp(games2[j].name, game_changes[i].game2->name))
					j++;
				print_game(new, &dat2, &games2[j], MERGED_ZIPS);
			}
		}

		for (i=j=0; caesar && i<num_game_changes; i++)
		{
			if ((game_changes[i].flags & GAME_RENAMED) ||
				(game_changes[i].flags & GAME_REMOVED))
			{
				while (strcmp(games1[j].name, game_changes[i].game1->name))
					j++;
				fprintf(grep, "grep \"%s,m$\" */*.map\n", games1[j].name);
			}
		}

		if (set_type==NO_SET_TYPE)
		{
			report_game_changes(out,
				GAME_REMOVED,
				"Game removals",
				0, 0, game_changes, num_game_changes, verbose);

			report_game_changes(out,
				GAME_NEW_CLONE|GAME_RENAMED|
				ROMS_RENAMED|ROMS_MERGED|ROMS_UNMERGED|ROMS_REMOVED|
				P_ROMS_RENAMED|P_ROMS_REMOVED|
				ROMS_COMP_CRC|P_ROMS_COMP_CRC,
				"Games affected by set reorganisation",
				0, 0, game_changes, num_game_changes, verbose);

			report_game_changes(out,
				ROMS_ADDED|P_ROMS_ADDED,
				"Games requiring additional ROMs",
				dat1.roms_idx, dat1.num_roms, game_changes, num_game_changes, verbose);

			report_game_changes(out,
				GAME_ADDED,
				"Game additions",
				0, 0, game_changes, num_game_changes, verbose);
		}
	
		if (set_type==MERGED_SETS)
		{
			report_required_rebuilds(out, 0,
				GAME_NEW_CLONE|GAME_REMOVED|
				ROMS_RENAMED|ROMS_REMOVED,
				"Merged set changes (just rebuild the ZIPs)",
				game_changes, num_game_changes);
		}

		if (set_type==SPLIT_SETS)
		{
			report_required_rebuilds(out, 
				GAME_RENAMED|GAME_REMOVED|
				ROMS_RENAMED|ROMS_MERGED|ROMS_REMOVED, ROMS_UNMERGED,
				"Split set changes (just rebuild the ZIPs)",
				game_changes, num_game_changes);
		}

		if (set_type==NON_MERGED_SETS)
		{
			report_required_rebuilds(out,
				GAME_RENAMED|GAME_REMOVED|
				ROMS_RENAMED|ROMS_REMOVED|
				P_ROMS_RENAMED|P_ROMS_REMOVED, 0,
				"Non-merged set changes (just rebuild the ZIPs)",
				game_changes, num_game_changes);
		}

		if (set_type!=NO_SET_TYPE)
		{
			report_required_roms(out, ROMS_ADDED|P_ROMS_ADDED,
				"Games requiring new/fixed ROMs (visit SYS2064!)",
				game_changes, num_game_changes);

			report_required_roms(out, GAME_ADDED,
				"Game additions (new ROMs required)",
				game_changes, num_game_changes);
		}

		if (num_game_changes)
			printf("\nReport has been written to mamediff.log\n");
		else
			printf("\nNo differences found\n");
	}

	if (grep) fclose(grep);
	if (new) fclose(new);
	if (out) fclose(out);

	release_dat(&dat2);
	release_dat(&dat1);

	if (rom_changes)
		free(rom_changes);
	if (game_changes)
		free(game_changes);

	return(errflg);
}

int zip_compare(int set_type, char *datname1, char *datname2)
{
	struct dat dat1, dat2;
	struct zip_entry *zip_entries1=0, *zip_entries2=0;
	struct zip_change *zip_changes;

	struct game *the_game;

	int i, j, k, l, found;
	int num_zip_changes=0;
	int num_zip_ents1=0, num_zip_ents2=0;
	int namediff;
	int errflg;

	unsigned long crc, crc1, crc2;
	FILE *out=0;
	FILE *new=0;

	int need_neogeo=0, need_pgm=0, need_cvs=0, need_decocass=0, need_playch10=0, need_skns=0, need_stvbios=0, need_konamigx=0;

	errflg=init_dat(&dat1, datname1);
	errflg+=init_dat(&dat2, datname2);

	if (!(zip_entries1=calloc(MAX_ROMS, sizeof(struct zip_entry))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!(zip_entries2=calloc(MAX_ROMS, sizeof(struct zip_entry))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!(zip_changes=calloc(MAX_GAMES*2, sizeof(struct zip_change))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!errflg)
		errflg=load_mame_listinfo(&dat1);

	if (!errflg)
		fix_merge_info(&dat1);

	if (!errflg)
		errflg=load_mame_listinfo(&dat2);

	if (!errflg)
		fix_merge_info(&dat2);

	if (!errflg && !(out=fopen("mamediff.log", "w")))
	{
		printf("Error opening mamediff.log for writing\n");
		errflg=1;
	}

	if (!errflg && !(new=fopen("mamediff.dat", "w")))
	{
		printf("Error opening new.dat for writing\n");
		errflg=1;
	}

	if (!errflg)
	{
		for (i=0; i<dat1.num_games; i++)
		{
			for (j=0; j<dat1.games[i].num_roms; j++)
			{
				if (set_type==MERGED_ZIPS)
				{
					strcpy(zip_entries1[num_zip_ents1].game_name, dat1.games[i].cloneof);
					strcpy(zip_entries1[num_zip_ents1].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries1[num_zip_ents1].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries1[num_zip_ents1].size, dat1.games[i].first_rom[j].size);
					num_zip_ents1++;
				}
				if (set_type==SPLIT_ZIPS && !dat1.games[i].first_rom[j].merge[0])
				{
					strcpy(zip_entries1[num_zip_ents1].game_name, dat1.games[i].name);
					strcpy(zip_entries1[num_zip_ents1].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries1[num_zip_ents1].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries1[num_zip_ents1].size, dat1.games[i].first_rom[j].size);
					num_zip_ents1++;
				}
				if (set_type==NON_MERGED_ZIPS)
				{
					strcpy(zip_entries1[num_zip_ents1].game_name, dat1.games[i].name);
					strcpy(zip_entries1[num_zip_ents1].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries1[num_zip_ents1].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries1[num_zip_ents1].size, dat1.games[i].first_rom[j].size);
					num_zip_ents1++;
				}
			}
		}
		qsort(zip_entries1, num_zip_ents1, sizeof(struct zip_entry), zip_entry_sort_function);

		for (i=0; i<dat2.num_games; i++)
		{
			for (j=0; j<dat2.games[i].num_roms; j++)
			{
				if (set_type==MERGED_ZIPS)
				{
					strcpy(zip_entries2[num_zip_ents2].game_name, dat2.games[i].cloneof);
					strcpy(zip_entries2[num_zip_ents2].rom_name, dat2.games[i].first_rom[j].name);
					strcpy(zip_entries2[num_zip_ents2].crc, dat2.games[i].first_rom[j].crc);
					strcpy(zip_entries2[num_zip_ents2].size, dat2.games[i].first_rom[j].size);
					num_zip_ents2++;
				}
				if (set_type==SPLIT_ZIPS && !dat2.games[i].first_rom[j].merge[0])
				{
					strcpy(zip_entries2[num_zip_ents2].game_name, dat2.games[i].name);
					strcpy(zip_entries2[num_zip_ents2].rom_name, dat2.games[i].first_rom[j].name);
					strcpy(zip_entries2[num_zip_ents2].crc, dat2.games[i].first_rom[j].crc);
					strcpy(zip_entries2[num_zip_ents2].size, dat2.games[i].first_rom[j].size);
					num_zip_ents2++;
				}
				if (set_type==NON_MERGED_ZIPS)
				{
					strcpy(zip_entries2[num_zip_ents2].game_name, dat2.games[i].name);
					strcpy(zip_entries2[num_zip_ents2].rom_name, dat2.games[i].first_rom[j].name);
					strcpy(zip_entries2[num_zip_ents2].crc, dat2.games[i].first_rom[j].crc);
					strcpy(zip_entries2[num_zip_ents2].size, dat2.games[i].first_rom[j].size);
					num_zip_ents2++;
				}
			}
		}
		qsort(zip_entries2, num_zip_ents2, sizeof(struct zip_entry), zip_entry_sort_function);

		i=j=0;
		while (i<num_zip_ents1 || j<num_zip_ents2)
		{
			if (i>=num_zip_ents1) namediff=1;
			if (j>=num_zip_ents2) namediff=-1;
			if (i<num_zip_ents1 && j<num_zip_ents2)
				namediff=strcmp(zip_entries1[i].game_name, zip_entries2[j].game_name);

			if (namediff==0)
			{
				k=i;
				while (!strcmp(zip_entries1[i].game_name, zip_entries1[k].game_name) ||
					!strcmp(zip_entries2[j].game_name, zip_entries1[k].game_name))
				{
					if (i>=num_zip_ents1) namediff=1;
					if (j>=num_zip_ents2) namediff=-1;
					if (i<num_zip_ents1 && j<num_zip_ents2)
					{
						namediff=strcmp(zip_entries1[i].game_name, zip_entries2[j].game_name);
						if (!namediff)
							namediff=strcmp(zip_entries1[i].rom_name, zip_entries2[j].rom_name);
					}

					if (namediff==0)
					{
						l=i; crc1=0;
						while (i<num_zip_ents1 && !strcmp(zip_entries1[i].game_name, zip_entries1[l].game_name) &&
							!strcmp(zip_entries1[i].rom_name, zip_entries1[l].rom_name))
						{
							crc=strtoul(zip_entries1[i].crc, NULL, 16);
							if (!crc1)
								crc1=crc;
							if (crc && crc1 && crc!=crc1 && crc!=~crc1)
								printf("Warning: MAME CRC conflict for %s in %s (%08lx and %08lx)\n", zip_entries1[i].rom_name, zip_entries1[i].game_name, crc, crc1);
							i++;
						}
						sprintf(zip_entries1[l].crc, "%08lx", crc1);
						
						l=j; crc2=0;
						while (j<num_zip_ents2 && !strcmp(zip_entries2[j].game_name, zip_entries2[l].game_name) &&
							!strcmp(zip_entries2[j].rom_name, zip_entries2[l].rom_name))
						{
							crc=strtoul(zip_entries2[j].crc, NULL, 16);
							if (!crc2)
								crc2=crc;
							if (crc && crc2 && crc!=crc2 && crc!=~crc2)
								printf("Warning: MAME CRC conflict for %s in %s (%08lx and %08lx)\n", zip_entries2[j].rom_name, zip_entries2[j].game_name, crc, crc2);
							j++;
						}
						sprintf(zip_entries2[l].crc, "%08lx", crc2);

						if (crc1!=crc2 && crc1!=~crc2)
						{
							strcpy(zip_changes[num_zip_changes].name, zip_entries2[l].game_name);
							zip_changes[num_zip_changes].flags|=ROMS_CHANGED;

							while (i<num_zip_ents1 && !strcmp(zip_entries1[i].game_name, zip_entries1[k].game_name)) {i++;}
							while (j<num_zip_ents2 && !strcmp(zip_entries2[j].game_name, zip_entries1[k].game_name)) {j++;}

							num_zip_changes++;
						}
					}
					else if (namediff<0)
					{
						strcpy(zip_changes[num_zip_changes].name, zip_entries1[k].game_name);
						zip_changes[num_zip_changes].flags|=ROMS_REMOVED;

						while (i<num_zip_ents1 && !strcmp(zip_entries1[i].game_name, zip_entries1[k].game_name)) {i++;}
						while (j<num_zip_ents2 && !strcmp(zip_entries2[j].game_name, zip_entries1[k].game_name)) {j++;}
		
						num_zip_changes++;
					}
					else if (namediff>0)
					{
						strcpy(zip_changes[num_zip_changes].name, zip_entries1[k].game_name);
						zip_changes[num_zip_changes].flags|=ROMS_ADDED;

						while (i<num_zip_ents1 && !strcmp(zip_entries1[i].game_name, zip_changes[num_zip_changes].name)) {i++;}
						while (j<num_zip_ents2 && !strcmp(zip_entries2[j].game_name, zip_changes[num_zip_changes].name)) {j++;}
		
						num_zip_changes++;
					}
				}
			}
			else if (namediff<0)
			{
				strcpy(zip_changes[num_zip_changes].name, zip_entries1[i].game_name);
				zip_changes[num_zip_changes].flags|=GAME_REMOVED;

				while (i<num_zip_ents1 && !strcmp(zip_entries1[i].game_name, zip_changes[num_zip_changes].name))
					i++;

				num_zip_changes++;
			}
			else if (namediff>0)
			{
				strcpy(zip_changes[num_zip_changes].name, zip_entries2[j].game_name);
				zip_changes[num_zip_changes].flags|=GAME_ADDED;

				while (j<num_zip_ents2 && !strcmp(zip_entries2[j].game_name, zip_changes[num_zip_changes].name))
					j++;

				num_zip_changes++;
			}
		}

		if (num_zip_changes)
		{
			output_title(out, "ZIPs Removed");
			for (j=i=0; i<num_zip_changes; i++)
			{
				if (zip_changes[i].flags & GAME_REMOVED)
				{
					the_game=bsearch(zip_changes[i].name, dat1.games, dat1.num_games, sizeof(struct game), game_sort_function);
					fprintf(out, "%8s.zip - %s\n", zip_changes[i].name, the_game->title);
					j++;
				}
			}
			if (!j) fprintf(out, "No ZIPs removed.\n");
			fprintf(out, "\n");

			output_title(out, "ZIPs Changed");
			for (j=i=0; i<num_zip_changes; i++)
			{
				if (zip_changes[i].flags & (ROMS_ADDED|ROMS_CHANGED|ROMS_REMOVED))
				{
					the_game=bsearch(zip_changes[i].name, dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
					fprintf(out, "%8s.zip - %s\n", zip_changes[i].name, the_game->title);

					if (!strcmp(the_game->romof, "neogeo"))
						need_neogeo++;
					if (!strcmp(the_game->romof, "pgm"))
						need_pgm++;
					if (!strcmp(the_game->romof, "cvs"))
						need_cvs++;
					if (!strcmp(the_game->romof, "playch10"))
						need_playch10++;
					if (!strcmp(the_game->romof, "decocass"))
						need_decocass++;
					if (!strcmp(the_game->romof, "skns"))
						need_skns++;
					if (!strcmp(the_game->romof, "stvbios"))
						need_stvbios++;
					if (!strcmp(the_game->romof, "konamigx"))
						need_konamigx++;

					j++;
				}
			}
			if (!j) fprintf(out, "No ZIPs changed.\n");
			fprintf(out, "\n");

			output_title(out, "ZIPs Added");
			for (j=i=0; i<num_zip_changes; i++)
			{
				if (zip_changes[i].flags & GAME_ADDED)
				{
					the_game=bsearch(zip_changes[i].name, dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
					fprintf(out, "%8s.zip - %s\n", zip_changes[i].name, the_game->title);

					if (!strcmp(the_game->romof, "neogeo"))
						need_neogeo++;
					if (!strcmp(the_game->romof, "pgm"))
						need_pgm++;
					if (!strcmp(the_game->romof, "cvs"))
						need_cvs++;
					if (!strcmp(the_game->romof, "playch10"))
						need_playch10++;
					if (!strcmp(the_game->romof, "decocass"))
						need_decocass++;
					if (!strcmp(the_game->romof, "skns"))
						need_skns++;
					if (!strcmp(the_game->romof, "stvbios"))
						need_stvbios++;
					if (!strcmp(the_game->romof, "konamigx"))
						need_konamigx++;

					j++;
				}
			}
			if (!j) fprintf(out, "No ZIPs added.\n");
			fprintf(out, "\n");

			for (j=i=0; i<dat2.num_games; i++)
			{
				while (j<num_zip_changes && zip_changes[j].flags==GAME_REMOVED)
					j++;

				if (set_type==MERGED_ZIPS)
				{
					for (found=k=0; k<num_zip_changes; k++)
					{
						if (!strcmp(dat2.games[i].cloneof, zip_changes[k].name))
							found++;
					}
					if (found && !(dat2.games[i].flags & RESOURCE))
					{
						print_game(new, &dat2, &dat2.games[i], set_type);
					}
				}

				if (set_type!=MERGED_ZIPS && j<num_zip_changes && !strcmp(dat2.games[i].name, zip_changes[j].name))
				{
					for (found=k=0; k<num_zip_changes; k++)
					{
						if (!strcmp(dat2.games[i].cloneof, zip_changes[k].name))
							found++;
					}
					if (!found)
					{
						/*if (!strcmp(dat2.games[i].cloneof, dat2.games[i].romof))
							dat2.games[i].romof[0]='\0';*/

						the_game=bsearch(dat2.games[i].cloneof, dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);

						if (!strcmp(the_game->romof, "neogeo"))
							need_neogeo++;
						if (!strcmp(the_game->romof, "pgm"))
							need_pgm++;
						if (!strcmp(the_game->romof, "cvs"))
							need_cvs++;
						if (!strcmp(the_game->romof, "playch10"))
							need_playch10++;
						if (!strcmp(the_game->romof, "decocass"))
							need_decocass++;
						if (!strcmp(the_game->romof, "skns"))
							need_skns++;
						if (!strcmp(the_game->romof, "stvbios"))
							need_stvbios++;
						if (!strcmp(the_game->romof, "konamigx"))
							need_konamigx++;

						strcpy(dat2.games[i].romof, the_game->romof);
						dat2.games[i].cloneof[0]='\0';
					}

					if (!(dat2.games[i].flags & RESOURCE))
						print_game(new, &dat2, &dat2.games[i], set_type);

					j++;
				}
			}

			printf("\nReport has been written to mamediff.log and dat saved as mamediff.dat\n");
		}
		else
		{
			printf("\nNo differences found.\n");
		}
	}

	if (need_neogeo)
	{
		the_game=bsearch("neogeo", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_pgm)
	{
		the_game=bsearch("pgm", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_cvs)
	{
		the_game=bsearch("cvs", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_decocass)
	{
		the_game=bsearch("decocass", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_playch10)
	{
		the_game=bsearch("playch10", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_skns)
	{
		the_game=bsearch("skns", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_stvbios)
	{
		the_game=bsearch("stvbios", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (need_konamigx)
	{
		the_game=bsearch("konamigx", dat2.games, dat2.num_games, sizeof(struct game), game_sort_function);
		if (the_game)
			print_game(new, &dat2, the_game, set_type);
	}

	if (new) fclose(new);
	if (out) fclose(out);

	release_dat(&dat2);
	release_dat(&dat1);

	if (zip_changes)
		free(zip_changes);
	if (zip_entries2)
		free(zip_entries2);
	if (zip_entries1)
		free(zip_entries1);

	return(errflg);
}

int tiny_compare(int set_type, int crc_support, char *datname1, char *datname2)
{
	struct dat dat1, dat2;
	struct zip_entry *zip_entries=0;
	struct zip_entry *zip_changes=0;

	struct zip_entry *parent_zip, *clone_zip;
	struct zip_entry *curr_zip_entry;
	struct game *curr_game;
	
	int i, j, found, printed_game;
	int num_zip_ents=0;
	int num_zip_changes=0;
	int errflg;

	char st[1024];
	char comp_crc[9];
	unsigned long crc;

	FILE *out=0;
	FILE *new=0;

	errflg=init_dat(&dat1, datname1);
	errflg+=init_dat(&dat2, datname2);

	if (!(zip_entries=calloc(MAX_ROMS, sizeof(struct zip_entry))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!(zip_changes=calloc(MAX_ROMS, sizeof(struct zip_entry))))
	{
		printf("Not enough memory\n");
		errflg++;
	}

	if (!errflg)
		errflg=load_mame_listinfo(&dat1);

	if (!errflg)
		fix_merge_info(&dat1);

	if (!errflg)
		errflg=load_mame_listinfo(&dat2);

	if (!errflg)
		fix_merge_info(&dat2);

	if (!errflg && !(out=fopen("mamediff.log", "w")))
	{
		printf("Error opening mamediff.log for writing\n");
		errflg=1;
	}

	if (!errflg && !(new=fopen("mamediff.dat", "w")))
	{
		printf("Error opening new.dat for writing\n");
		errflg=1;
	}

	if (!errflg)
	{
		strcpy(st, dat2.name);
		if (strstr(st, ".dat")) *strstr(st, ".dat")=0;
		fprintf(out, "Supplementary dat for use with %s\n", st);
		fprintf(out, "Use in addition to a perfect ");
		switch (set_type)
		{
			case NON_MERGED_ZIPS:
				fprintf(out, "non-merged");
				break;
			case SPLIT_ZIPS:
				fprintf(out, "split-merged");
				break;
			case MERGED_ZIPS:
				fprintf(out, "fully-merged");
				break;
		}

		strcpy(st, dat1.name);
		if (strstr(st, ".dat")) *strstr(st, ".dat")=0;
		if (strchr(st, '/')) strcpy(st, strrchr(st, '/')+1);
		if (strchr(st, '\\')) strcpy(st, strrchr(st, '\\')+1);
		fprintf(out, " set for %s\n\n", st);

		for (i=0; i<dat1.num_games; i++)
		{
			for (j=0; j<dat1.games[i].num_roms; j++)
			{
				if (set_type==MERGED_ZIPS)
				{
					strcpy(zip_entries[num_zip_ents].game_name, dat1.games[i].cloneof);
					strcpy(zip_entries[num_zip_ents].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries[num_zip_ents].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries[num_zip_ents].size, dat1.games[i].first_rom[j].size);
					num_zip_ents++;
				}
				if (set_type==SPLIT_ZIPS && !dat1.games[i].first_rom[j].merge[0])
				{
					strcpy(zip_entries[num_zip_ents].game_name, dat1.games[i].name);
					strcpy(zip_entries[num_zip_ents].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries[num_zip_ents].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries[num_zip_ents].size, dat1.games[i].first_rom[j].size);
					num_zip_ents++;
				}
				if (set_type==NON_MERGED_ZIPS)
				{
					strcpy(zip_entries[num_zip_ents].game_name, dat1.games[i].name);
					strcpy(zip_entries[num_zip_ents].rom_name, dat1.games[i].first_rom[j].name);
					strcpy(zip_entries[num_zip_ents].crc, dat1.games[i].first_rom[j].crc);
					strcpy(zip_entries[num_zip_ents].size, dat1.games[i].first_rom[j].size);
					num_zip_ents++;
				}
			}
		}
		qsort(zip_entries, num_zip_ents, sizeof(struct zip_entry), zip_entry_sort_function);

		for (i=0; i<dat2.num_games; i++)
		{
			printed_game=0;

			if (dat2.merging!=NO_MERGING)
			{
				parent_zip=bsearch(&dat2.games[i].cloneof, zip_entries, num_zip_ents, sizeof(struct zip_entry), zip_entry_search_function);
				while (parent_zip!=0 && parent_zip>zip_entries && !strcmp(parent_zip->game_name, parent_zip[-1].game_name))
					parent_zip--;
			}
			else
				parent_zip=0;

			if (dat2.merging!=FULL_MERGING)
			{
				clone_zip=bsearch(&dat2.games[i].name, zip_entries, num_zip_ents, sizeof(struct zip_entry), zip_entry_search_function);
				while (clone_zip!=0 && clone_zip>zip_entries && !strcmp(clone_zip->game_name, clone_zip[-1].game_name))
					clone_zip--;
			}
			else
				clone_zip=0;

			for (j=0; j<dat2.games[i].num_roms; j++)
			{
				found=0;
				crc=strtoul(dat2.games[i].first_rom[j].crc, NULL, 16);
				sprintf(comp_crc, "%08lx", ~crc);

				// Resource ROMs should be descarded from games, but not the resource

        			if (dat2.games[i].romof[0] && is_resource_rom(&dat2, &dat2.games[i].first_rom[j]))
					found++;

				if (clone_zip && !(dat2.merging==SPLIT_MERGING && dat2.games[i].first_rom[j].merge[0]!=0))
				{
					curr_zip_entry=clone_zip;
					while (!found && !strcmp(curr_zip_entry->game_name, dat2.games[i].name))
					{
						if ((((crc_support==1 && crc!=0) || !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->crc, dat2.games[i].first_rom[j].crc) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)) ||
							(((crc_support==1 && crc!=0) || !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->crc, comp_crc) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)) ||
							((crc==0 && !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)))
						{
							found++;
						}
						curr_zip_entry++;
					}
				}

				if (parent_zip && !(dat2.merging==SPLIT_MERGING && dat2.games[i].first_rom[j].merge[0]==0))
				{
					curr_zip_entry=parent_zip;
					while (!found && !strcmp(curr_zip_entry->game_name, dat2.games[i].cloneof))
					{
						if ((((crc_support==1 && crc!=0) || !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->crc, dat2.games[i].first_rom[j].crc) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)) ||
							(((crc_support==1 && crc!=0) || !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->crc, comp_crc) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)) ||
							((crc==0 && !strcmp(curr_zip_entry->rom_name, dat2.games[i].first_rom[j].name)) &&
								!strcmp(curr_zip_entry->size, dat2.games[i].first_rom[j].size)))
						{
							found++;
						}
						curr_zip_entry++;
					}
				}

				if (!found)
				{
					if (!printed_game)
					{
						curr_game=&dat2.games[i];
						FORMAT_GAME_NAME(st, curr_game);
						fprintf(out, "%s\n\n", st);
						printed_game++;
					}

					if (dat2.merging==NO_MERGING)
						strcpy(zip_changes[num_zip_changes].game_name, dat2.games[i].name);
					if (dat2.merging==FULL_MERGING)
						strcpy(zip_changes[num_zip_changes].game_name, dat2.games[i].cloneof);
					if (dat2.merging==SPLIT_MERGING || dat2.merging==ANY_MERGING)
					{
						if (dat2.games[i].first_rom[j].merge[0]==0)
							strcpy(zip_changes[num_zip_changes].game_name, dat2.games[i].name);
						else
							strcpy(zip_changes[num_zip_changes].game_name, dat2.games[i].cloneof);
					}
					strcpy(zip_changes[num_zip_changes].rom_name, dat2.games[i].first_rom[j].name);
					strcpy(zip_changes[num_zip_changes].crc, dat2.games[i].first_rom[j].crc);
					strcpy(zip_changes[num_zip_changes].size, dat2.games[i].first_rom[j].size);
					num_zip_changes++;

					fprintf(out, "  ROM: %12s (%7s bytes, crc %s)\n", dat2.games[i].first_rom[j].name, dat2.games[i].first_rom[j].size, dat2.games[i].first_rom[j].crc);
				}
			}

			if (printed_game)
				fprintf(out, "\n");
		}

		if (num_zip_changes)
		{
			qsort(zip_changes, num_zip_changes, sizeof(struct zip_entry), zip_entry_sort_function);
			for (i=0; i<num_zip_changes; i++)
			{
				if (i==0 || strcmp(zip_changes[i].game_name, zip_changes[i-1].game_name))
				{
					curr_game=bsearch(&zip_changes[i].game_name, dat2.games, dat2.num_games, sizeof(struct game), game_search_function);
	
					fprintf(new, "game (\n");
					fprintf(new, "\tname %s\n", zip_changes[i].game_name);
					fprintf(new, "\tdescription \"%s\"\n", curr_game->title);
					if (curr_game->year[0])
						fprintf(new, "\tyear %s\n", curr_game->year);
					if (curr_game->manufacturer[0])
						fprintf(new, "\tmanufacturer \"%s\"\n", curr_game->manufacturer);
				}

				if (i==0 || strcmp(zip_changes[i].game_name, zip_changes[i-1].game_name) ||
					strcmp(zip_changes[i].rom_name, zip_changes[i-1].rom_name))
				{
					if (strchr(zip_changes[i].rom_name, ' '))
						fprintf(new, "\trom ( name \"%s\" size %s crc %s )\n",
							zip_changes[i].rom_name, zip_changes[i].size, zip_changes[i].crc);
					else
						fprintf(new, "\trom ( name %s size %s crc %s )\n",
							zip_changes[i].rom_name, zip_changes[i].size, zip_changes[i].crc);
				}

				if (i+1==num_zip_changes || strcmp(zip_changes[i].game_name, zip_changes[i+1].game_name))
				{
					fprintf(new, ")\n\n");
				}
			}
			printf("\nReport has been written to mamediff.log and dat saved as mamediff.dat\n");
		}
		else
		{
			printf("\nNo differences found.\n");
			fprintf(out, "No supplement required\n");
		}
	}

	if (new) fclose(new);
	if (out) fclose(out);

	release_dat(&dat2);
	release_dat(&dat1);

	if (zip_changes)
		free(zip_changes);
	if (zip_entries)
		free(zip_entries);

	return(errflg);
}

int is_resource_rom(struct dat *dat_info, struct rom *curr_rom)
{
	int i;
	int retval=0;

	for (i=0; i<dat_info->num_resource_roms; i++)
	{
		if (!strcmp(dat_info->resource_roms[i].crc, curr_rom->crc))
			retval=1;
	}

	return(retval);
}

void print_game(FILE *new, struct dat *dat, struct game *game, int set_type)
{
	int i;

	if (game->flags & RESOURCE)
	{
		fprintf(new, "resource (\n");
		fprintf(new, "\tname %s\n", game->name);
		fprintf(new, "\tdescription \"%s\"\n", game->title);
	}
	else
	{
		fprintf(new, "game (\n");
		fprintf(new, "\tname %s\n", game->name);
		fprintf(new, "\tdescription \"%s\"\n", game->title);
		if (game->year[0])
			fprintf(new, "\tyear %s\n", game->year);
		fprintf(new, "\tmanufacturer \"%s\"\n", game->manufacturer);
	}

	if (game->cloneof[0] && strcmp(game->cloneof, game->name))
		fprintf(new, "\tcloneof %s\n", game->cloneof);

	if (game->romof[0])
		fprintf(new, "\tromof %s\n", game->romof);

	for (i=0; i<game->num_roms; i++)
	{
		if (set_type==SPLIT_ZIPS)
		{
			if ((game->cloneof[0] && game->first_rom[i].merge[0]) || (game->romof[0] && is_resource_rom(dat, &game->first_rom[i])))
				fprintf(new, "\trom ( name %s merge %s size %s crc %s )\n", game->first_rom[i].name, game->first_rom[i].merge, game->first_rom[i].size, game->first_rom[i].crc);
			else if (!game->first_rom[i].merge[0])
				fprintf(new, "\trom ( name %s size %s crc %s )\n", game->first_rom[i].name, game->first_rom[i].size, game->first_rom[i].crc);
		}
		else
		{
			if ((game->cloneof[0] && game->first_rom[i].merge[0]) || (game->romof[0] && is_resource_rom(dat, &game->first_rom[i])))
				fprintf(new, "\trom ( name %s merge %s size %s crc %s )\n", game->first_rom[i].name, game->first_rom[i].merge, game->first_rom[i].size, game->first_rom[i].crc);
			else
				fprintf(new, "\trom ( name %s size %s crc %s )\n", game->first_rom[i].name, game->first_rom[i].size, game->first_rom[i].crc);
		}
	}

	fprintf(new, ")\n\n");
}

void output_title(FILE *out, char *title)
{
	int i, j;

	i=(79-strlen(title))/2;
	j=79-strlen(title)-i;

	for (; i>1; i--) fprintf(out, "-");
	fprintf(out, " %s ", title);
	for (; j>1; j--) fprintf(out, "-");
	fprintf(out, "\n\n");
}

void report_game_changes(FILE *out, unsigned long flags, char *title,
	struct rom_idx *roms_idx, long num_roms,
	struct game_change *game_changes, int num_game_changes, int verbose)
{
	int i, j, k;
	char st[80];
	struct rom_idx rom_to_find;

	for (i=j=0; i<num_game_changes; i++)
	{
		if (game_changes[i].flags & (flags))
		{	
			if (!j++)
			{
				output_title(out, title);
			}

#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].flags);
#endif /*DEBUG */

			if ((game_changes[i].flags & GAME_RENAMED) ||
				(game_changes[i].flags & GAME_NEW_CLONE) ||
				(game_changes[i].flags & GAME_REMOVED))
			{
				FORMAT_GAME_NAME(st, game_changes[i].game1)
				fprintf(out, "< %s\n", st);
			}
			else if (!(game_changes[i].flags & GAME_ADDED))
			{
				FORMAT_GAME_NAME(st, game_changes[i].game1)
				fprintf(out, "%s\n", st);
			}

			if ((game_changes[i].flags & GAME_RENAMED) ||
				(game_changes[i].flags & GAME_NEW_CLONE) ||
				(game_changes[i].flags & GAME_ADDED))
			{
#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].flags);
#endif /*DEBUG */
				FORMAT_GAME_NAME(st, game_changes[i].game2)
				fprintf(out, "> %s\n", st);
			}

			for (k=0; verbose && k<game_changes[i].num_rom_changes; k++)
			{
				if (((game_changes[i].rom_changes[k].flags & ROMS_RENAMED) ||
					(game_changes[i].rom_changes[k].flags & P_ROMS_RENAMED) ||
					(game_changes[i].rom_changes[k].flags & ROMS_COMP_CRC) ||
					(game_changes[i].rom_changes[k].flags & P_ROMS_COMP_CRC) ||
					(game_changes[i].rom_changes[k].flags & ROMS_REMOVED) ||
					(game_changes[i].rom_changes[k].flags & P_ROMS_REMOVED) ||
					(game_changes[i].rom_changes[k].flags & ROMS_MERGED) ||
					(game_changes[i].rom_changes[k].flags & ROMS_UNMERGED)) &&
					!(flags & ROMS_ADDED))
				{
#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].rom_changes[k].flags);
#endif /*DEBUG */
					FORMAT_ROM_NAME(st, game_changes[i].rom_changes[k].rom1)
					fprintf(out, "< %s\n", st);
				}

				if (((game_changes[i].rom_changes[k].flags & ROMS_RENAMED) ||
					(game_changes[i].rom_changes[k].flags & P_ROMS_RENAMED) ||
					(game_changes[i].rom_changes[k].flags & ROMS_COMP_CRC) ||
					(game_changes[i].rom_changes[k].flags & P_ROMS_COMP_CRC) ||
					(game_changes[i].rom_changes[k].flags & ROMS_MERGED) ||
					(game_changes[i].rom_changes[k].flags & ROMS_UNMERGED)) &&
					!(flags & ROMS_ADDED))
				{
#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].rom_changes[k].flags);
#endif /*DEBUG */
					FORMAT_ROM_NAME(st, game_changes[i].rom_changes[k].rom2)
					fprintf(out, "> %s\n", st);
				}

				if (((game_changes[i].rom_changes[k].flags & ROMS_ADDED) &&
					(flags & ROMS_ADDED)) ||
					((game_changes[i].rom_changes[k].flags & P_ROMS_ADDED) &&
					(flags & P_ROMS_ADDED)))
				{
#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].rom_changes[k].flags);
#endif /*DEBUG */
					FORMAT_ROM_NAME(st, game_changes[i].rom_changes[k].rom2)
					fprintf(out, "> %s", st);

					rom_to_find.rom=game_changes[i].rom_changes[k].rom2;
					rom_to_find.game=game_changes[i].game2;

					if (!strcmp(game_changes[i].rom_changes[k].rom2->crc, "00000000"))
						fprintf(out, " *just ignore\n");
					else if (bsearch(&rom_to_find, roms_idx, num_roms, sizeof(struct rom_idx), rom_idx_find_function_1))
						fprintf(out, " *already in MAME\n");
					else if (bsearch(&rom_to_find, roms_idx, num_roms, sizeof(struct rom_idx), rom_idx_find_function_2))
						fprintf(out, " *already in MAME\n");
					else
						fprintf(out, "\n");
				}
			}

			if (!verbose && (flags & game_changes[i].flags &
				(ROMS_RENAMED|P_ROMS_RENAMED|
				ROMS_REMOVED|P_ROMS_REMOVED|
				ROMS_COMP_CRC|P_ROMS_COMP_CRC|
				ROMS_ADDED|P_ROMS_ADDED|
				ROMS_MERGED|ROMS_UNMERGED)))
			{
				k=0;
				fprintf(out, "Changes: ");
				
				if (flags & game_changes[i].flags & ROMS_RENAMED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM renames");
				}

				if (flags & game_changes[i].flags & P_ROMS_RENAMED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM renames (in parent)");
				}

				if (flags & game_changes[i].flags & ROMS_COMP_CRC)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "complemented CRCs");
				}

				if (flags & game_changes[i].flags & P_ROMS_COMP_CRC)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "complemented CRCs (in parent)");
				}

				if (flags & game_changes[i].flags & ROMS_REMOVED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM removals");
				}

				if (flags & game_changes[i].flags & P_ROMS_REMOVED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM removals (in parent)");
				}

				if (flags & game_changes[i].flags & ROMS_ADDED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM additions");
				}

				if (flags & game_changes[i].flags & P_ROMS_ADDED)
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM additions (in parent)");
				}

				if (flags & game_changes[i].flags & (ROMS_MERGED|ROMS_UNMERGED))
				{
					if (k++)
						fprintf(out, ", ");
					fprintf(out, "ROM merge details");
				}

				fprintf(out, "\n");
			}

			if (!(game_changes[i].flags & (GAME_REMOVED|GAME_ADDED)))
				fprintf(out, "\n");
		}
	}

	if (j && (flags & (GAME_REMOVED|GAME_ADDED)))
		fprintf(out, "\n");
}

void report_required_roms(FILE *out, unsigned long flags, char *title,
	struct game_change *game_changes, int num_game_changes)
{
	int i, j;
	char st[80];

	for (i=j=0; i<num_game_changes; i++)
	{
		if (game_changes[i].flags & (flags))
		{	
			if (!j++)
			{
				output_title(out, title);
			}

#ifdef DEBUG
	fprintf(out, "%04lx ", game_changes[i].flags);
#endif /*DEBUG */

			FORMAT_GAME_NAME(st, game_changes[i].game2)

			fprintf(out, "%s\n", st);
		}
	}
	if (j) fprintf(out, "\n");
}

void report_required_rebuilds(FILE *out, int child_flags, int parent_flags, char *title,
	struct game_change *game_changes, int num_game_changes)
{
	struct game_change_text rebuild_text[MAX_GAMES];
	int num_rebuilds=0;
	int i, j, found;

	for (i=0; i<num_game_changes; i++)
	{
		if (game_changes[i].flags & (child_flags))
		{
			found=j=0;
			while (!found && j<num_rebuilds)
			{
				if (!strcmp(rebuild_text[j].name, game_changes[i].game1->name))
					found++;
				j++;
			}
			if (!found)
			{
				strcpy(rebuild_text[num_rebuilds].name, game_changes[i].game1->name);
				strcpy(rebuild_text[num_rebuilds++].title, game_changes[i].game1->title);
			}
		}
	}

	for (i=0; i<num_game_changes; i++)
	{
		if (game_changes[i].flags & (parent_flags))
		{
			found=j=0;
			while (!found && j<num_rebuilds)
			{
				if (!strcmp(rebuild_text[j].name, game_changes[i].game1->cloneof))
					found++;
				j++;
			}
			if (!found)
			{
				strcpy(rebuild_text[num_rebuilds].name, game_changes[i].game1->cloneof);
				strcpy(rebuild_text[num_rebuilds++].title, game_changes[i].game1->parent_title);
			}
		}
	}

	if (num_rebuilds)
	{
		qsort(&rebuild_text, num_rebuilds, sizeof(struct game_change_text), rebuild_text_sort_function);
		output_title(out, title);

		for (i=0; i<num_rebuilds; i++)
		{
			rebuild_text[i].title[56]='\0';
			fprintf(out, "%s [rebuild %s.zip]\n", rebuild_text[i].title, rebuild_text[i].name);
		}

		fprintf(out, "\n");
	}
}

int rebuild_text_sort_function(const void *text1, const void *text2)
{
	return(strcmp(text1, text2));
}

/* --------------------------------------------------------------------------
 * Dat initialization - Initialises structure and checks file exists
 * -------------------------------------------------------------------------- */

int init_dat(struct dat *dat_info, char *fn)
{
	FILE *in;

	strcpy(dat_info->name, fn);
	dat_info->merging=ANY_MERGING;
	dat_info->games=0; dat_info->games_idx=0;
	dat_info->roms=0; dat_info->roms_idx=0;

	if (!(in=fopen(dat_info->name, "r")))
	{
		printf("Error opening %s\n", dat_info->name);
		return(1);
	}

	fclose(in);

	return(0);
}

/* --------------------------------------------------------------------------
 * Loads MAME Listinfo into memory
 * -------------------------------------------------------------------------- */

void fix_merge_info(struct dat *dat_info)
{
	struct game *games=dat_info->games;
	int num_games=dat_info->num_games;

	int i, j, k, parent_idx;
	struct rom *rom1, *rom2;
	struct rom *merge;
	int found;

	/* --- Otherwise, unknown parents is treated as a critical error --- */

	for (i=0;i<num_games; i++)
	{
		/* --- If game specifies a parent --- */

		if (strcmp(games[i].cloneof, games[i].name))
		{
			found=0;
 
			/* --- Search backward first (parent is likely to be before clone) --- */

			j=i-1;
			while (!found && j>=0)
			{
				if (!strcmp(games[j].name, games[i].cloneof))
				{
					parent_idx=j;
					found++;
				}

				j--;
			}

			/* --- Search forward if that didn't find it --- */

			j=i+1;
			while (!found && j<num_games)
			{
				if (!strcmp(games[j].name, games[i].cloneof))
				{
					parent_idx=j;
					found++;
				}

				j++;
			}

			if (!found)
			{
				printf("Error: invalid parent for %s\n", games[i].name);
			}
			else
			{
				rom1=games[i].first_rom;
				j=0;
				while (j<games[i].num_roms)
				{
					merge=0; found=0; k=0;
					if (!is_resource_rom(dat_info, rom1))
						rom1->merge[0]='\0';
					rom2=games[parent_idx].first_rom;
					while (k<games[parent_idx].num_roms)
					{
						if (!strcmp(rom1->name, rom2->name))
						{
							if (strcmp(rom1->crc, rom2->crc) &&
								(~strtoul(rom1->crc, NULL, 16) == strtoul(rom2->crc, NULL, 16) ||
								!strcmp("00000000", rom2->crc) || !strcmp(rom1->crc, "00000000")))
							{
								if (!strcmp("00000000", rom1->crc))
									strcpy(rom1->crc, rom2->crc);
								else
									strcpy(rom2->crc, rom1->crc);
							}

							if (!strcmp(rom1->crc, rom2->crc))
								strcpy(rom1->merge, rom1->name);
						}
						k++;
						rom2=&games[parent_idx].first_rom[k];
					}
					j++;
					rom1=&games[i].first_rom[j];
				}
			}
		}
		else
		{
			if ((games[i].flags & RESOURCE)==0)
			{
				rom1=games[i].first_rom;
				j=0;
				while (j<games[i].num_roms)
				{
					if (is_resource_rom(dat_info, rom1))
						strcpy(rom1->merge, rom1->name);
					j++;
					rom1=&games[i].first_rom[j];
				}
			}
		}
	}
}

int load_mame_listinfo(struct dat *dat_info)
{
	FILE *in=0;
	char st[BUFFER_SIZE], token[BUFFER_SIZE];
	char *st_ptr;
	struct game *games; struct game_idx *games_idx;
	struct rom *roms, *resource_roms; struct rom_idx *roms_idx;
	int num_games=0; long num_roms=0; int num_resource_roms=0;
	struct game *parent;
	unsigned long crc;
	int i;
	int in_resource=0;
	int in_header=0;
	int num_resources=0;
	int errflg=0;

	games=dat_info->games=calloc(MAX_GAMES, sizeof(struct game));
	games_idx=dat_info->games_idx=calloc(MAX_GAMES, sizeof(struct game_idx));
	roms=dat_info->roms=calloc(MAX_ROMS, sizeof(struct rom));
	resource_roms=dat_info->resource_roms=calloc(MAX_RESOURCE_ROMS, sizeof(struct rom));
	roms_idx=dat_info->roms_idx=calloc(MAX_ROMS, sizeof(struct rom_idx));

	games[0].first_rom=&roms[0];

#ifdef DEBUG
	printf("Allocated %d bytes\n", MAX_GAMES*sizeof(struct game) + MAX_ROMS*sizeof(struct rom) + MAX_GAMES*sizeof(struct game_idx) + MAX_ROMS*sizeof(struct rom_idx));
#endif /*DEBUG */

	if (!errflg && !(games && games_idx && roms && resource_roms && roms_idx))
	{
		printf("Failed to allocate memory for dat\n");
		errflg++;
	}

	if (!errflg && !(in=fopen(dat_info->name, "r")))
	{
		printf("Error opening %s\n", dat_info->name);
		errflg++;
	}

	if (!errflg)
		printf("Loading %s...", dat_info->name);

	while (!errflg && fgets(st, BUFFER_SIZE, in))
	{
		while (st[strlen(st)-1]==10 || st[strlen(st)-1]==13)
			st[strlen(st)-1]='\0';

		/* Hack to support the MAME v0.68 syntax */

		if (strstr(st, "nodump "))
		{
			strcpy(token, strstr(st, "nodump ")+7);

			sprintf(strstr(st, "nodump "), "crc 00000000 %s", token);
		}

		st_ptr=st;
		GET_TOKEN(token, st_ptr)

		if (!strcmp(token, "resource"))
		{
			num_resources++;
			in_resource++;
		}

		if (!strcmp(token, "clrmamepro") || !strcmp(token, "emulator"))
		{
			in_header++;
		}

		if (in_header && !strcmp(token, "forcemerging"))
		{
			GET_TOKEN(token, st_ptr)
			if (!strcmp(token, "full"))
				dat_info->merging=FULL_MERGING;
			if (!strcmp(token, "split"))
				dat_info->merging=SPLIT_MERGING;
			if (!strcmp(token, "none"))
				dat_info->merging=NO_MERGING;
		}

		if (!strcmp(token, "name"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].name, token, GAME_NAME_LENGTH);
			games[num_games].name[GAME_NAME_LENGTH]='\0';
			strncpy(games[num_games].cloneof, token, GAME_NAME_LENGTH);
			games[num_games].cloneof[GAME_NAME_LENGTH]='\0';
		}

		if (!strcmp(token, "description"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].title, token, TITLE_LENGTH);
			games[num_games].title[TITLE_LENGTH]='\0';
		}

		if (!strcmp(token, "manufacturer"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].manufacturer, token, MANUFACTURER_LENGTH);
			games[num_games].manufacturer[MANUFACTURER_LENGTH]='\0';
		}

		if (!strcmp(token, "year"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].year, token, YEAR_LENGTH);
			games[num_games].year[YEAR_LENGTH]='\0';
		}

		if (!strcmp(token, "cloneof"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].cloneof, token, GAME_NAME_LENGTH);
			games[num_games].cloneof[GAME_NAME_LENGTH]='\0';
		}
		
		if (!strcmp(token, "romof"))
		{
			GET_TOKEN(token, st_ptr)
			strncpy(games[num_games].romof, token, GAME_NAME_LENGTH);
			games[num_games].romof[GAME_NAME_LENGTH]='\0';
		}
		
		if (!strcmp(token, "rom"))
		{
			STORE_ROM(st)
			if (strstr(st, "354029fc"))  /* ng-sfix.rom */
			{
				strcpy(st, "Neo-Geo ");
				strcat(st, games[num_games].title);
				strncpy(games[num_games].title, st, TITLE_LENGTH);
				games[num_games].title[TITLE_LENGTH]='\0';
			}
			//if (in_resource) num_resource_roms++;
		}

		if (token[0]==')')
		{
			if (!in_header)
			{
				/* --- We don't want ROM re-ordering to affect the CRC! --- */
				qsort(games[num_games].first_rom, games[num_games].num_roms, sizeof(struct rom), rom_sort_function);

				/* --- Calculate the CRC of the ROMs (used for indexing) --- */
				crc = CRC32_XINIT;
				st_ptr=(char *)games[num_games].first_rom;
				for (i=0; i<games[num_games].num_roms; i++)
				{
					while (*st_ptr)
						crc = crctable[(crc ^ *st_ptr++) & 0xFFL] ^ (crc >> 8);
					st_ptr+=sizeof(struct rom)-8;
				}
				crc = crc ^ CRC32_XOROT;

				/* --- Cool... we have a CRC to identify the game by! --- */
				games[num_games].crc=crc;

				if (in_resource)
					games[num_games].flags|=RESOURCE;

				num_games++;

				games[num_games].first_rom=&roms[num_roms];
			}

			in_resource=0;
			in_header=0;
		}

		if (num_roms>=MAX_ROMS)
		{
			printf("Maximum number of ROMs exceeded - aborting!\n");
			errflg++;
		}

		if (num_resource_roms>=MAX_RESOURCE_ROMS)
		{
			printf("Maximum number of resource ROMs exceeded - aborting!\n");
			errflg++;
		}

		if (num_games>=MAX_GAMES)
		{
			printf("Maximum number of games exceeded - aborting!\n");
			errflg++;
		}
	}

	if (in) fclose(in);

	if (!errflg)
	{
		dat_info->num_games=num_games;
		dat_info->num_roms=num_roms;
		dat_info->num_resource_roms=num_resource_roms;

		/* --- Sort the games by name --- */
		qsort(games, num_games, sizeof(struct game), game_sort_function);
	
		/* --- Find parent titles --- */
		for (i=0; i<num_games; i++)
		{
			if (strcmp(games[i].name, games[i].cloneof))
			{
				if ((parent=bsearch(&games[i].cloneof, games, num_games, sizeof(struct game), game_sort_function)))
					strcpy(games[i].parent_title, parent->title);
			}
			else
				strcpy(games[i].parent_title, games[i].title);
		}
	
		/* --- Create the index --- */
		for (i=0; i<num_games; i++)
		{
			games_idx[i].crc=games[i].crc;
			games_idx[i].game=&games[i];
		}
	
		/* --- Sort the index so that a binary search can be used later --- */
		qsort(games_idx, num_games, sizeof(struct game_idx), idx_sort_function);

		/* --- Sort the ROM index so that a binary search can be used later --- */
		qsort(roms_idx, num_roms, sizeof(struct rom_idx), rom_idx_sort_function);
	
		/* --- Print summary but don't include Neo-Geo resource --- */
		printf(" %d games (%ld ROMs)\n", dat_info->num_games-num_resources, dat_info->num_roms-num_resource_roms);
	}

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Sorting functions for qsort - not very complicated!
 * -------------------------------------------------------------------------- */

int zip_entry_sort_function(const void *zip_entry1, const void *zip_entry2)
{
	int diff=strcmp(((struct zip_entry *)zip_entry1)->game_name, ((struct zip_entry *)zip_entry2)->game_name);

	if (!diff)
		return(strcmp(((struct zip_entry *)zip_entry1)->rom_name, ((struct zip_entry *)zip_entry2)->rom_name));
	else
		return(diff);
}

int zip_entry_search_function(const void *game_name, const void *zip_entry2)
{
	return(strcmp(game_name, ((struct zip_entry *)zip_entry2)->game_name));
}

int game_search_function(const void *game_name, const void *game)
{
	return(strcmp(game_name, ((struct game *)game)->name));
}

int game_sort_function(const void *game1, const void *game2)
{
	return(strcmp(game1, game2));
}

int idx_sort_function(const void *idx1, const void *idx2)
{
	unsigned long crc1=((struct game_idx *)idx1)->crc;
	unsigned long crc2=((struct game_idx *)idx2)->crc;

	if (crc1<crc2)
		return(-1);
	if (crc1>crc2)
		return(1);
	return(0);
}

int rom_sort_function(const void *rom1, const void *rom2)
{
	int res=strcmp(rom1, rom2);

	if (res)
		return(res);
	else
		return(strcmp(((struct rom *)rom1)->name, ((struct rom *)rom2)->name));
}

int rom_idx_sort_function(const void *text1, const void *text2)
{
	int diff=strcmp(((struct rom_idx *)text1)->rom->crc, ((struct rom_idx *)text2)->rom->crc);

	if (!diff)
		return(strcmp(((struct rom_idx *)text1)->game->cloneof, ((struct rom_idx *)text2)->game->cloneof));
	else
		return(diff);
}

int rom_idx_find_function_1(const void *text1, const void *text2)
{
	int diff=strcmp(((struct rom_idx *)text1)->rom->crc, ((struct rom_idx *)text2)->rom->crc);

	if (!diff)
		return(strcmp(((struct rom_idx *)text1)->game->cloneof, ((struct rom_idx *)text2)->game->cloneof));
	else
		return(diff);
}

int rom_idx_find_function_2(const void *text1, const void *text2)
{
	return(strcmp(((struct rom_idx *)text1)->rom->crc, ((struct rom_idx *)text2)->rom->crc));
}

/* --------------------------------------------------------------------------
 * Function to release dat from memory
 * -------------------------------------------------------------------------- */

int release_dat(struct dat *dat_info)
{
	if (dat_info->roms_idx) free(dat_info->roms_idx);
	if (dat_info->resource_roms) free(dat_info->resource_roms);
	if (dat_info->roms) free(dat_info->roms);
	if (dat_info->games_idx) free(dat_info->games_idx);
	if (dat_info->games) free(dat_info->games);

	return(0);
}


void logerror(char *, ...);

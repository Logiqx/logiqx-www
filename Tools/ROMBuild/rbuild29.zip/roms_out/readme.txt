This is the directory where new ROMs are saved.

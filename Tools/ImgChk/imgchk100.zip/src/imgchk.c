/* --------------------------------------------------------------------------
 * PNGChk - Written by Logiqx (http://www.logiqx.com)
 *
 * A simple little utility for checking resource PNGs
 * -------------------------------------------------------------------------- */

#define PNGCHK_VERSION "v1.00"
#define PNGCHK_DATE "21 January 2003"

/* --- The standard includes --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#include "mame/unzip.h"

#include "imgchk.h"

int main(int argc, char **argv)
{
	struct ini_entry *ini=0;
	struct dat *dat=0;

	char st[BUFFER_SIZE+1];

	int i=1, done=0;
	int errflg=0;

	printf("===============================================================================\n");
	printf("ImgChk %s (%s)\n", PNGCHK_VERSION, PNGCHK_DATE);
	printf("Written by Logiqx (http://www.logiqx.com)\n");
	printf("===============================================================================\n\n");

	/* --- Read INI options --- */

	if (!errflg && !(ini=load_ini("imgchk.ini")))
		errflg++;

	if (!errflg && find_ini_value(ini, "Dat", "Dat"))
	{
		if(!(dat=load_dat(find_ini_value(ini, "Dat", "Dat"))))
			errflg++;
	}
	else
	{
		printf("Error: Dat not declared properly in the INI file!\n");
		errflg++;
	}

	while (!errflg && !done)
	{
		sprintf(st, "Zip%d", i);

		if (find_ini_value(ini, "Zips", st))
			process_section(ini, dat, find_ini_value(ini, "Zips", st));
		else
			done++;

		i++;
	}

	free_dat(dat);
	free_ini(ini);

	return(errflg);
}

int process_section(struct ini_entry *ini, struct dat *dat, char *section)
{
	int report_unknown=0, report_missing=0, allow_clones=1, allow_resources=1;
	char *img_ext=0;

	struct stat buf;

	int i;
	int errflg = 0;

	for (i=0; i<dat->num_games; i++)
		dat->games[i].flags &= ~FLAG_IMAGE;

	if (find_ini_value(ini, section, "ImgExt"))
		img_ext=find_ini_value(ini, section, "ImgExt");

	if (find_ini_value(ini, section, "ReportUnknown"))
		report_unknown=atoi(find_ini_value(ini, section, "ReportUnknown"));

	if (find_ini_value(ini, section, "ReportMissing"))
		report_missing=atoi(find_ini_value(ini, section, "ReportMissing"));

	if (find_ini_value(ini, section, "AllowClones"))
		allow_clones=atoi(find_ini_value(ini, section, "AllowClones"));

	if (find_ini_value(ini, section, "AllowResources"))
		allow_resources=atoi(find_ini_value(ini, section, "AllowResources"));

	if (find_ini_value(ini, section, "ZipFile") && (stat(find_ini_value(ini, section, "ZipFile"), &buf) == 0))
	{
		printf("Testing %s...\n", section);

		check_zip(dat, find_ini_value(ini, section, "ZipFile"), img_ext, report_unknown, report_missing, allow_clones, allow_resources);

		for (i=0; report_missing && i<dat->num_games; i++)
		{
			if (!(dat->games[i].flags & FLAG_IMAGE))
			{
				if ((allow_clones==1 && dat->games[i].flags & FLAG_CLONEOF) ||
					(allow_resources==1 && dat->games[i].flags & FLAG_RESOURCE) ||
					(!(dat->games[i].flags & FLAG_RESOURCE) && !(dat->games[i].flags & FLAG_CLONEOF)))
				printf("   Missing: %s%s\n", dat->games[i].name, img_ext);
			}
		}

		printf("Done!\n\n");
	}

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Read CRCs from ZIP file
 * -------------------------------------------------------------------------- */

int check_zip(struct dat *dat, char *fn, char *img_ext, int report_unknown, int report_missing, int allow_clones, int allow_resources)
{
	ZIP *zip;
	struct zipent *zipent;
	struct game *game;

	char st[BUFFER_SIZE+1];

	int errflg=0;

	if ((zip=openzip(fn)))
	{
		while ((!errflg) && (zipent=readzip(zip)))
		{
			strcpy(st, zipent->name);

			if (strstr(st, img_ext))
				*strstr(st, img_ext)='\0';

			game=bsearch(&st, dat->games, dat->num_games, sizeof(struct game), generic_function);

			if (game==0)
			{
				if (report_unknown)
					printf("   Unknown: %s\n", zipent->name);
			}
			else
			{
				game->flags|=FLAG_IMAGE;

				if (allow_clones==0 && game->flags & FLAG_CLONEOF)
					printf("   Clone: %s\n", zipent->name);

				if (allow_resources==0 && game->flags & FLAG_RESOURCE)
					printf("   Resource: %s\n", zipent->name);
			}
		}
	}

	if (zip)
		closezip(zip);

	return(errflg);
}

/* --------------------------------------------------------------------------
 * Dat scan - Tokenised parser code ripped from CAESAR
 * -------------------------------------------------------------------------- */

struct dat *load_dat(char *fn)
{
	FILE *in;

	char st[BUFFER_SIZE]="";
	char token[BUFFER_SIZE]="";
	char *st_ptr;

	struct dat *dat=0;
	int errflg=0;

	CALLOC(dat, 1, dat)

	if (!errflg)
		CALLOC(dat->games, MAX_GAMES, game)

	if (!errflg)
		FOPEN(in, fn, "r")

	while (!errflg && fgets(st, BUFFER_SIZE, in))
	{
		REMOVE_CR_LF(st)

		st_ptr=st;
		GET_TOKEN(token, st_ptr)

		if (!strcmp(token, "game"))
			dat->games[dat->num_games].flags|=FLAG_GAME;

		if (!strcmp(token, "resource"))
			dat->games[dat->num_games].flags|=FLAG_RESOURCE;

		if (!strcmp(token, "cloneof"))
			dat->games[dat->num_games].flags|=FLAG_CLONEOF;

		if (!strcmp(token, ")"))
		{
			if ((dat->games[dat->num_games].flags & FLAG_GAME) ||
				(dat->games[dat->num_games].flags & FLAG_RESOURCE))
			{
				dat->num_games++;
			}
			dat->games[dat->num_games].flags=0;
		}

		if (!strcmp(token, "name"))
			GET_TOKEN(dat->games[dat->num_games].name, st_ptr)
	}

	FCLOSE(in)

	if (!errflg)
		qsort(dat->games, dat->num_games, sizeof(struct game), generic_function);
	else
		dat=free_dat(dat);

	return(dat);
}

struct dat *free_dat(struct dat *dat)
{
	if (dat)
	{
		if (dat->games)
			CFREE(dat->games);

		CFREE(dat);
	}

	return(0);
}

int generic_function(const void *string1, const void *string2)
{
	return(strcmp(string1, string2));
}

/* --------------------------------------------------------------------------
 * INI File stuff
 * -------------------------------------------------------------------------- */

struct ini_entry *load_ini(char *fn)
{
	struct ini_entry *ini=0;
	FILE *in=0;
	char st[BUFFER_SIZE+1];
	char section[INI_FIELD_LENGTH+1]="";
	int num_entries=0;
	int errflg=0;

	CALLOC(ini, MAX_INI_ENTRIES+1, ini_entry)

	if (!errflg)
		FOPEN(in, fn, "r")

	while (!errflg && fgets(st, BUFFER_SIZE, in))
	{
		REMOVE_CR_LF(st)

		if (strchr(st, ';'))
			*strchr(st, ';')='\0';

		if (strchr(st, '['))
		{
			strcpy(section, strchr(st, '[')+1);
			if (strchr(section, ']')) *strchr(section, ']')='\0';
		}

		if (strchr(st, '='))
		{
			if (num_entries<MAX_INI_ENTRIES)
			{
				strcpy(ini[num_entries].section, section);
				strcpy(ini[num_entries].value, strchr(st, '=')+1);
				*strchr(st, '=')='\0';	
				strcpy(ini[num_entries].param, st);
				num_entries++;
			}
			else
			{
				printf("The INI file contains too many entries\n");
			}
		}
	}

	FCLOSE(in)

	return(ini);
};

void free_ini(struct ini_entry *ini)
{
	CFREE(ini);
};

char *find_ini_value(struct ini_entry *ini, char *section, char *param)
{
	int found=0, i=0;

	while(!found && ini[i].section[0])
	{
		if (!strcmp(section, ini[i].section) && !strcmp(param, ini[i].param))
			found++;
		else
			i++;
	}

	if (found)
		return(ini[i].value);
	else
		return(0);
};


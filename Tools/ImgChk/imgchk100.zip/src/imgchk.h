/* --------------------------------------------------------------------------
 * ImgChk - Written by Logiqx (http://www.logiqx.com)
 * -------------------------------------------------------------------------- */

/* --- Function prototypes --- */

struct ini_entry *load_ini(char *);
void free_ini(struct ini_entry *);
char *find_ini_value(struct ini_entry *, char *, char *);

struct dat *load_dat(char *);
struct dat *free_dat(struct dat *);

int process_section(struct ini_entry *, struct dat *, char *);
int check_zip(struct dat *, char *, char *, int, int, int, int);

int generic_function(const void *, const void *);

/* --- Size declarations --- */

#define BUFFER_SIZE 1024
#define NAME_LENGTH 80
#define MAX_GAMES 5000

#define INI_FIELD_LENGTH 1024
#define MAX_INI_ENTRIES 200

#define FLAG_GAME 0x0001
#define FLAG_CLONEOF 0x0002
#define FLAG_RESOURCE 0x0004
#define FLAG_IMAGE 0x0008

/* --- Structures --- */

struct ini_entry
{
	char section[INI_FIELD_LENGTH+1];
	char param[INI_FIELD_LENGTH+1];
	char value[INI_FIELD_LENGTH+1];
};

struct dat
{
	struct game *games;
	int num_games;
};

struct game
{
	char name[NAME_LENGTH];
	int flags;
};

/* --- Macros --- */

#define CALLOC(PTR, NUMBER, TYPE) \
if (!(PTR=calloc(NUMBER, sizeof(struct TYPE)))) \
{ \
	printf("Not enough memory\n"); \
	errflg++; \
}

#define CFREE(PTR) \
if (PTR) \
{ \
	free(PTR);\
}

#define FOPEN(PTR, FN, MODE) \
if (!(PTR=fopen(FN, MODE))) \
{ \
	printf("Error opening %s for mode '%s'\n", FN, MODE); \
	errflg++; \
}

#define FCLOSE(PTR) \
if (PTR) \
{ \
	fclose(PTR); \
	PTR=0; \
}

#define REMOVE_CR_LF(ST) \
while (ST[strlen(ST)-1]==10 || ST[strlen(ST)-1]==13) \
	ST[strlen(ST)-1]='\0';

#define GET_TOKEN(TOKEN, ST_PTR) \
{ \
	int token_idx=0; \
\
	while (*ST_PTR==' ' || *ST_PTR=='	') \
		ST_PTR++; \
\
	if (*ST_PTR=='"') \
	{ \
		ST_PTR++; \
		while (*ST_PTR!='"' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
		if (*ST_PTR!='\0') \
			ST_PTR++; \
	} \
	else \
	{ \
		while (*ST_PTR!=' ' && *ST_PTR!='	' && *ST_PTR!='\0') \
		{ \
			TOKEN[token_idx++]=*ST_PTR; \
			ST_PTR++; \
		} \
		TOKEN[token_idx]='\0';  \
	} \
}

